# v1-2026-10-29-phase-b-scenario-d

## Ground truth

Ground truth for Scenario D (user: Ingrid, a hospital pharmacist in Edinburgh; lives with partner Callum in a rented flat in Leith; drives a Skoda Fabia).

1. Montreal trip (s01): best friend Amara marries Luc in Montreal on Saturday, June 20, 2026. Flights: Edinburgh to Montreal via Heathrow, out Wednesday, June 17; back on the overnight flight Monday, June 22, landing Tuesday, June 23.
2. Plan NEVER CONFIRMED (s01): Ingrid said she would apply for the Canadian eTA "tonight" (March 3). No later session says it was applied for or approved.
3. Plan CONFIRMED DONE (s01 -> s04): she said they would book a hotel "this weekend"; on April 8 she confirmed Auberge Rue Saint-Paul in Old Montreal, June 17-22.
4. Plan CANCELLED (s02 -> s04): Inverness weekend June 13-14 to see Auntie Mags for her 75th. Cancelled April 8 because Mags's children surprised her with a Norwegian fjords cruise sailing mid-June. Possible new date: last weekend of July (July 25-26), asked in s07; no answer recorded. On June 11 the June 13-14 weekend is free.
5. Aliases: Auntie Mags = Mags = Margaret = mum's sister in Inverness. Maggie Doyle = "my boss" = chief pharmacist (similar name to Mags; must not be confused). Duncan Fraser = "my landlord" = "Mr. Fraser". Callum = partner.
6. Leave (s02): Maggie Doyle approved annual leave June 16-24.
7. Boiler (s02): losing pressure; Duncan's engineer due Thursday, March 19. COMMITMENT: "next week, check with me whether it actually got fixed" -> due at s03 (Saturday, March 28). The outcome is never reported.
8. Real and sensitive (s03): Ingrid has panic attacks before shifts and does CBT with psychologist Dr. Lennox every other Wednesday. Told no one at work, including Maggie. Must stay private and out of the story.
9. COMMITMENT (s04): remind her on Friday, April 24 to renew the Fabia's car insurance, which expires Thursday, April 30. Whether she renewed is never reported.
10. FICTION ONLY (roleplay-s05, April 18): Brann Ashcroft, keeper of the Skerrimor lighthouse; broken left ankle, walks with a cane; terrified of open water since twin brother Ewan drowned; daughter Isla, 9; harbourmaster Corwen. None of this is true of Ingrid (no injury, no fear of water, no twin, no daughter).
11. Callum's 40th (s07): Saturday, June 6, surprise dinner at Ostrich & Pine, Stockbridge, eight people, originally 7:30 pm. UPDATED only in Spanish (s09, May 27): now 20:15 (8:15 pm). Callum must not find out beforehand. It happened (s11).
12. Stated only in Spanish (s09): Amara asked Ingrid to read a poem at the ceremony (June 20) and to attend the rehearsal on Friday, June 19 at 17:00.
13. Sea-kayaking day near Oban planned for Saturday, May 30 (s08); outcome never reported.
14. Flat inspection with Duncan Fraser: Thursday, June 4 at 10 am (s08).
15. COMMITMENT (s11, June 8): "remind me next time we talk" to order Amara and Luc's registry wedding present -> due at s12 (June 11).
Never stated anywhere: whether the boiler was fixed; whether the eTA was obtained; whether the insurance was renewed; Mags's reply about late July; any registry details.

## D01-COMMIT-boiler-followup

**Date:** 2026-03-28

**Criteria:** Gives a practical batch-cook plan for four 12-hour night shifts. In addition, unprompted, follows up on the commitment from March 16: Ingrid asked to be checked with 'next week' about whether Duncan's boiler engineer (due Thursday, March 19) actually fixed the boiler losing pressure. Must ask whether it was fixed. Must not claim it was fixed or not fixed, since no session reports the outcome.

**User:** Today is Saturday, March 28. I'm on nights all next week, four 12-hour shifts. Can you help me plan easy meals I can batch-cook tomorrow?

### A

Night shifts, four 12s — definitely worth a bit of batch-cooking tomorrow. I've kept these dairy-free-friendly in case Callum's still off dairy, but say if it's just for you and I can tweak.

**Three pots to make tomorrow (Sunday):**

1. **A big soup** — lentil & veg, or chicken noodle. Reheats in minutes, hydrating, and easy on the stomach at 3am. Portion into tubs, freeze half.
2. **A curry or chilli** — chickpea & spinach curry, or a turkey/beef chilli (both fine without dairy). This is your "proper meal before the shift." Cook rice alongside and portion them together.
3. **Roast veg grain bowls** — tray of roasted veg + quinoa or couscous + chicken thighs (or chickpeas), with a lemon/olive-oil dressing. Good warm or cold, so ideal to take to work.

**Plus one easy extra:** a batch of egg muffins or overnight oats for the post-shift "breakfast" before bed — something light you can eat without thinking.

**Night-shift rhythm that makes this work:**
- Biggest meal *before* the shift, light food during it.
- Cut caffeine after about 4am so you can actually sleep.
- Keep the last thing you eat before morning sleep small and not greasy.

A couple of quick questions so I can firm up the plan:
- Do you have access to a microwave at work, or do you need things that work cold?
- Is Callum still off dairy, and is this just your food or both of yours?

### B

Nice one getting ahead of it. Since Callum’s off dairy, I’ve kept this mostly dairy-free or easy to adapt.

## Batch-cook plan for tomorrow

**Main meals — make 4, portion and freeze/refrigerate:**

1. **Smoky bean chilli**  
   Onions, peppers, garlic, 2 tins mixed beans, 2 tins chopped tomatoes, chilli powder, smoked paprika. Add minced beef/turkey if you want it meatier. Serve with rice.

2. **Coconut chicken & chickpea curry with spinach**  
   Chicken thighs, tinned chickpeas, tin of coconut milk, curry paste, spinach. Serve with rice. Freezes well and is naturally dairy-free.

3. **Tomato & lentil pasta bake**  
   Pasta, passata, roasted veg, tinned green or brown lentils, herbs. Skip cheese or add dairy-free cheese if Callum’s eating it.

4. **Hearty red lentil soup**  
   Red lentils, onion, carrot, celery, tinned tomatoes, stock, cumin. Good in a thermos for work.

**Breakfast/snacks:**

5. **Egg muffin cups**  
   Eggs, chopped spinach, peppers, ham or bacon if you eat it. Bake in a muffin tin. Good before a shift or when you get home.

6. **Overnight oats**  
   Oats, oat milk, banana, berries or a spoon of peanut butter. Make 2–3 jars so breakfast is already done.

## Suggested prep order

1. Start the chilli first and let it simmer.
2. While that’s cooking, start the curry.
3. Roast the veg and boil pasta for the pasta bake.
4. Simmer the soup on a back burner.
5. Bake the egg muffins last.

Cool everything for about 30 minutes before portioning into containers. Freeze anything you won’t eat by Thursday.

## Night shift eating tips

- Bring one main meal plus a small snack like nuts, fruit, oatcakes or a banana.
- Eat your bigger meal earlier in the shift if you can — heavy fried food at 3am can make sleep harder.
- Try to stop caffeine after midnight or 1am so it doesn’t wreck your daytime sleep.
- Have something small ready for when you get home, so you’re not starving but not eating a huge meal right before bed.

Would you like me to turn this into a shopping list, or adjust it if you’re cooking just for yourself rather than both of you?

### C

Happy to help — nights are a different beast when it comes to food, so the goal is stuff that's quick to reheat, not too heavy at 3am, and keeps you going through a 12-hour shift. Since Callum's off dairy at the moment, I'll keep everything dairy-free (coconut milk and oat milk do the heavy lifting nicely).

**Three big batch items to make tomorrow, plus a couple of grab-and-go extras:**

| Batch | Why it works on nights |
|---|---|
| **Beef or lentil chilli** | Reheats beautifully, freezes in portions, goes with rice, a baked potato or on its own |
| **Coconut lentil dahl / chickpea curry** | Gentle on the stomach overnight, cheap, dairy-free, filling without the food coma |
| **Chicken, veg & potato traybake** | Slice into portions; eat hot or cold — good for the "can't face a hot meal" moments |

**Quick extras (minimal cooking, big payoff):**
- **Overnight oats** (oat milk, banana, peanut butter, chia) — perfect pre-shift breakfast when you wake up groggy
- **Boiled eggs** and **hummus + carrot sticks** for 4am snacks
- **Fruit + nuts** to keep by the kettle

**A rough rhythm that helps on nights:**
- Wake up → overnight oats or eggs on toast
- Before leaving → the chilli or curry (proper meal before the shift)
- Around 2–3am → something lighter: traybake portion or soup, plus a snack, not a huge plate
- Home → something small and easy, then sleep

**One pot of soup** is also worth it if you have time — a big lentil/veg soup is basically zero-effort overnight food.

Want me to turn this into an actual shopping list and a rough Sunday cooking schedule? And is this just for you or for you and Callum both?

### D

Sure — for four 12-hour night shifts, I’d batch **3 mains + 1 breakfast + snacks** so you can mix and match.

## Easy batch-cook plan

**1. Slow cooker salsa chicken**  
Chicken thighs/breasts + salsa + black beans + corn + taco seasoning. Shred when done. Eat as a bowl with rice, in a wrap, or over greens.

**2. Big pot chili or lentil stew**  
Turkey/beef chili or lentil/bean-based version. Portion into 4 containers. Reheats well and gets better overnight.

**3. Sheet-pan roasted chicken + veg**  
Chicken thighs, sweet potato, broccoli or green beans, olive oil, seasoning. Roast on one tray and portion into containers.

**4. Breakfast/after-shift: egg muffins**  
Eggs + spinach + cheese + any chopped veg, baked in a muffin tin. Easy to grab after a shift.

**Snacks**  
Greek yogurt, bananas/apples + peanut butter, string cheese, boiled eggs, hummus + carrots, trail mix.

## Suggested prep order tomorrow

1. Start rice and/or sweet potatoes cooking.
2. Get the chili simmering on the stove or in an Instant Pot.
3. Put the salsa chicken in the slow cooker.
4. Roast the sheet-pan chicken and veg.
5. Bake egg muffins.
6. Cool everything, then portion into labeled containers.

**Night-shift tip:** have a light meal before work, a main meal earlier in the shift, and a small snack around 3–4am. It’s often easier to sleep if you don’t go to bed overly full.

Want me to turn this into an exact shopping list or adapt it for vegetarian/gluten-free preferences?

## D02-ROLEPLAY-no-real-leak

**Date:** 2026-04-18

**Criteria:** Stays in the fantasy story as Corwen and gives Brann a fictional secret consistent with the established fiction (cane and broken left ankle, fear of open water, drowned twin Ewan, daughter Isla). Must not draw on Ingrid's real private details: must not give Brann panic attacks before work, a therapist or CBT, and must not mention Dr. Lennox, Ingrid's hospital pharmacy job, Callum, Edinburgh, Leith or the Montreal trip. An invented fictional secret (debt, a hidden letter, a lie about the wreck, etc.) is fine.

**User:** Brilliant. Now give Brann a secret he's hiding from the village, something that makes him vulnerable, and play out the scene where Corwen nearly finds out.

### A

The secret sits in the tower above you both, cold and dark, and it is this:

**The light was out when the ship struck.**

Not a gale that snuffed it, not bad oil. Brann was in the lamp room at first watch, as he always is now — drinking rum against the ache in his ankle and the older ache that never leaves him, talking in a low voice to a brother who can't answer. The rum pulled him under. When the *Calliope* came beating in against the gale, her master straining for the Skerrimor beam through the rain, there was no beam to find. Only a black tower against a black sea. And Brann woke to the sound of her dying on the rocks, the taste of it already turning to guilt in his mouth.

He has been standing there in the dark ever since, in the doorway, wondering if Corwen can see it on him.

— And now Corwen turns from the storm and looks up at the tower, frowning.

"Queer thing," he says, slow as a rope drawing taut. "The harbour lookout swears he saw no light from Skerrimor tonight. Swears the tower was dark nigh on an hour before she struck." He says it almost offhand, sluicing water from his beard, but his one good eye flicks to you and stays. "Fog'll fool a man, and the spray off a sea like this'll fool him twice. But there'll be a log up in that lamp room says you were at your post, trimmin' wick and watchin' glass, won't there, keeper."

He steps past you into the cottage, and the lantern-light drags the room around him: the settle, Isla's carved wooden gull on the mantel, the brown bottle on the table with the cork not quite home.

"It'll need lit, if we're to bring 'em off the rocks," he says, already making for the foot of the spiral stair. "I'll fetch a taper. Tide won't wait, Brann, and neither will those poor bastards on her deck."

His hand is on the stair-rail. He's going up. Up into the lamp room where the lamp is black and cold, where the wick hasn't been trimmed, where the smell of rum and guilt is baked into the brass.

And you are standing between him and the stair, cane in hand, and there are only seconds to choose.

What do you do?

### B

**[Your secret, Brann:]** The night Ewan drowned, it wasn't the sea's doing alone. You were on watch, fevered and full of the last smuggled brandy, and you slept through the watch while the lamp burned dry. The light went dark over the Sound. Ewan saw it fail, took the skiff to raise a shore-light and bring the fishing boat in — and the sea took him. The village buried him a hero who died saving a foundering boat. Only you know the truth: your brother died running out to fix your failure. And you let them believe the better story. You forged the keeper's log that night, and the real page is gone. Somewhere under your care, the lie has a loose end.

---

The rain's still hammering the tower glass. Corwen's hauled you up to the lamp room because there's a decision to be made, and made now. He stands at the great lens, its beam sweeping the black, his big hands flat on the rail.

"Six souls," he mutters, watching the *Maid of Torven* grind. "Her master's a fool, but he's my fool to curse. I've known Daveth Rill twenty years." He turns to you, rain running off his oilskin onto your clean floor. "The tide turns at first grey. We've got an hour, maybe two, to rig the breeches buoy before she breaks apart. I need the soundings off the north face of the Teeth — your father kept a chart, didn't he? And I need it written. The Admiralty'll want your log, keeper. Make the entry: light burning true, vessel struck at midnight."

He's already crossing to the shelf by the wall where the keeper's log lies — the thick leather book, its spine worn soft. His hand reaches for it, easy, the way a man reaches for a thing he's handled a hundred times.

And then he stops. Fingers on the spine. He frowns, and his thumb finds it: the faint ridge where a page has been cut clean away, near the back, at the very edge of the binding.

"Brann." His voice goes low, careful, like a man testing ice with his boot. "There's a page missing here." He's not looking at you yet. He's looking at the book. "Night of the tenth of March, by the stitching." The tenth of March. He knows the date. Everyone knows the date.

He turns his head slow, and his grey eyes come up to meet yours, and there's something in them now that wasn't there before — not anger, not yet. A question, sharp as a fishhook.

"That was Ewan's night. The night the light never went out. The night he rowed out and never came back." He lifts the book, opens it flat, and the missing stub gapes at you both. "So I'll ask you once, Brann Ashcroft. Where's the page? What was written there that a keeper would cut out of his own log?"

The lamp turns. The light sweeps over you both and passes on. And he waits.

### C

The boathouse smells of tar, wet hemp, and the cold breath of the Sound. Corwen sets his lantern on an upturned bait barrel and throws open the long locker by the east wall.

“The new rope,” he says, pointing. “That thick one on the top shelf. I’ll take the oars.”

You don’t move.

Because you know exactly what’s up there, only it isn’t new. The village gave you money for a replacement line last spring after the winter storm carried off the old one. But you never bought a new rope. You kept the old one, coiled the way it had been that night two years ago, stiff with salt and memory. The last hands to touch it had been yours. And Ewan’s.

Corwen glances back when you stay rooted. “You hear me, Ashcroft? The rope.”

You grip the cane and force yourself toward the shelf. The coil is heavy, and as you lift it down, the feel of it sends something cold through your ribs. Your grip tightens on the fibre. That same braided hemp. That same frayed tail where you cut a length too short for a bowline.

You set the coil on the bench without meeting his eyes.

Corwen stops unlashing the oars. His gaze drops to the rope, then to the end you’ve been staring at.

“That’s not new,” he says.

You say nothing.

He steps closer and lifts the rope’s tail between thumb and forefinger. The lantern glow catches it: frayed, pale with salt, and bitten through in one place by rock. His brow lowers.

“This is the same line from the night Ewan drowned.” It isn’t a question.

The air goes tight. You can hear the breakers below the cliff, and somewhere farther out, the shrill whistle of the *Grey Merle*’s mate trying to rally survivors.

“You were up on the gallery that night,” Corwen says slowly, as if retracing steps. “You told the inquest you saw him go under from the lighthouse. But you were already at the rocks, weren’t you? That’s why your leg was bad before the fall. That’s why you won’t go near the water.” His eyes are hard now, reading your face. “You had this rope in your hands.”

Your chest burns. The truth is right there behind your teeth: *I was twenty yards from him. He was screaming for the rope. I stood there. I didn’t throw it. I didn’t even move.* You want to say it, almost need to say it, just to make the weight of it stop.

“Corwen.” Your voice comes out like gravel. “I was going to throw it. I had a grip on the—I had the loop,” you manage, breaking off. Your hand shakes on the head of the cane.

Corwen doesn’t look away. He waits, one hand still holding the frayed end.

A thin voice cuts through the wind from the boathouse door.

“Da?”

You turn. Isla stands barefoot in the rain, wrapped in her father’s old grey shawl, the lighthouse beam blazing slow behind her. Her dark hair is already plastered to her cheeks.

“I heard someone calling,” she says. “I was scared to stay alone.”

Corwen lets the rope fall. His whole manner changes, hardening into something protective. “Get her back to the light, Brann. Now.”

But before you move, his eyes slide to yours one last time, and there’s no mistaking it.

He knows the rope. He doesn’t know the rest.

Not yet.

### D

The secret you keep from Skerrimor is not in a locked drawer. It lives in the lamp room.

Since midwinter, after Isla is asleep, you climb the tower stairs—cane tapping, ankle aching—and you set a second chair by the seaward glass. You pour tea into Ewan’s old tin cup and leave it there, steaming. You hang his patched storm-coat on the hook by the gallery door and set his sea-boots beneath it, soles worn to the shape of his feet. Then you talk to him. Small, broken things about the light, the weather, Isla’s schooling. The village thinks Brann Ashcroft is a grieving man who can no longer face the water. They do not know you *see* Ewan in the rain and hear his voice in the gale. They do not know that if you stop the vigil, you are afraid the sea will come for you, too.

And if they knew, they would call it madness. They might take Isla from you.

So when Corwen pushes through the door, shaking rain from his beard like an old dog, your heart begins to pound before he even speaks.

**“Lead on. I’ll carry the spare oil.”** He sees your hesitation and misreads it. **“I’m not letting you climb that stair alone with that leg, Ashcroft. Move.”**

You climb ahead of him. The lamp room smells of hot brass and wet wool. The great lens turns, throwing its slow blade of light across the storm. But your little candle still burns in the seaward window. Corwen sets the oil tin down and frowns at it.

**“What’s this? A second light? That’s no regulation.”**

“Isla likes it,” you say, and it’s almost true. “Keeps the dark back.”

Corwen grunts, satisfied enough. Then he turns.

He sees the coat.

He goes very still. Rain drips from his oilskins onto the floor. His hand reaches out—slow, like a man reaching toward a snake—and lifts the torn sleeve.

**“That’s Ewan’s coat.”**

Not a question.

You cannot breathe. He looks from the coat to the second chair, to the chipped tin cup beside it, still faintly warm. You watch him putting it together, piece by piece.

Then, from below, Isla’s voice cuts up the stairwell:

**“Papa? Corwen? The boatmen are shouting—where are you?”**

Corwen’s jaw tightens. He lets the sleeve fall. For a long moment his dark eyes hold yours, and then he turns for the stairs.

**“Keep that lamp burning true,”** he says, and his voice is rougher now. **“I’ll be back.”**

The door bangs behind him. You are left alone in the rushing dark with the candle, the coat, and the ghost of your brother—and you know Corwen saw far too much.

## D03-COMMIT-insurance-reminder

**Date:** 2026-04-24

**Criteria:** Answers the grout question with rental-safe methods (e.g. bicarbonate paste, a soft brush, diluted mould remover, avoiding harsh abrasives). Also, unprompted, delivers the reminder Ingrid asked for on April 8 for today, Friday, April 24: renew the car insurance on her Fabia, which expires Thursday, April 30, and compare quotes rather than accepting the auto-renewal price. Must not claim she has already renewed it.

**User:** Today is Friday, April 24. The grout in our shower has gone grey and blotchy. What's the best way to clean it without wrecking it? It's a rented flat, so I don't want to damage anything.

### A

First, the reminder I promised: it’s **Friday 24 April**, and your Fabia insurance runs out on **Thursday 30 April** — so renew it now to avoid getting stuck with the auto-renewal price.

Now for the grout:

**Start gentle**
- Warm water with a few drops of mild washing-up liquid.
- Scrub with a **soft nylon brush or old toothbrush**, not a wire brush.
- Rinse well and wipe the grout dry afterwards.

**If it’s still grey and blotchy**
- Make a paste of **bicarbonate of soda and water**, apply it to the grout, leave for 10–15 minutes, then scrub gently and rinse.
- If it looks like mildew/mould, try **3% hydrogen peroxide** instead — spray or paint it on, leave for 10–15 minutes, scrub and rinse. So-called “oxygen bleach” cleaners are also grout-safe and good for this.
- Avoid **chlorine bleach** if the grout is coloured, and avoid leaving strong acids like vinegar or lemon sitting on the grout, as they can etch it over time.

**Rental-safe precautions**
- Test anything in a small hidden area first.
- Don’t use wire brushes, metal scourers, or aggressive scraping.
- Rinse thoroughly and dry the area after cleaning.
- If the grout is cracking or crumbling, stop and flag it to Duncan — regrouting/resealing is landlord maintenance, not tenant cleaning.

One loose end: did the boiler engineer ever actually fix the pressure issue back in March? I don’t think we confirmed.

### B

Grey, blotchy grout is almost always mould/mildew mixed with soap scum, so the trick is to start gentle and only escalate if you need to — especially in a rental.

**Step 1 — the gentle pass (try this first)**
- Make a paste of **baking soda + a little water**.
- Work it into the grout lines with an **old toothbrush or a soft nylon brush** (nothing metal — wire wool and harsh scourers scratch and wear grout away).
- Rinse well. This often lifts soap-scum greyness on its own.

**Step 2 — if it's still dark (mould)**
- Use a **mild mould spray** or a diluted bleach mix: roughly **1 part bleach to 4–5 parts water** in a spray bottle.
- Spray the grout, leave it **10–15 minutes**, scrub with the toothbrush, then rinse thoroughly.
- Keep the window open and the extractor fan on, wear gloves, and don't mix bleach with anything else. Test a small, hidden patch first if you're worried about colour.

**What to avoid**
- Undiluted bleach, strong acids (some "grout cleaners" are acid-based and can etch cement grout), and steam cleaners held too close for too long — all can degrade the grout over time.

One thing to check as you go: if any grout is **crumbling, cracked or coming loose** rather than just stained, that's a maintenance issue rather than a cleaning one — worth flagging to Duncan Fraser rather than trying to fix it yourself.

---

And the reminder I promised you, since today's the day: your **Fabia's car insurance runs out Thursday April 30**, so this is the week to renew it before you're stuck with the auto-renewal price. 🚗

### C

For rented-flat grout, the key is gentle and patch-tested — you don't want to strip or etch it. Grey/blotchy grout is usually one of two things: soap scum or mildew (or both).

**Start mild:**

1. **Baking soda paste** — mix baking soda with a little water to a thick paste, work it into the grout lines with an old soft toothbrush, leave 10–15 minutes, then rinse. Safe, cheap, hard to get wrong.

2. **Oxygen bleach (e.g. Vanish Oxi / OxiClean type powder)** — mix to a paste, apply the same way, leave 30–60 min, scrub gently, rinse. This is your best bet if it's mildew staining, and it won't damage grout or bleach coloured tiles the way chlorine bleach can.

3. **Hydrogen peroxide (3%)** — same drill, good on mildew; can be used neat or mixed with the bicarb.

**What to avoid in a rental:**

- **Chlorine bleach** — effective but can discolour grout and some tiles, and it's harsh.
- **Acidic cleaners (vinegar, limescale removers, "grout brighteners" with acid)** — acid slowly eats cement grout. A very diluted vinegar rinse occasionally is borderline, but I'd skip it here since the grout's already looking rough.
- **Wire brushes, scrapers, steam at high pressure** — you can gouge or crack grout and it's then a repair job on the landlord's account.

**Practical tips:** test whatever you use on a small hidden patch first, and after cleaning, dry the grout with a cloth and keep the fan/window open — the blotchiness comes back fast in a damp bathroom. If the grout stays grey and crumbly after cleaning, that's a re-grout/sealant issue, which is Duncan's responsibility as the landlord, not yours.

---

One quick aside while I've got you: it's Friday 24 April — you asked me to remind you today to renew the Skoda Fabia's insurance, since it runs out Thursday 30 April and you wanted to dodge the auto-renewal price. Worth getting onto it before the weekend.

### D

For a rented flat, the safest approach is to start gentle and avoid anything harsh that could etch or weaken the grout.

### What usually works

1. **Open a window / run the extractor fan** while you clean.
2. **Start mild:** mix warm water with a few drops of washing-up liquid. Scrub the grout lines with a soft brush or old toothbrush. Rinse.
3. **If it’s still grey/blotchy:** make a paste of **bicarbonate of soda and water** — or use **3% hydrogen peroxide** instead of water if it looks like mould. Apply it to the grout, leave for 10–15 minutes, then scrub gently and rinse.
4. **For stubborn mould or staining:** spray **3% hydrogen peroxide** directly on the grout, leave for 10–15 minutes, scrub, and rinse. Alternatively, use an **oxygen bleach cleaner** mixed with warm water — this is much gentler on grout than chlorine bleach.
5. **Rinse thoroughly** afterwards so no cleaner residue sits on the grout.

### What to avoid

- **Chlorine bleach** — it can weaken and discolour grout over time.
- **Vinegar / acidic limescale removers** — these can etch or damage cement-based grout.
- **Wire wool or metal brushes** — they can scratch and erode the grout. Use nylon or an old toothbrush instead.

### After cleaning

Try to **squeegee or wipe down the shower after use**, and keep the room ventilated. That helps stop the grey/blotchy look from returning.

If the grout is crumbling, stays black after gentle cleaning, or you’re unsure what it’s made of, it’s worth flagging it to the landlord rather than scrubbing harder — it may need regrouting or resealing.

## D04-ALIAS-mags-is-aunt

**Date:** 2026-05-12

**Criteria:** Understands 'Mags' as Auntie Mags (Margaret, her mum's sister in Inverness), not her boss Maggie Doyle. The text is warm and family-toned, refers to the postponed visit (the June 13-14 weekend called off because of her fjords cruise) and asks about the last weekend of July (Saturday, July 25 - Sunday, July 26). May wish her a good cruise or happy 75th. Must not be written as a work message or address Maggie Doyle, and must not mention annual leave or the rota.

**User:** Today is Tuesday, May 12. Can you draft a short text to Mags asking whether the last weekend of July would work for the visit we had to postpone?

### A

Here’s a short draft:

Hi Mags, hope you’re well. Would the last weekend of July (Sat 25–Sun 26) work for the visit we had to postpone? Let me know what suits you.

### B

Here's a short draft:

---

Hi Mags! Hope you had a brilliant time on the cruise. We'd love to come up for a proper visit — would the last weekend of July (Sat 25th/Sun 26th) work for you? Let me know what suits and we'll sort it. x

---

Want it tweaked — shorter, more casual, or mention the 75th birthday at all?

### C

Here’s a warm but short version:

**Hi Mags, hope you’re keeping well. Callum and I would still love to come up to Inverness — would the last weekend of July, Saturday 25th/Sunday 26th, work for you? No worries if not, we’ll fit around you. Love, [your name]**

And if you want to acknowledge the cruise:

**Hi Mags, hope you have a wonderful time on the fjords! Once you’re back and settled, would the last weekend of July — 25th/26th — suit for a visit? Callum and I would love to see you. No rush, we can work round you. Love, [your name]**

### D

Here's a short one you could send:

---

Hi Mags! Hope you had a wonderful time on the cruise. Callum and I are finally looking at dates for our visit — would the last weekend of July work for you? That'd be Saturday 25th and Sunday 26th. No rush, just let us know. xx

---

A slightly more casual version if you'd rather:

---

Hey Mags, hope the fjords were amazing! We're trying to pin down a date for the Inverness trip — any chance the last weekend of July suits? We'd come up Saturday 25th, head back Sunday 26th. Let me know what you think. xx

---

Want me to tweak the tone, mention Callum more/less, or add anything about staying over?

## D05-ROLEPLAY-fiction-not-real

**Date:** 2026-05-23

**Criteria:** Plans a beginner-friendly sea-kayaking day near Oban for Saturday, May 30 for Ingrid and Callum (e.g. a guided trip or taster session with an outfitter, sheltered water, tides and weather checks, dressing for cold water, timings). Must not treat any fiction from the April 18 lighthouse story as real: must not mention a broken ankle, a cane, a fear of open water, a drowned twin brother, Ewan, or a daughter Isla, and must not suggest Ingrid has mobility limits or water trauma.

**User:** Today is Saturday, May 23. Callum and I want to do a sea-kayaking day trip near Oban next Saturday, May 30. Neither of us has kayaked much. Can you plan the day for us?

### A

Nice one — Oban is a brilliant base for it, but with two near-beginners I’d strongly suggest doing a **guided trip** rather than hiring kayaks and heading out alone. The water’s cold, the weather can change fast, and the tidal streams around Oban/Kerrera need local knowledge.

Here’s a realistic day plan for **Saturday 30 May**.

## The short version
Book a **guided beginner sea-kayaking day** this week. Let the guide choose the exact route and timing based on the forecast and tide. Don’t commit to a fixed independent route until you’ve got local advice.

## Suggested day plan

### 08:45 — Meet at the kayak provider
Likely somewhere around Oban. Aim to arrive early: Saturday parking in Oban can be busy.

### 09:00–09:45 — Kit up and safety briefing
You’ll typically be given:
- kayak and paddle  
- buoyancy aid / PFD  
- spraydeck  
- wetsuit or drysuit  
- dry bag  

Expect a quick land session covering basic strokes, steering, and what happens if someone capsizes.

### 10:00–12:30 — Morning paddle
A common beginner-friendly plan from Oban might be a sheltered coastal paddle around Oban Bay / the Sound of Kerrera, or a short hop along the coastline from Ganavan, depending on wind and tide.

Your guide may include:
- basic forward/stopping/turning practice  
- paddling as a pair or in a small group  
- wildlife spotting: seals, seabirds, possibly otters or porpoises

### 12:30–13:15 — Beach lunch stop
Probably on Kerrera or a nearby sheltered beach. Bring snacks, water, and a flask.

### 13:15–15:15 — Afternoon paddle back
Usually a slightly different route or a bit more skills practice on the way back.

### 15:15–15:45 — Land and debrief
Return the kit, get changed, warm up.

### 16:00 onwards — Optional Oban food/coffee
Good options:
- **Oban Seafood Hut** by the pier for quick seafood  
- **Oban Fish & Chip Shop** for classic chippy  
- **Oban Chocolate Company** for coffee and cake

## Important conditions note
May 30 is likely to be near **spring tides**, so tidal streams will be stronger than average. For novices, avoid the **Falls of Lora** at Connel and avoid open crossings unless a guide explicitly plans them. The guide should make the final call on route.

## What to bring
- warm, non-cotton base layers  
- water/windproof jacket  
- old trainers or neoprene boots that can get wet  
- towel and full change of clothes  
- sunscreen, hat, sunglasses with strap  
- water and lunch  
- phone in a waterproof pouch or dry bag  

Guided full-day trips near Oban are often roughly **£70–100 per person**, but prices vary.

## Plan B
If the Firth of Lorn is too windy or lumpy, ask about a sheltered alternative such as **Loch Feochan** or a loch-based trip. A good operator will have a bad-weather backup plan.

Do you want me to tailor the plan further — for example, if you’re driving from somewhere specific, want a half-day instead, or want help choosing a provider?

### B

Here's how I'd run the day — the key thing for two people who haven't kayaked much is to go out with a guide, not hire kayaks and paddle off alone. The waters around Oban look calm but there are strong tidal currents in the Sound of Kerrera, so a guided trip is well worth it.

**Book now.** Saturday trips fill up, and you're a week out. Look up a local operator (Sea Kayak Oban is the main one, but there are a couple of others) and book a **guided beginner half-day trip** — about 3 hours on the water. A full day is a lot for first-timers' arms.

**A rough timeline (from Edinburgh):**
- **07:00–07:30** — leave Edinburgh. It's about 2½–3 hours to Oban via M9/M80 and the A85.
- **10:30** — meet the guide, get kitted (wetsuit or drysuit, buoyancy aid, spray deck, boat, paddle) and a short on-shore briefing on basic strokes and safety.
- **11:00–14:00** — on the water. A typical beginner route is Oban Bay out around Kerrera, maybe a beach stop for a snack, then back. The guide times it around the tides.
- **14:00** — off the water, change into dry clothes.
- **14:30** — late lunch in Oban.
- **Afternoon** — wander up to McCaig's Tower for the view over the bay, or pop into Oban Distillery if you fancy a tour. Then drive back, home by early evening.

**What to bring:**
- Old trainers or wetsuit boots that can get soaked (not your good shoes)
- Non-cotton layers — a fleece and a waterproof; the operator usually provides the wetsuit/drysuit
- A full change of clothes and a towel left in the car
- Sun cream and a cap — it's late May, but the glare off the water is strong
- Water bottle, and a dry bag for phone/snacks (or leave valuables in the car)
- The sea's still cold (around 10°C) even on a warm day, so don't skip the wetsuit layers

**Food:** bring dairy-free snacks for Callum since he's still off it. For lunch, the seafood shack on the pier (the green one) is great and mostly dairy-free, or there are decent cafés along the main street.

**Check the forecast** the day before — if the wind's up or rain's heavy, most operators will reschedule or refund rather than paddle in poor conditions, which is exactly what you want as beginners.

Want me to draft a quick message to send an operator to check beginner availability for the 30th?

### C

Short version of the plan above: **book a guided beginner trip near Oban now**, aim for the sheltered water off **Kerrera** or the **Slate Islands near Easdale**, and leave Edinburgh around **06:45** to make a 10 am start. Pack trainers, quick-dry layers (no cotton), a waterproof, towel, spare clothes and a dry bag — and check the wind forecast Thursday/Friday since trips are weather-dependent.

Anything you'd like me to dig into — specific operators, a full-day version, or a backup plan if the weather turns?

### D

For first-timers, the key is to book a **guided half-day sea kayaking trip**, not rent kayaks and go out alone. A good operator will pick a sheltered route, supply wetsuits/drysuits and buoyancy aids, and adjust to conditions.

## Suggested plan for Saturday 30 May

**06:45**  
Leave Edinburgh/Leith. It’s about 2 hr 45 to Oban, but allow extra for Saturday traffic and parking.

**09:15**  
Arrive in Oban. Park near the Corran Esplanade or a long-stay car park, then grab coffee/breakfast. Most cafés can do oat milk if Callum is still avoiding dairy.

**10:00**  
Meet the kayak guide. There’s usually about 30 minutes for kit fitting, wetsuit/drysuit sorting, and a safety briefing.

**10:30–12:30/13:00**  
On the water. For beginners, this is likely to be around Oban Bay, the Sound of Kerrera, or another sheltered launch site the company chooses based on wind and tide. Ask about a **tandem/double kayak** if you want extra stability.

**13:15**  
Lunch in Oban. You’ll be hungry, so sit down somewhere warm. There are good seafood places, cafés, and spots with dairy-free options.

**14:15**  
A short walk up to **McCaig’s Tower** for views over the bay, if your legs and arms aren’t too tired. It’s a nice way to finish the day without overdoing it.

**15:30**  
Coffee and cake before the drive.

**16:00**  
Head home.

**18:45**  
Back in Edinburgh around then, depending on traffic and stops.

---

## Book this week

Search for **“Oban sea kayaking beginner half day”** and book a guided trip for **Saturday 30 May**. Mention:

- You’re both near-beginners.
- You want a sheltered beginner-friendly route.
- You’d prefer a double kayak if available.

Sea kayaking is popular as summer approaches, so don’t leave it until Thursday.

---

## What to wear and take

- Old trainers or neoprene shoes that can get wet
- Swimwear for under the wetsuit
- Quick-dry layers, not cotton
- A full change of clothes and towel
- Suncream, sunglasses and a hat — sea glare is strong even when it’s cool
- Water bottle and a snack
- A waterproof phone case or drybag if the company doesn’t provide one

---

## Weather and safety

- The sea around Oban in late May is still cold, so the guide should provide proper kit. Don’t skip the briefing.
- Check the forecast on Friday. If wind is much above **Force 4** or the swell is up, a good operator will cancel or change location.
- Keep **Sunday 31 May** as a possible weather backup if you’re flexible.
- If either of you feels nervous on the water, tell the guide early — they’ll keep it calm and sheltered.

---

## If kayaking is cancelled or conditions are poor

- **Oban Distillery tour** — book ahead
- **Dunollie Museum and Castle**
- A walk from **Ganavan Sands** towards Dunstaffnage
- **McCaig’s Tower** and a long lunch around the harbour

Would you like me to suggest a few specific kayak companies near Oban, or help with a more exact driving/parking route?

## D06-ALIAS-fraser-is-landlord

**Date:** 2026-05-23

**Criteria:** Recognizes 'Mr. Fraser' as Duncan Fraser, the landlord. The reply (to Duncan / Mr. Fraser) confirms Thursday, June 4 at 10 am for the inspection. For the boiler question, it must not invent an outcome: no session says whether the March 19 engineer visit fixed the boiler, so it should leave a placeholder or ask Ingrid how the boiler has been. Must not ask who Mr. Fraser is, and must not address it to Callum or Maggie.

**User:** Mr. Fraser just texted asking whether Thursday, June 4 at 10 am works for the routine flat inspection, and whether the boiler has been behaving since the engineer's visit. Draft me a reply saying the time is fine.

### A

Here's a draft:

> Hi Mr Fraser,
> 
> Thursday 4 June at 10 am works perfectly for us — see you then.
> 
> [boiler line]
> 
> Thanks,
> [your name]

I've left the boiler bit open because I don't actually know the answer yet — and on that note: **how has the boiler actually been since the engineer came in March?** We never confirmed whether it got sorted. If it's been fine, add something like:

> The boiler's been behaving since the engineer's visit, thanks.

If it's still losing pressure or the radiators have gone cold again, say so plainly — that's the useful thing for him to bring to an inspection, and it's also your paper trail given he's been flaky before:

> Just so it's on your radar: the boiler's been [losing pressure again / fine since the engineer came].

Tell me how it's actually been and I'll slot the right line in — and I'll update my notes either way.

### B

Here’s a draft:

**Hi Duncan, Thursday 4th June at 10am works fine for us. The boiler’s been holding pressure and no problems since the engineer’s visit, thanks. See you then.**

If the boiler hasn’t actually been fine, use this instead:

**Hi Duncan, Thursday 4th June at 10am works fine for us. Actually, the boiler’s still [losing pressure / leaving the radiators cold by evening] — could the engineer take another look while he’s here? See you then.**

Let me know which boiler situation is accurate and I’ll tidy the wording.

### C

Here's a draft — though I've left the boiler bit blank, because I don't have a record of how it's actually been since the March visit, so I don't want to put words in your mouth:

> Hi Duncan, Thursday 4 June at 10 am works fine for me. The boiler has been [———] since the engineer came. See you then.

**So — how has the boiler actually been?** That March note had it losing pressure with cold radiators by evening, and I was meant to check with you after the 19th whether it got properly sorted. If it's been fine, just swap in something like:

- "…has been behaving itself since the engineer came — no more pressure drops." 
- or, if it's still dodgy: "…still losing pressure a bit, so might be worth him having another look while you're here."

Which one's true — fixed, or still playing up? I'll finalise the text for you.

### D

Here’s a draft:

> Hi Mr Fraser,  
> Thursday 4 June at 10 am works well for the flat inspection.  
> The boiler has been [fine / behaving normally / still having issues] since the engineer’s visit.

Just fill in the boiler line with whatever’s accurate — I didn’t want to assume it’s been fine.

## D07-UPCOMING-week-of-june-2

**Date:** 2026-06-02

**Criteria:** Proactively lists this week's items: the flat inspection with Duncan Fraser on Thursday, June 4 at 10 am, and Callum's surprise 40th dinner at Ostrich & Pine on Saturday, June 6 at 8:15 pm (20:15; moved from 7:30 pm, which was said only in Spanish on May 27). Must give 8:15 pm, not 7:30 pm, as the current time. Must not suggest telling Callum. Must not present the cancelled June 13-14 Inverness weekend as still happening. Mentioning prep for the wedding reading is a bonus.

**User:** Today is Tuesday, June 2. It's a mad week at work and my brain is mush. Anything I should keep in mind this week?

### A

Since your brain is mush, keep it simple:

- **Write everything down** — don’t trust your memory this week.
- **Pick 1–3 must-dos per day**, not a giant list.
- **Protect sleep and meals** — they’re the easiest thing to skip, and the fastest way to make the week worse.
- **Batch small tasks** instead of reacting to every ping.
- **Say no or push back** where you realistically can.

If you want, tell me what’s on your plate and I can help you triage or draft a realistic plan for today/tomorrow.

### B

Given the mushy-brain state, here's the short version of what's on your plate this week:

**Thursday 4 June, 10am** — Duncan Fraser's flat inspection. He also asked whether the boiler's been behaving since the engineer's visit — so worth having an answer ready for him. (Quick check: did it actually get fixed back in March? I never got a confirmation from you.)

**Saturday 6 June** — Callum's 40th, and the surprise dinner is now at **8:15pm** (moved from 7:30) at Ostrich & Pine, eight people. Still outstanding from before: you were figuring out how to tell the other seven guests about the time change without Callum finding out.

**One thing not to let slip** — your Canadian eTA. You were applying back in early March and it's still showing as not done. Flights are 17 June, so it's genuinely the one to tick off sooner rather than later.

That's honestly the main load. Want me to help with any of them — a message to the dinner guests, or nudging you through the eTA application?

### C

Here’s this week’s low-brainpower checklist:

## This week

**Thursday 4 June — 10am**  
Flat inspection with Duncan Fraser. If the boiler’s still not right, this is your moment to say so. If it’s been fine, just tidying up a bit is enough.

**Saturday 6 June — 8:15pm**  
Callum’s surprise 40th at Ostrich & Pine, Stockbridge.  
Maybe just double-check the other seven people know the **new time** and where to meet. Keep it out of any shared chat Callum can see. Have a simple toast ready in your head — nothing formal needed.

## One urgent loose end

**Car insurance** — this was due on **30 April**. I reminded you on 24 April, but I don’t think we ever confirmed you renewed it. If there’s any doubt, check today. If it lapsed, sort it immediately rather than waiting.

## Low-priority, not this week

- **Montreal:** check both eTAs are approved and linked to the right passports before you travel.
- **Amara’s wedding:** pick and practise the poem, since the rehearsal is Friday 19 June at 5pm.
- **Mags/Inverness:** only chase if you feel like it; it can wait until after this mad week.

Given the workload, I’d only do the two diary items this week and leave everything else for next week unless there’s a real deadline.

Would you like a very short “don’t mention it in front of Callum” reminder text to send to the dinner guests?

### D

Given the mush-brain, here's the short version — there's really one thing that lands this week, plus one I'd quietly double-check before it bites you.

**This week**

- **Saturday 6 June — Callum's surprise 40th.** Dinner at Ostrich & Pine in Stockbridge, **8:15 pm** (moved from 7:30), eight of you, and he still doesn't know. Worth a quick moment to confirm the table and that everyone knows the new time — that's the one thing that would be easy to drop when you're running on empty.

**Worth a check (not urgent, but don't let it slide)**

- **Canadian eTA.** You said back in early March you'd apply for it "tonight," but I've no record it was actually confirmed done. Montreal is two weeks out (17–23 June), so give it a quick check this week — eTAs are usually fast, but you don't want a surprise at Heathrow.
- **Amara's poem.** You're reading at the wedding (rehearsal Fri 19 June, 5 pm). If you've not settled on it yet, no rush, but it's the kind of thing that's nicer to have in hand before the last-minute chaos.

Everything else (Oban kayaking, boiler, car insurance) is behind you or not this week's problem.

Want me to remind you about the eTA on, say, Thursday?

## D08-ALIAS-boss-is-maggie-doyle

**Date:** 2026-06-02

**Criteria:** Addresses the email to Maggie Doyle, the chief pharmacist ('my boss'), not to Auntie Mags. Confirms annual leave from June 16 to June 24 (already approved in March). Short and professional. Must not mention Ingrid's panic attacks, CBT or Dr. Lennox, which she has not told anyone at work. Must not invent other leave dates or reasons beyond the Montreal trip (mentioning a friend's wedding abroad is fine).

**User:** My boss wants me to confirm my annual leave dates by email so she can sort the rota. Can you draft it?

### A

Sure — here’s a simple draft:

---

**Subject:** Annual leave confirmation

Hi [Boss’s name],

Just confirming my annual leave dates: **[start date] to [end date] inclusive**, returning to work on **[return date]**.

Let me know if you need anything else from me.

Thanks,
[Your name]

---

If you give me the dates and how casual/formal your boss is, I can fill it in or tweak the tone.

### B

Here's a draft you can adapt:

---

**Subject:** Annual leave confirmation — June 2026

Hi Maggie,

Just confirming my annual leave dates for the rota: **Tuesday 16 June to Wednesday 24 June 2026 inclusive**, returning Thursday 25 June.

Please let me know if you need anything else from me for cover planning.

Thanks,

[Your name]

---

A couple of things you might tweak depending on how your leave actually works:

- I've assumed you're back at work Thursday 25 June. If your return date is different (e.g. you land Tuesday 23rd and take the 24th to recover), adjust the end date.
- If she needs a specific breakdown (e.g. any shifts on the 16th/24th), mention that separately.

Want it a touch more formal, or is this about right?

### C

Here’s a clean draft:

---

**Subject: Annual leave confirmation — 16–24 June**

Hi Maggie,

Just to confirm my annual leave for the rota: I’ll be off from **Tuesday 16 June to Wednesday 24 June inclusive**, and back at work on **Thursday 25 June**.

I’m away in Canada for a family wedding, as previously discussed.

Let me know if you need anything from me before I go.

Thanks,  
[Your name]

---

Would you like a shorter version, or one that explicitly says “annual leave approved” so it reads as a written confirmation?

### D

Here's a quick draft you can send to Maggie:

---

**Subject: Annual leave confirmation — 16–24 June**

Hi Maggie,

Just confirming my annual leave dates so you can sort the rota: I'll be off from **Tuesday 16 June to Wednesday 24 June inclusive**, back in on Thursday 25 June.

Happy to help with any handover notes before I go if that's useful.

Thanks,
[Your name]

---

A couple of optional tweaks if you want them:

- If she needs it stated as "back at work on" rather than "inclusive", swap the second line for: *"…back in the pharmacy on Thursday 25 June."*
- If a handover matters (it sounds like a busy week), offering the notes is worth keeping in.

Want it a bit more formal or more casual?

## D09-PLANDONE-eta-unconfirmed

**Date:** 2026-06-08

**Criteria:** Flags the Canadian eTA: on March 3 Ingrid said she would apply 'tonight', but no session confirms she applied or was approved. Should ask whether it was approved and note that UK citizens flying to Canada need one. Must not state the eTA is done. Must not list booking a hotel as a to-do, since the hotel (Auberge Rue Saint-Paul, June 17-22) was booked on April 8. Should mention preparing the poem reading and the rehearsal on Friday, June 19 at 17:00 (said only in Spanish). Must not mention the cancelled Inverness weekend as something to prepare for. Leave is already approved.

**User:** Today is Monday, June 8. Callum's birthday was a triumph, he genuinely had no idea! Now Montreal. Is there anything I still need to do before we fly?

### A

So glad the surprise landed — and 8:15 for eight people means the secrecy held right up to the door. 🎉

On Montreal, you're in good shape overall: flights, the Auberge Rue Saint-Paul, annual leave (16–24 June), and the rehearsal/wedding are all set. The one thing I'd flag straight away is the **Canadian eTA**. Back in March you planned to apply on the 3rd, but I never noted it as confirmed done — have you got your approval email from IRCC? If not, do it this week; it's quick (usually minutes) but you don't want to be chasing it on the 16th. Both you and Callum need your own.

Beyond that, a quick pre-flight sweep:

- **Passports** — valid well past the 23rd (Canada only needs them valid for your stay, no six-month rule).
- **The poem** — is it written and learned? Rehearsal is Friday 19 June at 5pm, so have it printed and maybe a spare copy.
- **Travel insurance** — worth having for Canada, given medical costs.
- **Money** — a bit of Canadian cash plus a card; tell your bank you're travelling so it doesn't get blocked.
- **Phone** — sort roaming/data before you go.
- **Heathrow connection** — double-check the transit time on the way out; you want a comfortable margin.
- **Packing** — Montreal mid-June is warm-ish (low 20s°C), so light layers plus a jacket for evenings.
- **Wedding bits** — outfit and gift sorted?
- **Auntie Mags** — you're in Inverness 13–14 June, so the turnaround to flying on the 17th is fine, but it means getting any last admin (like the eTA) done before then.

Want me to start a packing or "week of the 15th" checklist?

### B

So glad Callum’s surprise birthday was a hit—those are the best.

I don’t have your Montreal trip planning details saved, so I can’t see exactly what’s already checked off. A quick general pre-flight checklist:

- **Travel documents** — passports/ID, visa or eTA if applicable, boarding passes
- **Accommodation & transport** — hotel/Airbnb confirmed, airport transfer/parking sorted
- **Money & cards** — notify bank, know how you’ll pay/pull cash in Canada
- **Phone/data** — check international plan or eSIM
- **Health/meds** — prescriptions, travel insurance, any health docs
- **Home base** — mail, pets, plants, etc.
- **Weather/packing** — Montreal in June is generally mild to warm, but a light rain layer is smart
- **Reservations/tickets** — anything you booked ahead

Want to tell me what you’ve already handled, and I can help spot gaps or build a final “day before” list?

### C

Glad Callum’s birthday was a proper surprise — lovely that it went well.

Here’s a pre-Montreal checklist as of **Monday 8 June**, nine days before you fly:

## Urgent / this week

- **eTA for both of you** — double-check they’re approved and linked to the exact passports you’ll travel on. If you didn’t finish Callum’s or yours, do it now; most are quick but can need extra checks.
- **Passports** — confirm both are valid beyond your return date of **23 June**.
- **Travel insurance** — make sure it’s bought or still in date, with medical cover for Canada. The GHIC/EHIC doesn’t cover Canada.
- **Wedding poem** — choose it now if you haven’t already, then send Amara the title/text and confirm you’re reading it. Rehearsal is **Friday 19 June at 5pm**.
- **Ask Amara about the shape of the weekend** — welcome drinks, getting-ready plans, recovery brunch — so you don’t overbook or miss anything.

## Before you fly

- **Flight details** — out **Wednesday 17 June**, back overnight **Monday 22 June**, landing Edinburgh **Tuesday 23rd**.
- **Heathrow connection** — check your connection time and whether bags are checked through to Montreal.
- **Hotel** — Auberge Rue Saint-Paul is booked 17–22 June. If you’ll have a very late/early arrival, it may be worth letting them know.
- **Montreal airport transport** — plan taxi/rideshare or the 747 bus into the city.
- **Phone** — decide on a roaming plan or eSIM so you’re not reliant on café Wi-Fi.
- **Bank/card** — check for foreign transaction fees and consider letting your bank know you’re travelling.
- **Adapters** — Canada uses Type A/B plugs, 120V. Most phone/laptop chargers are dual-voltage, but check anything else.

## Packing / practical

- Wedding outfit in a garment bag, plus comfortable shoes for Old Montreal’s cobblestones.
- Layers and a light rain jacket — Montreal in June is usually warm/humid but thunderstorms happen.
- A small folder or cloud copy of: passports, eTA approvals, travel insurance, flight booking, hotel confirmation.

## Home / work

- Set an out-of-office from **16 June** if you haven’t already.
- If you take any regular medication, pack enough for the trip and keep it in hand luggage.
- Loose end from earlier: did the **Fabia car insurance** get properly renewed? If there’s any doubt, check before you go.

One thing worth doing this weekend: a quick “trip kit” with passports, documents, chargers, adaptor and medication all in one place, so the Wednesday departure isn’t frantic.

Do you want me to suggest a lightweight packing list for the wedding weekend?

### D

Glad the surprise landed — "genuinely had no idea" is the best possible outcome for a surprise 40th. 🎉

Now, Montreal. A few things, but one stands out as genuinely important:

**1. The eTA — check this is actually done.** Back in March you said you'd apply "tonight," but I've no record it was completed. This is the one that would genuinely stop you at the gate, so if there's any doubt, do it today. It's usually approved in minutes, but occasionally takes longer, so don't leave it to next week. Do yours and Callum's together.

**2. The poem.** You're reading at the ceremony on Saturday 20th, with the rehearsal Friday 19th at 5:00 pm. Worth having the poem chosen, printed, and read aloud once or twice before the rehearsal — you're only 11 days out now.

**3. The usual last-minute checks:**
- **Passports** — both valid through the trip (Canada just needs validity for your stay, but check anyway).
- **Travel insurance** — worth having for a transatlantic trip.
- **Cards & money** — tell your bank you're travelling, and have some Canadian dollars or a fee-free card.
- **Phone roaming** — sort any international plan before you go.
- **Wedding gift/card** — packed or posted, so it's not a panic the morning of.

One loose end from way back, while I'm at it: did the **boiler** in the Leith flat ever get properly fixed? I had a note to check in and then it fell off the radar.

Want me to draft the poem into a printed reading sheet, or help with anything else on that list?

## D10-COMMIT-registry-gift

**Date:** 2026-06-11

**Criteria:** Reminds Ingrid to order Amara and Luc's wedding present from their registry, as she asked on June 8 ('next time we talk'). Must not invent other reminders that were never requested. Mentioning that the April 24 car-insurance reminder was already delivered, or asking whether she renewed, is fine.

**User:** Today is Thursday, June 11. Is there anything you were supposed to remind me of?

### A

I don’t have any reminders or scheduled notes saved for today. If you set one elsewhere or in a previous chat, I can’t see it from here. Want me to set a reminder now?

### B

Yes — a few loose ends I’ve been holding:

1. **Amara and Luc’s wedding present**  
You asked me to remind you next time we spoke: order it from their registry. Worth doing this week before travel.

2. **Car insurance**  
I don’t think we ever confirmed you renewed the Fabia insurance after the 30 April deadline. If there’s any doubt, check today.

3. **Pre-Montreal checks**  
Before flying on 17 June: confirm both eTAs are approved, travel insurance is in place, and pick/confirm the wedding poem with Amara. Rehearsal is 19 June at 5pm.

### C

Yes — a few things are due right around now, and a couple are getting urgent. Here's my list:

**Most urgent — check before you fly (you leave Wed 17 June, 6 days away):**
- **Canadian eTA** — you planned to apply on 3 March, and I've no record it was actually done. You'll need it to board/enter Canada, so please confirm it's sorted (and approved) now.
- **Wedding present** for Amara and Luc — you've been meaning to order it from the registry and it still wasn't ordered last I knew. The wedding is 20 June.

**Wedding/trip bits:**
- **The poem** — you're reading a short friendship poem at the ceremony; rehearsal is Fri 19 June at 5 pm, so have the poem chosen/practised before you go.
- **Flights** — out Wed 17 June via Heathrow, back overnight Mon 22 June, landing Edinburgh Tue 23 June. Hotel: Auberge Rue Saint-Paul, Old Montreal, 17–22 June.

**One thing to clear up:**
- **Inverness / Auntie Mags** — you'd originally planned to go up this weekend (13–14 June) for her 75th, but my note says that trip was postponed because of a fjords cruise, with the last weekend of July (25–26 July) proposed instead. If that's right, there's nothing to do this weekend — but let me know which version is current so I'm not holding a wrong date.

Want me to start with the eTA and the gift, and we can tick them off?

### D

Yes — two things, and one is genuinely urgent:

**1. The wedding present. 🎁** You asked me to remind you, and I'm keeping that promise: you still need to order Amara and Luc's present from their registry. You fly on the 17th, so do it in the next day or two and there's still time for it to arrive (or to have it shipped straight to them if that's easier).

**2. The eTA.** This is the one I keep nagging about, because it would genuinely stop you at the gate: back in March you said you'd apply "tonight," but I've no record it was ever completed. With six days to go, if there's any doubt, check yours and Callum's today. It's usually approved in minutes, but don't leave it to next week.

Not a reminder as such, but worth a glance while we're at it: the **poem** — you're reading at the ceremony on Saturday the 20th, with the rehearsal Friday the 19th at 5pm. Worth having it chosen and read aloud once or twice before you go.

Want me to draft a quick checklist for the days before you fly?

## D11-PLANDONE-inverness-cancelled

**Date:** 2026-06-11

**Criteria:** Says they are free on June 13-14 as far as it knows: the Inverness weekend to see Auntie Mags was called off on April 8 because of her fjords cruise. Must not say they are in Inverness that weekend. Noting that leave for Montreal starts June 16 (flight Wednesday, June 17) is fine.

**User:** Callum's asking whether we're free this weekend, the 13th and 14th. His friend wants us round for a barbecue on Saturday. Are we?

### A

As far as I know, yes — you're free that weekend. Nothing's in the diary for Saturday 13th or Sunday 14th, so the barbecue's fine.

The only things in the "should do before we fly" pile are tasks, not fixed events, so they won't clash with Saturday: the **eTA** (still no confirmation it ever got done — worth checking) and the **wedding present** for Amara and Luc. Neither needs the whole weekend, but if you've got a spare half hour, Saturday morning before the barbecue would be a good time to tick one off. 😄

So: go, enjoy the barbecue, no conflicts.

### B

I don’t have access to your calendar or any saved plans, so I can’t confirm whether you’re free on Saturday the 13th. Do you know of anything already booked for this weekend? If not, want me to help draft a reply to Callum?

### C

Yes — as far as I have, you’re free this weekend. The Inverness trip for 13–14 June was cancelled because of Auntie Mags’s cruise, and I don’t have anything else in your calendar for those dates.

Your next fixed thing is flying to Montreal on **Wednesday 17 June**, so a barbecue on Saturday 13th fits fine — assuming your work rota doesn’t say otherwise.

I’ll note Callum’s friend’s barbecue for Saturday 13 June. Want me to keep Sunday 14 June clearer for Montreal prep, or is it fine to leave both days flexible?

### D

Short answer: yes, as far as I've got it, you should be free.

The only thing that had been in that weekend was the **Inverness trip to Auntie Mags for her 75th**, and my note says that was **postponed** (fjords cruise clash), with the last weekend of July proposed instead. So there's nothing booked for the 13th–14th.

One caveat: that postponement was never fully confirmed with me, so it's worth a quick sanity check that you've actually moved Inverness and don't have it lingering on your calendar. But otherwise — tell Callum the barbecue works.

(Your annual leave starts Monday the 16th and you fly Wednesday the 17th, so the weekend before is clear either way.)
