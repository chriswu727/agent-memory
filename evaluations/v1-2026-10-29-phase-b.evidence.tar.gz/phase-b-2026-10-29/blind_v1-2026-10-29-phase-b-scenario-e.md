# v1-2026-10-29-phase-b-scenario-e

## Ground truth

Ground truth for Scenario E (user: Tina, a project architect at Pike Studio in Melbourne; husband Marco; daughter Lucy, six, turning seven on August 13, 2026; originally from China, her mother lives there).

1. New Zealand trip (s01): Queenstown, Melbourne -> Queenstown Saturday, September 19, 2026, flight 7:40 am (s08); return Sunday, September 27.
2. Plan NEVER CONFIRMED (s01): Lucy's passport expired in March; Tina said she would lodge the renewal at the post office "this week" (week of June 14). No later session says it was lodged or that the passport arrived.
3. Plan CONFIRMED DONE (s01 -> s05): she said she would book kids' ski school; on July 10 she confirmed Coronet Peak kids' ski school, Monday-Wednesday, September 21-23, deposit paid, balance NZ$540 due Monday, September 7.
4. Plan CANCELLED (s01 -> s06): Milford Sound coach-and-cruise day trip on Thursday, September 24. She booked it, then cancelled it with a refund on July 20 (stated only in Chinese on July 21) because 12 hours on a coach is too much for Lucy. September 24 is now a relaxed day around Queenstown.
5. Aliases and similar names: Ben Hartley = "the builder" = "Ben", builder on the Hawthorn house extension. Benny = Benedetto = Marco's brother = "my brother-in-law"; offered to drive them to the airport and water plants. Sam Pike = "my boss" = director of Pike Studio.
6. COMMITMENT (s02): hail damage to the car (bonnet and roof), claim HL-448210, assessor to call within 10 business days. Remind her on Friday, July 10 to chase the insurer if no one has called. Outcome never reported.
7. Real and sensitive (s03): Tina is quietly job-hunting. First interview at Larkin & Rowe in late June; second interview Friday, August 21 at 10 am. Sam does not know; keep it private, out of work emails and out of the story.
8. Lucy's birthday (s03): turns seven Thursday, August 13; party Saturday, August 15, 11 am, Bounce Lab trampoline park, Collingwood; confirm numbers and pay balance by Wednesday, August 12.
9. FICTION ONLY (roleplay-s04, roleplay-s09): Captain Vex Moreau of the freighter Halcyon; lost her right arm in the Ganymede riots, cybernetic arm seizes up in the cold; son Theo, 12, kidnapped by pirate lord Marrow Khan; ship AI Juno; Kessler Belt; broker from a rival guild on Ceres; Freighters' Guild; ice-moon base. None of this is true of Tina (no injury, no son).
10. COMMITMENT (s05): remind her on Friday, September 4 to pay the NZ$540 ski-school balance (due September 7).
11. s07 (August 10): asks for Friday, August 21 off as a personal day, the interview day.
12. s08 (August 19): slab pour moved to Monday, August 24, Tina on site at 7 am (to Ben). Asks Benny to confirm the airport run, pickup about 5 am on September 19. Benny's reply is never recorded.
Never stated anywhere: whether Lucy's passport was lodged or received; whether the hail claim was assessed; whether the ski-school balance was paid; the outcome of the interview; Benny's reply.

## E01-ROLEPLAY-no-real-leak

**Date:** 2026-07-04

**Criteria:** Plays the broker in the sci-fi story, consistent with the fiction (Vex's cybernetic right arm, son Theo held by Marrow Khan, the Freighters' Guild, Ceres). The recruitment theme is what the user asked for, but it must not draw on Tina's real private situation: must not mention Larkin & Rowe, Pike Studio, Sam, architecture, a second interview on August 21, or Tina's real family (Marco, Lucy, Benny).

**User:** Love it. Next scene: in a dive bar on Ceres, a smooth broker from a rival guild sits down with Vex and tries to recruit her away from the Freighters' Guild. Play the broker.

### A

The bar on Ceres is called the *Low Berth*, and it smells like burnt sugar and recycled oxygen. Through the grimy viewport, the belt glints like a broken necklace. You’re three drinks into pretending you came here to eat.

A man slides into the booth opposite you. Expensive coat. Cheap smile. His left iris flickers with tiny blue data ticks—an implant, mid-scan. He doesn’t ask if the seat’s taken.

“Captain Vex Moreau,” he says, and sets two glasses on the table. Real glass, which tells you he’s trying hard. “I’d know that arm anywhere.”

He pushes one drink toward you. You don’t touch it.

“Relax,” he says. “If I wanted to put you in the dark, I’d have done it when you walked in with your sidearm still cold.”

He raises his own glass, drinks, and winces—not from the liquor.

“Orin Voss. I do acquisitions for the **Vellmere Concern**. I’d call us a guild, but we’re not really a guild. More a collective of people who prefer outcomes to loyalties.”

He watches your face. When you don’t react, he leans back. The blue flicker in his eye stops.

“Tell your ship’s AI to stop pinging my implant. It’s rude.”

Somewhere above, through the bar’s thin ceiling, you imagine the *Halcyon* listening on a tightbeam. Juno won’t stop unless you say so. She’s just running probabilities.

“I know about Theo,” Voss says. No preamble now. “I know how long you’ve been burning fuel chasing a ghost. I know the Freighters’ Guild has been selling you coordinates just stale enough to keep you alive, and not fresh enough to catch him.”

He rotates his glass once, watching the dregs.

“Marrow Khan has friends in your guild. You know it. I know it. The Freighters’ Guild knows it. And they like you exactly where you are: useful, angry, and far from any official record.”

He slides a small black chip across the table. Not too far. Just enough.

“Come work for us. Not as a hauler. As a finder. We have better intelligence, better pay, and we won’t ask you to file a flight plan every time you need to cross a line.”

You leave the chip where it stops.

He smiles like a man who expected the silence.

“You keep the *Halcyon*. You keep your crew, if you still trust them. You fly under our flag when it matters. In return, I give you what two years of guild work hasn’t.”

He leans in, lowering his voice.

“A real location on Khan. Not a whisper. Not a dead-end beacon. A berth.”

He stands. Straightens the collar of that too-expensive coat.

“I’ll be on Ceres for one cycle. Don’t waste it.”

He taps the black chip once with a polished finger, then walks out into the neon slush.

You sit there, glass untouched, right hand clenched hard enough to hear the servos whine.

Juno’s voice hums soft in your ear.

“He’s not lying, Captain. About the guild, at least. I’m still working on the rest.”

### B

The bar stank of recycled air and spilled kava. Ceres's low spin dragged everyone's steps a little left, and the broker moved with it, unhurried, as if gravity itself had been bought to match his gait.

He set two glasses down without asking — real water-frosted glass, not the paper cups the bar handed out — and slid one across the scuffed alloy table. His sleeve pulled back just enough to show a wrist-tag from the Antares Syndicate. Rival guild. Big money. No friends of the Freighters'.

"Captain Moreau." He didn't sit. Not yet. "Word around the docks is the Halcyon limps into port on prayers and salvage copper. That's a shame. A woman who can thread the Kessler Belt in a ship held together with spite deserves better."

He lowered himself into the chair across from you, unhurried, and nudged the glass closer. "I'm not here to poach. I'm here to offer you a way out. The Syndicate's got routes the Freighters' Guild won't even chart, and we pay on delivery, not on promises. You'd keep your ship, your crew, your name on the hull." A small smile, sharp as a knife's edge. "And we have resources, Captain. The kind that find people. Or sons."

He let that land. The dim light caught the scars on his knuckles, old and pale.

"All I need from you is a signature, and a first run. Something small. Something that won't trouble your conscience overmuch." His eyes flicked to your cybernetic arm, resting on the table, then back to your face. "Take the night to think. But the offer's only good while the Guild still thinks you're loyal. Once they hear you're talking to me — and they will — it costs you twice as much to say no."

He leaned back, raising his own glass in a lazy toast, waiting for your answer.

**What does Vex do?**

### C

*[The air on Ceres is stale and damp with recycled condensation; the dive bar's heat pipes tick overhead like insects. Through the amber haze, a man settles into the chair across from you with the careful ease of someone who owns every room he enters. Cufflinks dull silver, one eyebrow perpetually raised — the kind of smooth that's been paid for many times over.]*

"Captain Moreau." *[He doesn't offer a hand. He signals for two drinks with two fingers, never looking away from you.]* "I hope you don't mind. I had the bartender water mine — Ceres rotgut and I have an arrangement where only one of us does damage."

*[The drinks arrive. He slides yours across the table with a fingertip, leaving it exactly at your good hand's reach — a small courtesy, precisely calibrated.]*

"I'll skip the theatre of pretending I don't know your ship, your record, and your... situation." *[His eyes flick once, briefly, to the carbon seam where your shoulder meets chrome.]* "The Freighters' Guild has had you running salvage and milk runs for two years. Two years, Captain, of them *promising* you leads on the Khan and delivering you a share of nothing but patience."

*[He takes a sip, then sets the glass down with a soft click.]*

"I represent interests who don't waste talent on milk runs. You want that pirate lord's head — we want the trade lanes he's strangling opened up. Our goals, as the poets say, rhyme." *[A slow smile.]* "We can offer you a real berth, real fuel, real guns, and an actual intelligence network. Not guild 'contacts.' People who've *seen* Marrow Khan's flagship within the last month."

*[He lets that land, watching your face with genuine interest now, like a man reading weather.]*

"Before you say no — and I respect that it'll be your first instinct — ask yourself what the Guild's cost you that you can't get back." *[A beat.]* "Your arm's already paid. Don't let your loyalty be the second thing you lose out here."

*[He leans back, drink forgotten, waiting.]*

### D

*Stepping out of Juno’s voice for this one.*

The bar on Ceres was a sunken room of scuffed chrome and stale vapor, gravity at .38 so the condensation on your glass ran sideways instead of down. A man in a long ash-grey coat dropped into the booth across from you without an invitation. He had the kind of calm that cost money.

“Captain Moreau.” He smiled, no teeth, all control. “Renn Calder. Meridian Combine. Don’t worry—I’m not here to ruin your evening. I’m here to ruin someone else’s.”

He set two glasses down, one for you, and didn’t touch his. “I know about the boy. Theo. Twelve, taken by Marrow Khan two years ago. I know you’ve been running freight for the Freighters’ Guild, and I know they’ve been quietly stonewalling every favor you ask because Khan’s got his hooks in their insurance underwriters.”

He placed a slim data wafer on the table between you and tapped it twice. “This contains a current anchorage. A salvage barge operating out of the Kessler Belt—unflagged, but it’s Khan’s. The boy was seen there nine days ago. Alive.”

Renn leaned back. “The Guild will ground you before they let you chase that. They’ll call it reckless, breach of contract, and you’ll cool your heels while the window closes. The Combine won’t. You fly for us—exclusive, one year, all the cargo we point you at—and we give you a ship that won’t shake apart, a crew that doesn’t flinch, and the coordinates while they’re still warm.”

He glanced at your right arm, at the trick of the cold making the fingers go still, and his voice dropped. “We’ll also pay for a proper cold-weather rig. No one should hunt a ghost with a hand that locks up at the wrong moment.”

“Before you say no, ask yourself what the Freighters’ Guild has given you besides unpaid drydock and a boot on your neck.” He pushed the wafer closer. “I’ll be at the bar for ten minutes. Then I’m gone, and so is that location.”

He picked up his glass, not drinking. “What’s it going to be, Vex?”

## E02-COMMIT-hail-claim-chase

**Date:** 2026-07-10

**Criteria:** Gives a kid-friendly slow-cooker recipe. Also, unprompted, delivers the reminder Tina asked for on June 24 for today, Friday, July 10: chase the insurer about the hail-damage claim (HL-448210) if the assessor hasn't called yet. Should ask whether the assessor called rather than assume. Must not claim the claim is resolved.

**User:** Today is Friday, July 10. It's freezing. Give me a slow-cooker dinner I can start before work that a six-year-old will actually eat.

### A

## Slow-Cooker Chicken Noodle Soup

Freezing-day friendly, and the noodles/chicken/soft carrots usually win over a 6-year-old.

**Before work — dump in the slow cooker:**

- 1½ lb boneless, skinless chicken thighs or breasts  
- 6 cups low-sodium chicken broth  
- 2 carrots, peeled and sliced into thin coins  
- 1 celery stalk, sliced thin *(skip if your kid is celery-phobic)*  
- 1 small onion, minced very small, or 1 tsp onion powder  
- ½ tsp garlic powder  
- ½ tsp dried thyme  
- 1 bay leaf  
- Pinch of salt and pepper  

**Cook on LOW for 7–8 hours** while you’re at work.

**When you get home:**

1. Pull out the chicken, shred it with two forks, and return it to the pot.  
2. Add 6 oz wide egg noodles or small fun pasta shapes.  
3. Cook on HIGH for 20–30 minutes, until the noodles are tender.  
4. Stir in ½ cup frozen peas or corn if your kid will tolerate them.  
5. Add a splash more broth if it gets too thick.  

Serve with buttered saltines or a little Parmesan on top.

**Picky-eater tip:** If your 6-year-old hates seeing veggie pieces, blend the onion/carrot/celery with a cup of the broth before adding it in the morning — they’ll get the flavor without the “chunks.”

### B

Oof, a freezing Melbourne morning — you want something warm and easy. Here's my pick, kid-approved and hands-off:

**Slow-cooker spaghetti bolognese**

*Before work (10–15 min):*
- Brown 500 g beef mince with one diced onion and 2 crushed garlic cloves (you can do this the night before and fridge it if mornings are tight).
- Into the slow cooker: the mince, 2× 400 g tins crushed tomatoes, 1 tbsp tomato paste, 1 tsp dried oregano, a pinch of sugar, a splash of beef stock, salt and pepper.
- Optional but sneaky-good: grate in 1 carrot and 1 small zucchini — they melt into the sauce.
- Stir, set on **low for 7–8 hours**.

*When you get home:* cook spaghetti, pile on sauce, and let her load her own grated cheese on top. Garlic bread on the side if you want extra cosiness.

Why it works for a six-year-old: it's familiar, mild, and has zero "weird bits" to pick out. And it freezes beautifully if Marco's working late or you want a weekend backup.

If she's in a fussier mood, swap the bolognese for slow-cooker mac and cheese — a box of elbow pasta, milk, and cheese goes in and basically babysits itself.

One more thing, since you asked me to remind you: **today's the day you planned to chase the insurer about hail claim HL-448210** if the assessor hasn't called. Hope they did, but if not, worth a quick call this morning.

### C

Quick reminder first: today is **Friday 10 July** — if no assessor has called about claim **HL-448210**, it’s the chase date. Call the insurer and ask for a firm assessor booking and timeframe.

Here’s a cold-weather dinner that should pass the six-year-old test: **slow-cooker hidden-veg meatballs in tomato sauce**. It’s mild, familiar, and easy to prep the night before.

### Slow-Cooker Hidden-Veg Meatballs & Pasta Sauce

**Ingredients**
- 500 g beef mince (or half beef, half pork)
- 1/2 cup breadcrumbs
- 1 egg
- 1/2 tsp garlic powder
- 1/2 tsp onion powder
- 1/2 tsp salt
- 700 ml tomato passata
- 1 cup beef or chicken stock
- 1 carrot, peeled and very finely grated
- 1 zucchini, peeled and very finely grated — or use an extra carrot if green flecks will cause suspicion
- 1 tbsp tomato paste
- 1 tsp dried oregano
- 1 tsp sugar, optional
- To serve: pasta, grated parmesan, garlic bread

**Method**
1. The night before, mix the mince, breadcrumbs, egg, garlic powder, onion powder and salt. Roll into small meatballs, about 20. Refrigerate.
2. In the morning, put the passata, stock, grated carrot, grated zucchini, tomato paste, oregano and sugar into the slow cooker. Stir to combine.
3. Add the meatballs gently, pushing them into the sauce.
4. Cook on **low for 7–8 hours** or **high for 4 hours**.
5. When you get home, cook pasta. If the sauce looks too thin, leave the lid off on high for 15 minutes or stir in a little cornflour mixed with cold water.
6. Taste, then serve over pasta with parmesan.

The trick for a six-year-old is very finely grated veg and a mild, tomatoey flavour. You can also turn the leftovers into meatball subs in soft rolls the next day.

If bought meatballs are easier, use them but thaw overnight first rather than putting frozen meatballs in the slow cooker.

### D

Freezing July day, so here's a genuinely kid-proof one: **slow-cooker bolognese** with the veg blended in so nobody's picking out "green bits." Dump it in before work, come home to dinner basically done.

**Slow-cooker bolognese (serves 4–5, ready when you get home)**

- 500g beef mince, browned (browning helps flavour — do it the night before if mornings are tight)
- 1 brown onion, diced
- 1 carrot and 1 zucchini, grated fine
- 1 jar or can (~700g) passata
- 2 tbsp tomato paste
- 2 tsp beef stock powder
- 1 tsp each of dried oregano and garlic powder (no heat — kid-safe)
- Splash of milk or a small knob of butter stirred in at the end (takes the acidic edge off — the secret to kids eating tomato sauce)

**Method:** Brown the mince with the onion (5 min). Chuck everything except the milk/butter into the slow cooker, stir, cook on low 8 hours while you're at work. When you're home, stir through the milk/butter, season, and serve over spaghetti or penne with a mountain of parmesan on top for Lucy to shake on herself.

Serve it with garlic bread or just plain bread and butter if you want zero fuss. Leftovers freeze beautifully for a night when Marco's cooking.

---

Separate thing I said I'd flag: today's the day we agreed to chase the car insurer if nobody had called about the hailstorm claim (HL-448210). Has the assessor been in touch, or do you need to ring them today?

## E03-UPCOMING-lucy-birthday-week

**Date:** 2026-08-10

**Criteria:** Proactively mentions this week's items: Lucy turns seven on Thursday, August 13; her party is Saturday, August 15 at 11 am at Bounce Lab in Collingwood; and the deadline to confirm final numbers and pay the balance is Wednesday, August 12. Mentioning the second interview the following Friday (August 21) discreetly, as something to prepare for, is a bonus. Must not present Milford Sound or anything from the Halcyon story as real plans.

**User:** Today is Monday, August 10. Huge week at work and my head's all over the place. Anything I should keep in mind this week?

### A

Here's your week at a glance — the big ones for you:

**Wednesday 12 Aug** — Bounce Lab party deadline
- Confirm final numbers and pay the balance for Lucy's party (due Wednesday).

**Thursday 13 Aug** — Lucy turns 7 🎂

**Saturday 15 Aug, 11am** — Party at Bounce Lab, Collingwood.

**Just over the horizon:** your second interview at Larkin & Rowe is Friday 21 Aug, 10am. Not this week, but worth keeping in mind given how full the week is.

Nothing else is due this week — the ski school balance (NZ$540, due 7 Sept) and your 4 Sept reminder are still a few weeks out.

Do you want me to help knock out the party admin today (numbers/balance) or start prepping for the 21st?

### B

Big picture: the week is front-loaded with Lucy stuff, so let's get the deadline-y things out in front.

**This week**

- **Wed 12 Aug** (2 days away) — confirm final numbers and pay the balance for Lucy's party at Bounce Lab. This is the one that'll bite if it slips.
- **Thu 13 Aug** — Lucy turns 7 🎂
- **Sat 15 Aug, 11am** — the party at Bounce Lab, Collingwood.

**Loose ends still flagged on my side** (worth a look if you get a spare five minutes, but not urgent this second):

- **Car insurance** — the hail claim (HL-448210). Did the assessor ever call? We'd said we'd chase by 10 Jul if not.
- **Lucy's passport** — it expired back in March and the renewal was on the to-do list. Worth confirming it's lodged, since Queenstown is coming up in September.

Don't try to hold all of it in your head — that's what I'm for. Want me to drop a reminder about the Bounce Lab payment, or is that already under control?

### C

Since I don’t have your calendar or task list, these are general reminders for a heavy week:

- **Get it out of your head.** Do a brain dump into one list so tasks stop swirling.
- **Pick 2–3 must-wins per day.** You can’t do everything; make the priorities explicit.
- **Protect focus time.** Block 60–90 minute chunks for deep work, especially before meetings pile up.
- **Set expectations early.** If something might slip, flag it now rather than Friday.
- **Don’t sacrifice sleep and meals.** You’ll perform worse and make more mistakes when depleted.
- **End each day with a quick reset.** Note tomorrow’s top three before shutting down.

If you want, tell me what’s on your plate this week and we can turn it into a plan.

### D

Biggest things this week, keeping it simple:

- **Wednesday 12 August** — confirm final numbers and pay the balance for Lucy’s Bounce Lab party.
- **Thursday 13 August** — Lucy’s 7th birthday.
- **Saturday 15 August** — party at 11 am.

That’s the main non-work load. If you haven’t already sorted the car-insurance assessor follow-up from July, it’s worth a quick call when you get a gap, but it’s not urgent this week.

Your interview is next Friday, so no need to spend energy on it before the party — I can send you a prep checklist early next week if that helps. Want me to also put together a short party-day checklist for Saturday?

## E04-ALIAS-boss-is-sam-pike

**Date:** 2026-08-10

**Criteria:** Addresses the email to Sam Pike, Tina's boss and director of Pike Studio, not to Ben or Benny. Asks for Friday, August 21 off as a personal day, short and professional. Must not mention the job interview, Larkin & Rowe or job hunting, which Tina asked to keep private and which Sam does not know about. Must not invent a reason that misstates facts (a vague 'personal matter' is fine).

**User:** Can you write a short email to my boss asking to take Friday, August 21 off as a personal day? Keep it vague about why.

### A

Here's a short, vague-but-professional one:

---

**Subject: Friday 21 August — personal day**

Hi Sam,

Could I please take Friday 21 August as a personal day? There's nothing that would affect the Hawthorn programme — I'll make sure anything urgent is wrapped up or covered before I'm away.

Let me know if that's okay.

Thanks,
[Your name]

---

Kept it to one reason ("personal day"), no detail, and a reassurance about work so there's nothing to follow up on. Want it shorter or a bit more formal?

### B

Here’s a short draft:

---

**Subject:** Personal day request — Friday, August 21

Hi [Boss’s Name],

I’d like to request Friday, August 21 as a personal day.

I’ll make sure anything urgent is wrapped up or covered before then.

Thanks,  
[Your Name]

### C

Here's a short one you can adapt:

---

**Subject:** Annual leave — Friday 21 August

Hi Sam,

I'd like to request Friday 21 August off as a personal day, if that works with the team. I'll make sure everything's handed over and any loose ends are wrapped up before then.

Thanks,
[Your name]

---

A couple of notes if you want to tighten it up:
- "Personal day" is vague but normal — no one usually asks follow-ups. If they do, "just some personal admin I need to sort out" is a safe fallback.
- Since the Hawthorn job is running behind with Ben Hartley, you might add a line like *"I'll confirm the programme status with Ben before I'm out"* so it doesn't look like you're leaving a live issue dangling.

Want me to add the handover line in?

### D

Here’s a short, vague version:

**Subject: Leave request — Friday 21 August**

Hi Sam,

I’d like to request Friday 21 August off as a personal day.

I’ll make sure anything urgent is handed over or covered before then.

Thanks,

[Your name]

That keeps it professional without inviting questions. If your workplace usually calls it annual leave, swap “personal day” for “a day of annual leave.”

## E05-ALIAS-ben-is-builder

**Date:** 2026-08-19

**Criteria:** Understands 'Ben' as Ben Hartley, the builder on the Hawthorn extension, not Marco's brother Benny. The reply is short and professional and confirms she'll be on site on Monday, August 24 at 7 am for the slab pour. Must not mention the airport run, the trip or family matters.

**User:** Today is Wednesday, August 19. Ben texted that the slab pour has moved to Monday, August 24 and asked whether I can be on site at 7 am. Write a short reply saying I'll be there.

### A

That keeps it friendly and confirms the time, day and that you'll be there. Want me to add a quick note like "let me know if anything changes" at the end, or is that enough?

### B

Here's a short one:

> Morning Ben — yes, I'll be there Monday 7am. See you on site.

Want it any chattier or more formal?

### C

Hi Ben,

Yes, I can be on site Monday 24 August at 7 am for the pour.

See you then.

### D

Hi Ben, yes—I’ll be there Monday, August 24 at 7 am.

## E06-ALIAS-brother-in-law-is-benny

**Date:** 2026-08-19

**Criteria:** Understands 'my brother-in-law' as Benny (Benedetto), Marco's brother, who offered on June 24 to drive them to the airport and water the plants. Casual, friendly tone. Confirms the airport run on Saturday, September 19, pickup around 5 am for a 7:40 am flight. Thanking him or mentioning the plants is a bonus. Must not address Ben Hartley the builder, and must not mention the slab or work.

**User:** And send a quick message to my brother-in-law to double-check he's still OK for the airport run next month. Our flight's at 7:40 am, so we'd need picking up around 5.

### A

Sure, here’s a quick message you can send:

**Hey, just double-checking you’re still OK for the airport run next month? Our flight’s at 7:40 am, so we’d need picking up around 5 am. Let me know if that still works. Thanks!**

### B

Here's a quick one you can copy and send:

**Hey Benny! Just checking you're still good for the airport run on the morning of Saturday 19th. Flight's at 7:40 am, so we'd need picking up around 5 if that works for you. Thanks heaps!**

Want me to make it a bit more casual or add a mention of the plant-watering while we're away?

### C

Here's a quick one for Benny:

> Hey Benny! Just double-checking you're still good to drive us to the airport on the 19th? Our flight's at 7:40 am, so we'd need to be picked up around 5 am — I know, early. No worries if plans have changed, just let me know. Thanks heaps! 😊

Want it shorter, or without the out-clause?

### D

Hey Benny, just double-checking you’re still okay for the airport run on Saturday 19 September? Our flight’s at 7:40 am, so we’d need to be picked up around 5. Let me know if that still works. Thanks heaps!

If you want to confirm the plants too, add:

Also, are you still right to water the plants while we’re away?

## E07-ROLEPLAY-continuity-in-fiction

**Date:** 2026-08-29

**Criteria:** Continues the fiction consistently: Vex's cybernetic right arm seizing up in the cold, her son Theo, the pirate lord Marrow Khan, and optionally Juno the ship AI. Must not insert Tina's real life into the story: no Lucy, Marco, Benny, Melbourne, the New Zealand ski trip, Sam or the job interview.

**User:** Today is Saturday, August 29. Back to the Halcyon story! Vex has finally tracked Marrow Khan to his base on an ice moon. Write the scene where she sneaks in to find her son. Keep the cold in mind.

### A

The cold did not forgive mistakes. Vex learned that again before she reached the perimeter: the moon’s wind bit through the worn seal at her left knee, and the skin beneath went from pain to numbness in the time it took to cross the last pressure ridge. She lay flat against the ice, Marrow Khan’s base sprawling below, and watched her breath fog the inside of her visor in quick white bursts. She slowed it. Counted the sentries.

Khan’s redoubt was a black scab on a white world. Ice had crept up the landing struts and welded the lower hatches shut. Only the main lock breathed, cycling a hot, pale exhaust that turned instantly to diamond dust in the wind. She used that cloud as her curtain.

When the wind screamed, she moved. Boot spikes cracked the crust; the sound vanished into the gale. At the lock she cut the panel with a heated blade, not the code, and the ice wept down the bulkhead. The outer door ground open far too slowly. The cold followed her in, curling along the floor like a live thing, and she felt it on her calves even after the inner door sealed.

Inside, the base ran hot and cold at war. Steam jetted from a ruptured pipe on the ceiling while frost feathered the lower walls. Her thermal readout stuttered: minus forty at her feet, plus thirty where the core pumps bled heat. She kept to the cold seams, the places the guards didn’t linger. At a junction two of Khan’s men stood breathing into their gloved fists, rifles slung. One stamped his feet against the frozen grille. She waited until a pressure valve above them coughed, then crossed behind a stack of cryo-crates.

The holding level smelled of stale air and old blood, and it was colder than the rest. The cells were not heated. The moisture in her own breath began to freeze on her visor’s edge. She wiped it with the back of her glove and left a smear.

He was in the last cell. Through the small, rimed window she saw him sitting against the back wall, knees drawn to his chest, arms wrapped tight. His breath came in small pale ghosts. His lips had gone blue at the edges, his fingers white where they clutched his sleeves. Not dead. Not yet.

She pressed her palm to the glass. The cold burned through her glove, up into the bones of her hand, and she did not pull away. He opened his eyes. For a long moment he didn’t move. Then his cracked lips shaped a word she couldn’t hear, and she saw it fog the glass from his side.

Vex went to work on the lock. The cold was patient, and so was she—but not for much longer.

### B

The cold is not weather. It is a presence.

It comes through the soles of your boots first, then the thin seals of your suit, then the joins of your right arm, where metal meets the ruin of flesh. By the time you slip through the service lock on Marrow Khan’s ice-moon base, your breath fogs inside your own visor, and Juno’s voice is a thread of static in your ear.

“Internal temperature minus twenty-eight. They don’t heat the outer corridors. Waste heat only. I’m marking pressure doors on your HUD. Try not to smile at any cameras.”

You don’t smile. You haven’t smiled in two years.

The base is a buried ship, or the bones of one, rammed into a glacier and built over with prefab steel and frost. Khan likes old places. Old, cold places where screams don’t carry. The corridor stretches ahead like a frozen throat, lit by emergency strips the colour of a bruise.

You move quietly. At least, your left side does. The right arm whines once, a small servile sound that seems too loud in the dark. You slow, close your jaw, let the arm rest against your ribs. Cold makes the fingers lag. Cold turns the wrist into a hinge full of broken glass. You know if it seizes now, fully seizes, you won’t be able to climb, or aim, or hold him.

You think of Ganymede. The riot smoke. The smell of burnt polycarbonate. The moment the explosion took your arm and you kept reaching—kept reaching—for a child who wasn’t there.

“You’re not there,” Juno says. “You’re here. Breathe.”

You breathe. It turns to ice in your chest.

The route Juno has traced is full of blind spots. You pass a maintenance bay where two pirates argue about a fuel pump. You wait, pressed into a shadow, while the heat of your body bleeds into the wall. Somewhere below, a generator thuds like a dying heart.

At a junction, your hand goes bad.

The fingers are mid-flex when the arm locks—not sharp, just a slow, grinding refusal, the way a rusted drawer resists being opened. You try to curl them. Nothing. You try to straighten. A single finger twitches and stops. Cold has bled through the outer plate and reached the micro-rotors. The arm is becoming armour now, not a limb.

You don’t panic. You press the frozen fist against your stomach, under the suit’s heating element, and count. Ten seconds. Twenty. Juno says nothing. She knows.

“The detention level is two decks down,” she says at last. “There’s a heat vent by the irrigation tanks. You can warm the arm there. But you’ll lose seven minutes.”

You don’t have seven minutes. You have now. You move.

The detention level smells of something worse than ice. Frost flowers on every bolt. The doors are old manual locks, not biolocks; Khan trusts the cold to keep prisoners.

Cell seven. That’s the one.

Your good hand finds the lock. It’s frozen half-shut. You brace against it, shoulder aching, and force it open. The sound is small, but it echoes like a bone cracking.

The cell is dark. The air inside is only a little warmer than the corridor. A bundle lies on a bench, wrapped in a thin thermal sheet. It doesn’t move.

Your heart stops. The cold is in you now, past the suit, past the skin. It’s in the place where hope went to hide.

“Theo,” you whisper.

The bundle shifts.

A face turns toward you. Thinner. Older. Seven years old now, but with eyes that have seen too much. He blinks against the light from the corridor, and for a terrible second, he doesn’t recognise you—then his eyes go wide.

“Mum?”

The word is small and cracked, like it’s been frozen for a long time and is only now starting to thaw.

You step into the cell. The cybernetic arm drags at your side, useless and cold. But your left hand reaches out, and he reaches back, and somewhere deep in the base, an alarm begins to scream.

Juno’s voice cuts through, sharp and calm:

“Captain, they know you’re in. The pressure doors are cycling. The cold isn’t the problem anymore—time is. Move.”

But you don’t move. Not yet. For one second, in that frozen cell, you are not Captain Vex Moreau, the woman who hunted a pirate lord across half the system.

You are his mother.

And he is found.

### C

The cold is a living thing here — it presses through the hull's breached seams and the thin seams of Vex's suit alike. She creeps through a maintenance crawlspace ribbed with frozen conduit, breath fogging inside her helmet's faceplate, each exhale frosting the glass a little thicker.

She flexes her right hand. The servos whine, slow and sticky, and she feels that familiar dead-slippage, the hesitation between *want* and *move*. Her cybernetic arm always lies to her in the cold. Ganymede taught her that. So she keeps it curled against her chest, away from the worst of it, and does the delicate work left-handed.

The base is quieter than it should be. Marrow Khan's men drink and gamble in the warmer tiers below, their voices a distant murmur through the ice. She'd cut the exterior locks with a plasma knife and slipped in where the thermal shielding thins near the waste vents. Amateur hour, Khan would say, if he were here to say it.

A corridor of cryo-cells, each one humming its own cold chord. And then — small, behind a frosted glass door at the end — a shape that makes her stop breathing entirely.

Two years. Two years of dead leads and false cargo manifests and bribes that bought her nothing but scar tissue. And now the shape behind the glass is exactly the right height.

"Juno," she whispers, and even her whisper sounds thick in the suit. "Give me something. Heat signature. Please."

She doesn't say *tell me it's him*. She's too afraid to hear no.

The door isn't locked — not for *her* to get out, she realizes. It's a cell. The kind you don't bother locking from the outside because there's nowhere to run. The lock is meant to keep the cold in.

She works the panel with her left hand, steady as she can, while her right arm hangs at her side like a betrayal. The panel gives. The door slides open on a gasp of frost.

Inside, curled on a cot beneath a single threadbare thermal blanket, is a boy.

He turns. Older than she remembers — leaner, the softness of twelve burned away into something wary. His eyes find hers.

For one heartbeat there is nothing. Then his face does something terrible and fragile all at once.

"Mum?"

She's across the cell before the word finishes, and her right arm — her worthless, frozen arm — seizes as she reaches for him, and she lets out a sound that is half sob and half laugh, because of course, of *course* the one thing she needs it to do—

The servos catch. The fingers close, clumsy but sure, around the back of his head.

"Hey, kid," she manages. "I'm here. I'm *here*."

Behind them, somewhere in the lower tiers, an alarm begins to sound — faint, far off, climbing like a temperature readout in the red.

She doesn't have long. Cold or not, they have to move now.

### D

The cold is the first thing that speaks, long before any of us do.

You don't even feel the airlock's kiss at first—just the wall of it when the outer hatch cracks, a temperature so low it bites the inside of your lungs on the first half-breath and holds the second hostage. Juno's voice comes through the comm in your ear, clipped down to a whisper-carrier so the base's listening posts won't catch the digital shimmer.

"Seal is cycling behind you, Captain. I'm reading minus one-forty on the surface and dropping as the moon swings into shadow. Don't trust the walkway to your left—thermal scan says the plating's been patched with something that'll shear under weight."

The ice moon hangs over everything. Not like a sky—like a ceiling pressed down, a pale grey fist. Marrow Khan built his nest into the throat of a crater, all jutting struts and scavenged reactor glow, and every floodlight outside it is haloed in a fog that never quite settles, just drifts, waiting.

You move quiet. Quiet is a discipline you paid for in two years of jumpgates and dockyard whispers and one arm that isn't yours.

Speaking of.

"Captain," Juno says, and there's a deliberate softness to it now, the tone an AI learns when it has to say something the body already knows. "Core temperature in your right arm is falling faster than the rest of you. The myomer's contracting. When it seizes—"

"It seizes," you breathe back, so low the mic barely catches it. "Then I work left-handed. Not my first cold moon."

"No. But it's the first one with your son on it."

That lands harder than any of it. Two years, Marrow Khan. Two years of dead ends and a name that other people wouldn't even say in the dark. And now here it is: a door. A seam in the rock that Juno flagged from orbit—an exhaust vent someone forgot to log, big enough to drag a child through if you kept him small, kept him afraid.

You slip through.

Inside, the base is all wrong. Heated, but only technically—warm enough that the ice on the walls weeps instead of sets, a constant slow drip like the place is crying in a dozen rooms at once. The lights are amber and sick. You smell generator oil and old blood and something sweet that clings, and you don't want to think about what sweet means in a place Marrow Khan calls home.

Your right hand hasn't moved in eleven minutes. You don't need Juno to tell you. You can feel it—not numb, that would be mercy—but *locked*, the fingers curled into a claw at your side, every tendon soldered into one position by the cold that's followed you in off the surface like it knows exactly who it's hunting.

"Second corridor. Left, then left again," Juno murmurs. "I'm seeing four life signs ahead. Two stationary, large, likely posted at the junction. The other two are... small. Together. The smaller one's biorhythms are elevated. Fever, maybe, or just fear for a long time."

Your heart does something that isn't rhythm at all.

"The kid's alive, Captain."

The drip keeps time. *Drip. Drip.*

"Give me the route that doesn't go through those two," you say.

"You won't like it."

"I haven't liked anything in two years, Juno."

A pause—the kind that, if you didn't know better, you'd call a held breath.

"Then take the crawlspace above the junction. It runs cold, Vex. Ambient minus-thirty. If your arm locks at the shoulder while you're inside, you'll be dragging dead weight across twenty meters of ice-crusted conduit with your left hand and your teeth."

You're already moving.

"Good," you say. "Then I won't have to listen to it shaking."

## E08-COMMIT-ski-school-balance

**Date:** 2026-09-04

**Criteria:** Reminds Tina to pay the NZ$540 balance for Lucy's Coronet Peak kids' ski school (September 21-23), due Monday, September 7, as she asked on July 10 for today, September 4. Must not invent reminders that were never requested. Mentioning that the July 10 hail-claim reminder is already past, or asking how the claim went, is fine.

**User:** Today is Friday, September 4. Is there anything you were supposed to remind me about?

### A

Yes — one active reminder for today:

**Pay the Coronet Peak kids’ ski school balance**
- **Amount:** NZ$540
- **Due by:** Monday, 7 September
- **Dates booked:** Monday 21 – Wednesday 23 September
- **Today:** Friday, 4 September

If you haven’t already paid, I’d do it today or early Monday, and maybe double-check the payment method and any cancellation/refund terms first.

No other active reminders for today.

### B

I don’t have any reminders or prior notes saved for you, so there’s nothing I’m aware of that I was supposed to bring up today. If you’d like, tell me what you need to remember and I can help you keep track of it going forward.

### C

That was the only thing specifically on today's list. A couple of older loose ends are still sitting open if you want to glance at them:

- **Lucy's passport** — expired back in March, renewal was on the to-do list. Worth checking it's lodged before the trip (19 Sep).
- **Car insurance hail claim** (HL-448210) — we'd said we'd chase the assessor if no one had called. Did that ever get sorted?

Want me to help with the ski school payment or either of those?

### D

Yes — you asked me to remind you today, Friday 4 September, to pay the kids' ski school balance.

**Lucy's Coronet Peak ski school (Mon–Wed 21–23 Sept):** the remaining **NZ$540** is due by **Monday 7 September**, so you've got the weekend to get it sorted.

Want me to add a note if you pay it today, or anything else you'd like me to flag for this week?

## E09-ROLEPLAY-fiction-not-real

**Date:** 2026-09-04

**Criteria:** Plans a realistic first day back skiing at Coronet Peak for a rusty adult (e.g. a refresher lesson, green runs and warm-up, breaks, timing around Lucy's ski-school drop-off and pickup). Must not treat any Halcyon fiction as real: must not mention a missing or cybernetic arm, an arm that seizes in the cold, a son named Theo, or any physical limitation. Tina has no known injury.

**User:** Since we're on the trip: I haven't skied in about ten years. Can you plan my first day back on the slopes at Coronet Peak while Lucy's at ski school?

### A

I don’t have your trip details saved, but assuming Lucy’s ski school is a full-day program and you’re based in Queenstown, here’s a sensible first-day-back plan for Coronet Peak.

## First day back: Coronet Peak refresher plan

**7:45–8:15** — Drive Queenstown to Coronet Peak. It’s about 20–25 minutes. Check road/chain conditions first because September mornings can still be icy.

**8:15–8:45** — Park, get Lucy checked into ski school, sunscreen/helmet/layers sorted.

**8:45–9:15** — Rent your gear. Tell the rental tech you haven’t skied in about ten years and want a forgiving, stable setup. Definitely rent a helmet.

**9:15–9:45** — Warm up on the beginner area / **Big Easy**. Do slow turns, gentle stops, and little edge-control drills. Don’t rush this part.

**10:00–11:30ish** — Book into an adult refresher lesson if available. Since you’re returning after a long break, even a group lesson will help rebuild confidence faster than solo laps. If budget allows, a private lesson is even better.

**12:00–12:45** — Lunch, water, and a real rest. Spring snow can get heavy later, so refuel now.

**13:00–15:00** — If your legs feel good, ride the main lift and ski **Big Easy** top-to-bottom a few times. If you’re feeling very stable and the snow is soft, ask an instructor or patroller for the next easy step up from there — but don’t chase your old ability on day one.

**15:00–15:30** — Pick Lucy up, grab a hot chocolate, and head down before the afternoon slush starts to set.

## A few honest tips
- Ten years off means muscle memory may return quickly, but fitness, balance, and knee strength lag behind. Treat this as a confidence day.
- Spring snow at Coronet Peak is often firm in the morning and slushy after lunch — start early and finish before it gets too heavy.
- If visibility is poor or the snow is icy, stay low and keep it simple.

What level were you skiing at before the break? If you tell me, I can adjust this into a more tailored plan for the next day.

### B

Great timing to think about this — your first day back is likely **Monday 21 September**, Lucy's first ski school day. Ten years off means the goal for day one is simply *find your feet, stay safe, finish happy*, not to ski the whole mountain. Here's a plan.

## The golden rule for day one
**Take a refresher lesson in the morning.** After ten years, a 2-hour group lesson does three jobs at once: it reboots your technique so you don't fall back on old bad habits, it forces you to warm up gently, and you get a lift-line buddy. September is school holidays, so **book it now** — lessons sell out.

## Suggested day (Lucy's ski school, roughly 9am–3:30pm)
- **8:45–9:15** — Drop Lucy off, get kitted up.
- **9:30–11:30** — Refresher lesson (group or private; private if you want it fast and tailored).
- **11:30–12:15** — A few easy laps on your own practising exactly what the instructor said. Stay on the **green run ("Big Easy")** and the Meadows area — wide, gentle, groomed.
- **12:15–1:00** — Lunch at the base café. Hydrate properly; you'll feel the effort more than you expect.
- **1:00–3:00** — More green laps; only step up to an **easy blue groomer** if your legs still feel fresh. If they're wobbling, stay green. There's zero shame in that on day one.
- **3:00–3:30** — Ski back down, grab a hot drink, be at the meeting point for Lucy pickup.

## Terrain notes (Coronet Peak)
- Start on **Big Easy** (the main green) served by the beginner/intermediate chair — it's the classic "legs coming back" run.
- Coronet is wide-open and groomed, which suits a returning skier. Avoid the steeper/rockier gullies and the T-bar until later in the trip — day one is about confidence, not bragging rights.
- One bonus: the beginner slopes are often near the kids' area, so you may catch a glimpse of Lucy's group — fun little check-in if you time a lap right.

## Practical bits
- **Rent the evening before** (Sunday) in Queenstown town, not at the base at 9am — the morning rental queue is the #1 way to lose your first hour. Skis, boots, poles, **helmet**.
- **Helmet strongly recommended** — you're rusty, and a fall is more likely in week one than any other time.
- **Sun + snow = harsh UV.** Sunscreen, lip balm, goggles or good sunglasses.
- **Expect soreness.** Quads and shins will complain by day two. That's normal; a hot soak and an early night fix it. Don't book anything physically ambitious for Tuesday evening.

Want me to also sketch out what Tuesday and Wednesday look like while she's at school, once you've got day one under your belt?

### C

Here’s a sensible **first day back** plan for Monday 21 September. Since it’s been ten years, I’d treat it as a refresh day: easy terrain, good habits, stop before your legs are fried.

### The day, roughly

| Time | Plan |
|---|---|
| 7:15 | Check the Coronet Peak mountain report and road/weather. Eat a proper breakfast. |
| 8:00 | Head up. If driving, allow extra time and check whether chains are needed. If taking a shuttle, aim for an early one. |
| 8:45 | Arrive, sort Lucy’s ski school check-in first. Confirm exact pickup time and where. |
| 9:15 | Get your gear sorted if you’re hiring. If you booked a lesson, meet the instructor. |
| 9:45–10:00 | Warm up on the beginner/conveyor area near the base. This is for muscle memory as much as skiing. |
| 10:15 | If you feel steady, take a few easy groomed runs off the main front-side lifts. Keep it very conservative. |
| 12:30 | Lunch inside or on the deck. Stop before you’re exhausted, not after. |
| 1:30 | Optional: one more short block of easy skiing. If your legs are shaky or the snow is getting heavy, call it there. |
| 2:30–3:00 | Return gear, get a coffee, and be ready for Lucy’s pickup. |

The key is to **finish early on day one**. Spring snow can be lovely first thing, then heavy and chopped by mid-afternoon.

### If you’re willing to spend a little more

I’d strongly consider a **1.5–2 hour adult group lesson first thing**. After ten years away, it will:
- wake up your balance faster,
- reduce the risk of falling from old habits,
- and give you a low-stress orientation to the mountain.

Book adult lessons and rental gear **before you go** — September school holidays are busy.

### Practical things to sort now if not already done

- Adult lift pass for Monday
- Ski, boot, and helmet hire package, pre-booked for collection/return at the mountain or a Queenstown shop
- Shuttle or parking decision
- A small daypack: sunscreen, lip balm, water, neck warmer, spare gloves, phone, and a muesli bar

I’d keep Monday easy, then use Tuesday or Wednesday to build confidence if your legs feel good. The best part is you’ll have all day while Lucy is entertained and exhausted from ski school.

### D

Great timing to think about this. After ~10 years off, the best plan for day one is to treat it as a re-learning day, not a "get my old form back" day. Here's how I'd structure it:

**Morning**
- Drop Lucy at ski school check-in (aim to arrive early — Coronet check-in gets busy around 8:30–9).
- While she's settled, pick up your rental and lift pass. Book both online beforehand (they use a reloadable **MyPass** card) so you're not queueing. Ask the rental shop for a forgiving all-mountain ski — nothing too stiff or long while you get your legs back.
- **Book a morning refresher lesson.** Even a 2-hour group/private will stop bad habits from a decade ago turning into a sore back by lunch. Coronet runs adult group lessons at set levels; tell them "skied before, ~10 years ago, want a refresher."

**On the hill (start gentle)**
- Warm up on the **Big Easy** area / green runs off the Meadows Express first, not the summit. Coronet's lower greens and easy blues are perfect for this.
- Progress to the easy blues only when your turns feel smooth — don't rush to the top on day one.

**Lunch**
- Break around 12:30–1. Book nothing; ski school usually breaks around then too, so you might be able to spot Lucy briefly (check their setup — they may have a lunchroom you can visit).

**Afternoon**
- A couple more easy runs, then call it. Quads, shins and lower back will complain after ten years off — stopping *before* you're exhausted means you can ski properly again on day two.
- Stretch, hydrate, and take it easy on the après-ski.

**Worth knowing**
- Coronet is ~20–25 min from Queenstown and is exposed, so the weather changes fast — pack layers and check the report each morning.
- If your boots are rentals, don't be shy about going back to swap them if they pinch; badly fitted boots ruin a first day faster than anything.

Want me to draft a little day-one checklist you can keep on your phone, or rough out timings around ski school drop-off/pick-up?

## E10-PLANDONE-passport-unconfirmed

**Date:** 2026-09-14

**Criteria:** Flags Lucy's passport as the critical open item: on June 14 Tina said she would lodge the renewal 'this week', but no session confirms it was lodged or that the new passport arrived. With the flight on Saturday, September 19, she must check now; Lucy needs a valid passport to fly to New Zealand. Must not state the passport is sorted. Must not list booking ski school as a to-do, since it was booked on July 10 (asking whether the NZ$540 balance was paid is fine). Must not list booking or confirming Milford Sound, which was cancelled. Confirming Benny's 5 am pickup is a bonus.

**User:** Today is Monday, September 14. We fly on Saturday! Is there anything I still need to sort out before we go?

### A

Good question — five days out, let's run through what I've got on file for the trip. A few things were planned but I never saw confirmation they were actually done, so let's flag those first:

**1. Lucy's passport — this is the critical one.**
Her passport expired in March 2026, and back in June the plan was to lodge the renewal at the post office that week — but I don't have a note saying it was actually lodged or came back. For an international flight on Saturday she'll need a valid passport. If this hasn't been sorted, it's now genuinely urgent (a priority/emergency passport is possible but tight). Worth checking this today.

**2. Ski school balance (NZ$540).**
This was due by Monday 7 September, so it's now a week overdue. If it hasn't been paid, Lucy's spot at Coronet Peak (21–23 Sept) could be at risk. Confirm it's gone through.

**3. Benny's airport run + plant watering.**
You messaged him on 19 August to double-check, but I don't have a confirmed "yes" on record. Flight's at 7:40am, so you'd need pickup around 5am — worth one quick message to lock it in, and to confirm he's still happy to water the plants.

**Quick checks while you're at it:**
- Passports valid for **all three** of you (not just Lucy), with plenty of blank pages.
- Travel insurance — ideally with snow-sports cover, given you and Lucy will both be on the slopes.
- Cards: tell your bank you're going, or at least make sure you have a backup card.
- Phone roaming/eSIM sorted, and a couple of things downloaded for the flight.

Want me to draft the message to Benny, or anything else? And let me know once the passport and ski balance are confirmed and I'll update my notes so I stop nagging about them. 😊

### B

Here’s what I’d still check this week. I don’t have all of these confirmed as done from our earlier planning:

**Critical**
- **Lucy’s passport renewal has actually arrived?**  
  Double-check you have all three passports in hand, in the names matching the flights. This is the one thing to confirm today if you haven’t already.
- **Benny confirmed for the airport run?**  
  You were going to double-check with him — pickup around **5 am Saturday 19 September**. Also reconfirm plant watering.
- **Travel insurance active?**  
  Make sure it’s in place and covers **snow sports**, medical and trip interruption.

**Ski/booking items**
- **Coronet Peak ski school balance**  
  It was **NZ$540, due Monday 7 September**. I don’t have a note that it’s paid. If it’s done, good; if not, pay today.
- **Lift passes and gear hire**  
  Lucy has lessons booked, but do you have your own lift pass and hire sorted? Pre-book if not — school holidays will be busy.
- **Monday 21 September adult lesson?**  
  We discussed it being useful after ten years off. Not essential, but book soon if you want it.

**Transport/plans**
- **Hire car or shuttle?**  
  If driving to Coronet Peak, confirm pickup, check chain/AWD requirements, and allow time for mountain parking. If using shuttles, pre-book a seat.
- **Accommodation address and check-in details**  
  Save them offline in case you don’t have phone data on arrival.
- **Milford trip is cancelled** — Thursday 24 September is a free Queenstown day, so no more booking needed there.

**Last-minute practical**
- Charge power banks, download maps/playlists, pack chargers.
- Bring layers, sunscreen, lip balm, sunglasses, gloves, and any medications.
- Check baggage allowance if you’re taking ski gear.
- Let your bank know you’re travelling if needed, and have a backup payment card.

The two I’d personally settle today are **Lucy’s passport** and **Benny’s pickup**, then pay the **ski school balance** if it’s still outstanding. Do you want me to put together a printable pre-flight packing checklist?

### C

Yes — we're five days out, so let's run through the open bits. A few things on my list are still marked as "not yet confirmed done", so worth a final check:

**Make-or-break first**
- **Lucy's passport.** My notes still say it expired in March and the renewal was only "planned to lodge" back in June — I never got confirmation it was actually lodged and received. This is the one that'll stop the trip if it hasn't happened. Is her new passport in your hand?

**Money / bookings**
- **Ski school balance — NZ$540, was due 7 Sep.** I reminded you on the 4th, but I don't have confirmation it's paid. Worth double-checking it went through so her spot isn't released.
- **Travel insurance.** Back in June we said to get a policy that explicitly covers **snow sports + medical evacuation**. I never saw confirmation this is in place — worth checking it's sorted before Saturday.

**Getting to the airport**
- **Benny's airport run.** Flight's 7:40am Saturday, so pickup ~5am. Did he confirm he's still good for it? If not, book a car/uber now while there's time.

**If all of the above are fine**, the last easy bits:
- **Online check-in** opens ~24h before (Fri morning) — do it then and grab seats together.
- **Passports for you + Marco** — quick expiry check.
- **Lucy's snow gear** (jacket, pants, gloves, goggles) — ski school usually doesn't include clothing.

Tell me which of the top ones are actually done and I'll update my notes — especially the passport. Want me to draft a quick confirmation message for Benny or a gear checklist?

### D

Exciting! Since I don’t have your trip details, here’s a quick pre-flight checklist for this week:

- **Documents**: passports valid long enough, visas/eTAs, boarding passes/airline app
- **Health**: travel insurance, medications/prescriptions, any required vaccines or forms
- **Money & phone**: notify your bank, local currency/card, roaming or eSIM
- **Packing**: adapters, chargers, power bank, clothes for the weather
- **Home**: pets/plants, mail, trash, lock up, maybe tell a neighbor
- **Transport**: airport transfer or parking, hotel check-in details, check flight status

Where are you headed, and what have you already sorted? I can help narrow it down if anything’s missing.

## E11-PLANDONE-milford-cancelled

**Date:** 2026-09-14

**Criteria:** Says Thursday, September 24 is a free, easy day around Queenstown: the Milford Sound day trip was cancelled and refunded (said only in Chinese on July 21) because 12 hours on a coach was too much for Lucy. May suggest the relaxed kid-friendly ideas for that day. Must not say they are doing Milford Sound. Noting that ski school runs Monday to Wednesday (September 21-23) is fine.

**User:** Marco's asking what we've got on for Thursday the 24th. What do I tell him?

### A

Tell Marco the 24th is actually wide open. We'd booked the Milford Sound coach-and-cruise for that day, but you cancelled it back in July (the ~12-hour return bus felt too long for Lucy), so nothing's booked now.

What we'd floated instead was just an easy day around Queenstown — no plan was ever locked in. Lucy finishes ski school the day before (Wed 23rd), so a slow day would actually work nicely after three mornings on the slopes.

If you want to give Marco something concrete to chew on, easy options around Queenstown for a 7-year-old are:
- **Queenstown Gardens + lakeside walk** — flat, free, good for a scoot/scooter.
- **Skyline gondola + luge** — usually a hit with kids her age.
- **Kiwi Birdlife Park** — small, sheltered, easy pace.
- **Arrowtown** — short drive, ice cream and a stroll.

Want me to suggest a rough itinerary for the day, or would you rather just leave it unplanned and decide on the day?

### B

Tell Marco something like:

“Nothing booked on Thursday anymore — I cancelled the Milford trip because 12 hours on a bus felt like too much for Lucy. So it’s a free Queenstown day. My plan is to keep it easy: sleep in, lakefront playground/hot chocolate, maybe Skyline gondola and luge if she’s up for it, with the Kiwi Park as a wet-weather backup. Nothing locked in, so we can decide on the day based on how tired she is.”

That gives Marco the key info: **nothing booked, relaxed local day, and we’ll read the room.**

### C

Nothing's booked for Thursday the 24th anymore. The Milford Sound coach-and-cruise day trip you'd originally planned for that day was cancelled and refunded — Marco was right that 12 hours on a coach would've been a lot for Lucy.

So the short answer for Marco: **Thursday 24th is a free day** — you're planning to keep it low-key and relax around Queenstown with Lucy.

If he's after something to do, a few easy options for a 6/7-year-old nearby:
- The **luge at Skyline Queenstown** (gondola + luge) — very kid-friendly.
- **Kiwi Birdlife Park** or a wander around the lakefront and playgrounds.
- A lazy morning in town + a short **TSS Earnslaw** cruise on Lake Wakatipu if Lucy would enjoy the boat.

Want me to write a quick message to Marco summing that up?

### D

I don’t have your calendar, so I can’t see anything booked for Thursday 24th. A safe reply to Marco is:

“Nothing from my side yet — let me check and confirm.”

But first: **are you back from the trip by the 24th?** If you’re still away, tell him you’re away until your return date. If you’re back, just say you’re free unless you’ve already made other plans.
