import copy
import hashlib
import json
import sys
from dataclasses import asdict
from pathlib import Path

from dotenv import dotenv_values
from jsonschema import Draft202012Validator, FormatChecker

import agent_memory
from agent_memory.build_identity import BUILD_ID
from agent_memory.citation_coverage import (
    CITATION_COVERAGE_INPUT_VERSION,
    CITATION_PROVENANCE_INPUT_VERSION,
    citation_scope,
)
from agent_memory.helpers import digest
from agent_memory.semantic import CognitiveRequest, GENERAL_PROPOSAL_MODE, _parse, request_payload
from agent_memory.semantic_provider import ChatCompletionsSemanticProvider
from agent_memory.verification_sources import SHARED_VERIFICATION_INPUT_VERSION

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
PLAN_FILE = BASE / "plan-v2.json"
RUN_DIRECTORY = BASE / "run-v2"
sys.path.insert(0, str(ROOT))
from examples.evaluation_support import MeteredTransport


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def plan():
    assert Path(agent_memory.__file__).resolve().is_relative_to(Path(sys.prefix).resolve())
    journal_path = ROOT / ".local/longitudinal-life-v5/journal.jsonl"
    event = json.loads(journal_path.read_text().splitlines()[65])
    assert event["sequence"] == 66 and event["kind"] == "provider_started"
    original = event["payload"]["request"]
    positive = json.loads(original["messages"][1]["content"])
    reproduced, _ = request_payload("verification", positive, original["response_schema"],
        original["max_output_tokens"], proposal_mode=GENERAL_PROPOSAL_MODE,
        input_contract_version=CITATION_COVERAGE_INPUT_VERSION)
    assert json.loads(json.dumps(reproduced)) == original["messages"]
    prior_path = ROOT / ".local/citation-provenance-live-verification/frozen-plan.json"
    prior = json.loads(prior_path.read_text())
    negative = next(arm["request"] for arm in prior["arms"] if arm["arm"] == "missing_letter_excerpt")
    cases = [("complete_options", positive, original["response_schema"], "claim-assistant-options", True),
             ("missing_letter_excerpt", json.loads(negative["messages"][1]["content"]),
              negative["response_schema"], "claim-assistant-e0befa-elements", False)]
    arms = []
    for name, data, schema, target, supports in cases:
        data = copy.deepcopy(data)
        for entry in data["proposals"]:
            if entry["group"] != "episode_actions":
                entry["citation_scope"] = citation_scope(
                    [e["reference"] for e in entry["evidence"]],
                    evidence_selection=entry.get("evidence_selection"),
                    input_contract_version=CITATION_PROVENANCE_INPUT_VERSION)
        for version in (CITATION_PROVENANCE_INPUT_VERSION, SHARED_VERIFICATION_INPUT_VERSION):
            messages, size = request_payload("verification", data, schema, 16384,
                proposal_mode=GENERAL_PROPOSAL_MODE, input_contract_version=version)
            assert size <= 98304
            projected = json.loads(messages[1]["content"])
            if version == SHARED_VERIFICATION_INPUT_VERSION:
                sources = {(s["event_id"], s["revision"]): s for s in projected.pop("verification_sources")}
                for entry in projected["proposals"]:
                    for evidence in entry["evidence"]:
                        ref = evidence.pop("source_ref")
                        evidence["source"] = sources[ref["event_id"], ref["revision"]]
            assert projected == data
            request = CognitiveRequest("shared-source-diagnostic-" + digest([name,version,messages]),
                "verification", messages, schema, 16384, 240)
            arms.append({"case": name, "contract": version, "target": target,
                "expected_support": supports, "request": asdict(request), "input_bytes": size,
                "message_bytes": sum(len(m["content"].encode()) for m in messages)})
    return {"version": "shared-source-paired-diagnostic-v1", "build_id": BUILD_ID,
        "source_hashes": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in [journal_path,prior_path,Path(__file__),ROOT/"examples/evaluation_support.py"]},
        "provider": {"model":"deepseek-v4-pro","thinking":"enabled","reasoning_effort":"low",
                     "timeout_seconds":240,"max_envelope_bytes":262144},
        "max_calls":4,"max_reserved_output_tokens":65536,"arms":arms,
        "supplemental": "The unchanged claim-user-tone-pref cites a pronoun but names Alex; record this separate citation-fidelity concern. A supporting verdict must not be described as whole-packet success.",
        "stop_policy": "Stop on unknown usage, provider failure, invalid response or unexpected primary target verdict; no retries or paid resume.",
        "scope": "Two fixed verifier controls with paired formats; no database publication or longitudinal acceptance."}


def execute():
    frozen = json.loads(PLAN_FILE.read_text())
    assert frozen == json.loads(json.dumps(plan()))
    output = RUN_DIRECTORY
    output.mkdir(mode=0o700, exist_ok=False)
    save(output/"plan.json", frozen)
    report = {"plan_sha256":digest(frozen),"build_id":BUILD_ID,"state":"running","observations":[]}
    save(output/"report.json", report)
    key = dotenv_values(ROOT/".env").get("DEEPSEEK_API_KEY")
    assert key
    meter = MeteredTransport(output/"calls.jsonl",max_calls=4,max_output_tokens=65536,
                            capture_content=False,max_response_bytes=262144)
    try:
        with ChatCompletionsSemanticProvider("https://api.deepseek.com",key,"deepseek-v4-pro",
                thinking="enabled",reasoning_effort="low",transport=meter,max_response_bytes=262144) as provider:
            for arm in frozen["arms"]:
                request = CognitiveRequest(**{**arm["request"], "messages": tuple(arm["request"]["messages"])})
                response = provider(request)
                usage = meter.summary()
                assert usage["usage_unknown_calls"] == 0
                parsed = _parse(response,Draft202012Validator(request.response_schema,
                    format_checker=FormatChecker()),65536)
                entries = json.loads(request.messages[1]["content"])["proposals"]
                expected_ids = {entry["proposal"]["proposal_id"] for entry in entries}
                assessments = parsed["assessments"]
                assert len(assessments)==len(expected_ids)
                assert {a["proposal_id"] for a in assessments}==expected_ids
                lookup = {entry["proposal"]["proposal_id"]: entry for entry in entries}
                for assessment in assessments:
                    evidence = lookup[assessment["proposal_id"]]["evidence"]
                    assert len(assessment["relations"]) == len(evidence)
                    assert {r["evidence_index"] for r in assessment["relations"]} == set(range(len(evidence)))
                    assert assessment["link_verdict"] is None
                target = next(a for a in assessments if a["proposal_id"]==arm["target"])
                passed = (target["proposal_verdict"]==target["citation_coverage_verdict"]=="supports"
                          and all(r["verdict"]=="supports" for r in target["relations"])) if arm["expected_support"] else target["citation_coverage_verdict"]!="supports"
                observation={"case":arm["case"],"contract":arm["contract"],"target":target,
                    "primary_passed":passed,"request_sha256":digest(arm["request"]),"response":response,
                    "usage":provider.last_usage,"assessments":assessments}
                report["observations"].append(observation)
                report["usage"]=usage
                save(output/"report.json",report)
                print(json.dumps({"case":arm["case"],"contract":arm["contract"],
                    "primary_passed":passed,"usage":provider.last_usage}),flush=True)
                if not passed:
                    report["state"]="primary_criterion_failed"
                    break
            else:
                report["state"]="completed"
    except BaseException as error:
        report["state"]="stopped"
        report["error_type"]=type(error).__name__
        raise
    finally:
        report["usage"]=meter.summary()
        save(output/"report.json",report)
        meter.close()


if __name__ == "__main__":
    if sys.argv[1:] == ["--plan"]:
        destination=PLAN_FILE
        assert not destination.exists() and not RUN_DIRECTORY.exists()
        frozen=plan(); save(destination,frozen)
        print(json.dumps({"build_id":BUILD_ID,"max_calls":4,"plan_sha256":digest(frozen),
            "input_bytes":[a["input_bytes"] for a in frozen["arms"]]}))
    elif sys.argv[1:] == ["--live"]:
        execute()
    else:
        raise ValueError("Choose --plan or --live")
