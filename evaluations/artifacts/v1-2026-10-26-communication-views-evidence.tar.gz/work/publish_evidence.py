import hashlib,io,json,os,re,subprocess,tarfile
from pathlib import Path
from urllib.parse import urlsplit
from dotenv import dotenv_values
ROOT=Path.cwd();WORK=ROOT/'.local/communication-view';PREFIX='v1-2026-10-26-communication-views';entries={}
for p in WORK.iterdir():
 if p.is_file() and (p.suffix in {'.py','.json','.log','.txt'} or p.name.endswith('.before-input-reduction')):entries['work/'+p.name]=p.read_bytes()
for p in (WORK/'campaign').iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl'}:entries['campaign/'+p.name]=p.read_bytes()
entries['tested-source.patch']=subprocess.check_output(['git','diff','--binary','bc3cec79f9bb679c1f499891ba1db3abad1d5031','e7b94182b0833d06c433af5ff6737d3ba528288e','--','src','tests','examples'])
configured={**dotenv_values(ROOT/'.env'),**os.environ}
secrets={v.encode() for k,v in configured.items() if v and len(v)>=12 and any(x in k.upper() for x in ('API_KEY','API_TOKEN','SECRET','PASSWORD'))}
for k,v in configured.items():
 if v and 'URL' in k.upper():
  try:password=urlsplit(v).password
  except ValueError:continue
  if password and len(password)>=8:secrets.add(password.encode())
def scan(v):
 if isinstance(v,dict):
  assert not any(k in {'reasoning_content','hidden_reasoning','chain_of_thought'} and x for k,x in v.items())
  for x in v.values():scan(x)
 elif isinstance(v,list):
  for x in v:scan(x)
for name,raw in entries.items():
 assert not any(v in raw for v in secrets),name
 assert not re.search(rb'sk-[A-Za-z0-9]{16,}',raw),name
 if '.jsonl' in name:
  for line in raw.splitlines():scan(json.loads(line))
 elif '.json' in name:scan(json.loads(raw))
bundle=ROOT/'evaluations/artifacts'/(PREFIX+'-evidence.tar.gz')
with tarfile.open(bundle,'w:gz') as stream:
 for name,raw in sorted(entries.items()):
  member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o600;stream.addfile(member,io.BytesIO(raw))
with tarfile.open(bundle,'r:gz') as stream:
 assert set(entries)=={m.name for m in stream.getmembers()}
 for m in stream.getmembers():assert m.isfile() and stream.extractfile(m).read()==entries[m.name]
manifest={'runtime_build':'fe52d33156502e59d20f3a44c4e80ec67fbd2ded742bb0488b10c1b21307f5e8','source_commit':'e7b94182b0833d06c433af5ff6737d3ba528288e','bundle':str(bundle.relative_to(ROOT)),'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'bytes':bundle.stat().st_size,'files':{n:hashlib.sha256(raw).hexdigest() for n,raw in sorted(entries.items())},'configured_secret_and_key_pattern_scan':'passed','json_hidden_reasoning_field_scan':'passed','member_bytes_verified':True,'campaign':'Closed stopped journal; one delivered reply,zero learning-complete turns,zero complete sessions. Two actual provider calls,24088known tokens,zero unknown usage; no automatic retry or age diagnostic.','earlier_failed_full_run':'Included under before-input-reduction suffix. Synthetic replays are not paid calls or repaired historical operations.'}
(ROOT/'evaluations'/(PREFIX+'-evidence.json')).write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'files':len(entries),'bytes':manifest['bytes'],'sha256':manifest['sha256'],'scans':'passed'}))
