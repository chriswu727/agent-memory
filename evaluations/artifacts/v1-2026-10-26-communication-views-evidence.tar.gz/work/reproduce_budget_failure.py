import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / 'tests'))
from test_semantic import verifier
from agent_memory import semantic
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest

w = Path('.local/communication-view')
es = [json.loads(line) for line in (w/'campaign/journal.jsonl').read_text().splitlines()]
start = next(e['payload']['request'] for e in es if e['kind']=='provider_started' and e['payload']['role']=='cognition')
raw = next(e['payload']['response'] for e in es if e['kind']=='provider_completed' and e['payload']['role']=='cognition')
body = json.loads(start['messages'][-1]['content'])
finished = next(e['payload']['result'] for e in es if e['kind']=='learning_job' and e['payload'].get('learning_phase')=='encoding' and e['payload'].get('record_type')=='finished')
batch = semantic.CognitiveBatch(
    'offline-original-budget',body['working_state']['scope'],tuple(body['sources']),
    existing_assertions=tuple(body['existing_assertions']),working_state=body['working_state'],
    episodes=tuple(body['episodes']),sampling=body['sampling'],belief_relations=tuple(body['belief_relations']),
    consolidation_plan=body['consolidation_plan'],current_input_refs=tuple(body['current_input_refs']),
    learning_input_refs=tuple(body['learning_input_refs']),input_contract_version=finished['input_contract_version'],
    proposal_mode=finished['proposal_mode'],
)
policy = semantic.SemanticPolicy(**finished['semantic_policy']['limits'])
sizes = []
base = semantic.request_payload

def measured(phase,*args,**kwargs):
    messages,size = base(phase,*args,**kwargs)
    sizes.append({'phase':phase,'bytes':size,'message_bytes':sum(len(m['content'].encode()) for m in messages)})
    if phase=='verification':
        (w/'over-budget-verification.json').write_text(json.dumps({'messages':messages,'schema':args[1]},indent=2)+'\n')
    return messages,size

semantic.request_payload=measured
requests=[]

def verify(request):
    requests.append(request)
    return verifier(request)

result=semantic.SemanticProcessor(lambda _:raw,verify,policy).process(batch,reserve=lambda **_:None)
report={'runtime_build':BUILD_ID,'source_plan_sha256':es[-1]['plan_sha256'],'source_head_sha256':es[-1]['sha256'],'recorded_proposal_sha256':digest(raw),'scope':'Zero-model in-memory replay of the exact recorded proposal and source request with synthetic batch ID; no database/source mutation or original operation retry.','provider_calls':0,'processor_status':result.status,'synthetic_phase_count':result.model_calls,'verification_provider_invocations':len(requests),'request_sizes':sizes,'limits':{'per_request_bytes':policy.max_request_bytes,'total_input_bytes':policy.max_input_bytes},'rejected':result.rejected}
(w/'budget-reproduction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
