import importlib.util,json,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from test_bounded_learning_semantics import local_batch,local_claim
from test_cognition import event
from test_semantic import encoded,proposals,verifier
from agent_memory.semantic import SemanticProcessor
from examples.longitudinal_journal import CampaignJournal
spec=importlib.util.spec_from_file_location('remaining_controls',ROOT/'.local/communication-view/run_campaign.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=json.loads((ROOT/'.local/communication-view/frozen-plan.json').read_text())
class Meter:
 def summary(self):return {'usage_unknown_calls':0,'completed_calls':0,'reserved_calls':0}
operations=[];provider_invocations=[]
with tempfile.TemporaryDirectory(prefix='memory-control-',dir=ROOT/'.local/communication-view') as directory:
 with CampaignJournal(Path(directory)/'run',plan) as journal:
  source=event('The user reported that Mara spread a blue map.')
  def propose(request):
   provider_invocations.append(request.phase);(journal.path/'GRACEFUL_STOP').write_text('Stop after this job, not inside its provider callback.\n')
   return encoded(proposals(local_claim(source,statement='The user reported that Mara spread a blue map.')))
  def verify(request):provider_invocations.append(request.phase);return verifier(request)
  result=SemanticProcessor(m.NoReplayProvider(journal,Meter(),propose,'cognition'),m.NoReplayProvider(journal,Meter(),verify,'cognition')).process(local_batch(source),reserve=lambda **_:None,on_call_result=lambda **v:operations.append(v))
  assert result.status=='completed' and [v['outcome'] for v in operations]==['completed','completed']
  assert provider_invocations==['proposal','verification']
  runner=m.GracefulRunner.__new__(m.GracefulRunner);runner.journal=journal;runner.meter=Meter()
  try:runner.check()
  except m.evaluation.CampaignStopped as error:assert error.code=='operator_stop_after_current_job'
  else:raise AssertionError('Graceful stop not enforced')
  def forbidden(_):raise AssertionError('Previous request reached provider')
  try:m.NoReplayProvider(journal,Meter(),forbidden,'host')(SimpleNamespace(request_id=next(e['payload']['request']['request_id'] for e in journal.events if e['kind']=='provider_started')))
  except m.evaluation.CampaignStopped as error:assert error.code=='logical_request_replay_forbidden'
  else:raise AssertionError('Previous request not blocked')
report={'graceful_stop_after_current_job':'passed','both_mock_phase_results_settled_completed':True,'prior_logical_request_rejected_before_provider':'passed','paid_provider_calls':0,'scope':'Deterministic control-flow check with synthetic proposal/verifier; not semantic behavioral evidence.'}
(ROOT/'.local/communication-view/control-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
