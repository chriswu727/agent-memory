import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from examples.longitudinal_journal import CampaignJournal
from examples.evaluate_longitudinal import report
w=Path('.local/communication-view');c=w/'campaign';p=json.loads((c/'plan.json').read_text()); start=int(sys.argv[1]) if len(sys.argv)>1 else 0
with CampaignJournal(c,p) as j:
 r=report(j);seen={};n=0
 for entry in j.events:
  value=entry['payload']
  if entry['kind']=='delivered_exchange':
   n+=1
   if n>start:
    t=value['transcript'];print('\nTURN',n,t['turn_id'],'BRANCH',value['branch']);print('USER:',t['user_text']);print('ANSWER:',t['assistant_text'])
  if entry['kind']=='learning_job' and value.get('record_type')=='finished' and n>start:
   result=value.get('result') or {}
   print('LEARNING',value.get('learning_phase'),value['state'],result.get('status'),'REJECTED',json.dumps(result.get('rejected')))
   for action in result.get('episode_actions',[]):
    print('EPISODE',json.dumps(action,ensure_ascii=False))
   for finding in result.get('verification_assessments',[]):
    if 'organization_fidelity' in finding:print('ROLE_AUDIT',json.dumps(finding,ensure_ascii=False))
  if entry['kind']=='turn_completed':
   after=value['after'];sources={(s['event_id'],s['revision']):s for s in after['sources']}
   current={(m['memory_id'],m['revision']):m for m in after['documents']['memories']}
   for key,m in current.items():
    if key in seen or m['derivation']['method']=='direct_capture' or n<=start:continue
    refs=[]
    for ref in m['evidence_refs']:
     source=sources.get((ref['event_id'],ref['event_revision']));span=ref['span'];text=source['observed']['content']['text'] if source else ''
     refs.append({'role':source['observed']['actor_role'] if source else None,'relationship':ref['relationship'],'text':text[span['start']:span['end']]})
    print('MEMORY',json.dumps({k:m.get(k) for k in ('memory_id','revision','statement','claim_kind','world','conditions','valid_during','recall_summary')}|{'sources':refs},ensure_ascii=False))
   seen=current
 print('\nSUMMARY',json.dumps({k:r[k] for k in ('state','turns_delivered','turns_completed','sessions_completed','user_assistance','timing')}))
 print('HEAD',j.events[-1]['sha256'],'USAGE',json.dumps(j.events[-1]['payload'].get('usage')))
 (w/f"stage-{len(r['sessions_completed'])}-report.json").write_text(json.dumps(r,indent=2)+'\n')
