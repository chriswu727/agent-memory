import hashlib
import json
import sys
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'tests'))
from test_communication_views import DRAFT, WRONG_CLAIM, WRONG_EPISODE, run
from test_bounded_learning_semantics import publication_snapshot
from agent_memory.build_identity import BUILD_ID
from agent_memory.consolidation import _assertion, _check_result
from agent_memory.contracts import validate
from agent_memory.helpers import digest

SOURCE = ROOT / '.local/source-capsules/remaining/run'
paths = [SOURCE / name for name in ('plan.json', 'journal.jsonl', 'head.json', 'calls.jsonl')]
before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
original_plan = json.loads(paths[0].read_text())
events, previous = [], digest(original_plan)
for line in paths[1].read_bytes().splitlines():
    event = json.loads(line)
    assert event['previous_sha256'] == previous and event['plan_sha256'] == digest(original_plan)
    assert event['sha256'] == digest({k: v for k, v in event.items() if k != 'sha256'})
    previous = event['sha256']
    events.append(event)
assert previous == '62a00579d71f6b1c61eb54264292ed7cbec21bd1a709fd067dbf0cf554d7321a'
last = [e['payload'] for e in events if e['kind'] == 'turn_completed'][-1]
recorded_source = next(s for s in last['after']['sources']
                       if s['event_id'] == '194d9bfe-a045-4c2c-950e-3f3c49321089')
assert recorded_source['observed']['content']['text'] == DRAFT
assert recorded_source['content_sha256'] == digest({'media_type': 'text/plain', 'text': DRAFT})
recorded_claim = next(m for m in last['after']['documents']['memories']
                      if m['memory_id'] == 'semantic-445e4297bf7ba7e06a1b22939253af0f')
assert recorded_claim['statement'] == WRONG_CLAIM
recorded_episode = next(a for e in events if e['kind'] == 'learning_job'
                        and e['payload'].get('record_type') == 'finished'
                        for a in (e['payload'].get('result') or {}).get('episode_actions', [])
                        if a['proposal_id'] == 'episode-morgan-booklet-return-casual-revision')
assert recorded_episode['organization_statement'] == WRONG_EPISODE
batch, result, requests, operations, raw = run()
assert result.status == 'completed' and len(requests) == 1
assert all(o['outcome'] == 'completed' for o in operations)
_check_result(batch, result, publication_snapshot(batch))
memory = _assertion(result.claims[0], batch, {'dependency_generation': 0},
                    {'root_event_ids': [batch.sources[1]['event_id']]})
validate('MemoryAssertion', memory)
assert json.loads(memory['statement'].split(': ', 1)[1]) == DRAFT
assert memory['derivation']['rule_version'] == 'source-composition-v3'
assert before == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
report = {
    'runtime_build': BUILD_ID,
    'source_head_sha256': previous,
    'source_plan_sha256': digest(original_plan),
    'recorded_source_content_sha256': recorded_source['content_sha256'],
    'recorded_bad_claim_sha256': digest(WRONG_CLAIM),
    'recorded_bad_episode_sha256': digest(WRONG_EPISODE),
    'fixture_texts_match_recorded_failure': True,
    'original_journal_and_ledger_unchanged': True,
    'scope': 'Synthetic IDs/scope rebind exact recorded source and wrong proposal texts to the current processor with an always-supports fake verifier. Structural regression, not real-model acceptance, historical operation recovery or source migration.',
    'provider_calls': 0,
    'synthetic_processor_phases': ['proposal', 'verification'],
    'raw_response_fingerprint_preserved': operations[0]['response_fingerprint'] == digest(raw),
    'verification_received_rendered_proposals': json.loads(requests[0].messages[-1]['content'])['proposals'],
    'schema_validated_new_memory': memory,
    'rendered_episode': result.episode_actions[0],
}
(ROOT / '.local/communication-view/recorded-regression.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ('runtime_build', 'fixture_texts_match_recorded_failure', 'original_journal_and_ledger_unchanged', 'provider_calls', 'raw_response_fingerprint_preserved')}))
