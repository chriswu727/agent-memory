import json, os, sys
from datetime import timedelta
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import psycopg
from psycopg import sql
from psycopg.rows import dict_row
from agent_memory.build_identity import BUILD_ID
from agent_memory.client import default_budget, default_read_fence
from agent_memory.helpers import Principal, digest, uid
from agent_memory.service import MemoryService
from agent_memory.storage import Database
from examples.longitudinal_journal import CampaignJournal

WORK=Path('.local/communication-view');C=WORK/'campaign';OUT=WORK/'access-age.json'
assert not OUT.exists()
assert os.environ.get('PYTHON_DOTENV_DISABLED')=='1'
assert not any('API_KEY' in k or 'API_TOKEN' in k for k in os.environ)
p=json.loads((C/'plan.json').read_text());assert p['runtime_build']==BUILD_ID
aging=json.loads((WORK/'age-diagnostic-plan.json').read_text());review=json.loads((WORK/'pre-execution-review.json').read_text())
assert digest(aging)==review['age_diagnostic_plan_sha256'] and aging['paid_provider_calls']==0
assert aging['access_day_offsets']==[0,3650] and len(aging['queries'])==2 and aging['memory_context_budget']==16000

def snapshot(conn,params,tables):
 value={}
 for table,brain_key,owner in tables:
  statement=sql.SQL('SELECT row_to_json(t) AS data FROM {} t WHERE tenant_id=%s {} AND {}=%s LIMIT 10001').format(sql.Identifier(table),sql.SQL('AND owner_id=%s') if owner else sql.SQL(''),sql.Identifier(brain_key))
  rows=conn.execute(statement,params if owner else (params[0],params[2])).fetchall();assert len(rows)<=10000
  value[table]={'rows':len(rows),'sha256':digest(sorted(digest(row['data']) for row in rows))}
 return {'tables':value,'sha256':digest(value)}

with CampaignJournal(C,p) as j:
 assert j.events[-1]['kind']=='completed'
 initial,=[e['payload'] for e in j.events if e['kind']=='initialized']
 last=j.events[-1]['payload']['usage'];assert not last['usage_unknown_calls'] and last['completed_calls']==last['reserved_calls']
 files={name:digest((C/name).read_text()) for name in ('plan.json','journal.jsonl','head.json','calls.jsonl')}
 principal=Principal(**initial['principal']);params=(principal.tenant_id,principal.principal_id,initial['brain_id'])
 with psycopg.connect(os.environ['MEMORY_DATABASE_URL'],row_factory=dict_row,autocommit=True) as conn:
  with conn.transaction(force_rollback=True):
   conn.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
   conn.execute("SET LOCAL statement_timeout='10000'")
   conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",(params[0],params[1]))
   columns=conn.execute("SELECT table_name,array_agg(column_name::text) AS columns FROM information_schema.columns WHERE table_schema=current_schema() AND table_name LIKE 'memory_%' GROUP BY table_name ORDER BY table_name").fetchall()
   tables=[(r['table_name'],'id' if r['table_name']=='memory_brains' else 'brain_id','owner_id' in r['columns']) for r in columns if {'tenant_id','id' if r['table_name']=='memory_brains' else 'brain_id'}<=set(r['columns'])]
   before=snapshot(conn,params,tables)
   brain=conn.execute('SELECT * FROM memory_brains WHERE tenant_id=%s AND owner_id=%s AND id=%s',params).fetchone();assert brain
   reference=conn.execute('SELECT clock_timestamp() AS at').fetchone()['at']
   memories=[r['document'] for r in conn.execute('SELECT document FROM memory_assertions WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s AND is_current AND NOT invalidated AND NOT deleted AND NOT suppressed AND document IS NOT NULL',params)]
   results=[];target={'brain_ref':brain['id'],'conversation_ref':'isolated-age-'+uid(),'branch_ref':'main'}
   for days in aging['access_day_offsets']:
    for item in aging['queries']:
     label,query=item['id'],item['text']
     at=(reference+timedelta(days=days)).isoformat();calls=[]
     def clock():calls.append(at);return at
     service=MemoryService(Database(os.environ['MEMORY_DATABASE_URL']),access_time_provider=clock)
     payload={'query':query,'intent':'continue_conversation','cue_event_ids':[],'additional_cues':[],
      'budget':default_budget(aging['memory_context_budget']),'evidence_mode':'prior_record_check','read_fence':default_read_fence(brain['durable_sequence']),
      'evidence_cutoff':{'mode':'through_sequence','through_sequence':brain['durable_sequence']}}
     with conn.transaction(force_rollback=True):result,_,_=service._retrieval(conn,principal,brain,target,payload)
     assert calls==[at] and result['usage']['model_calls']==result['usage']['embedding_calls']==0
     assert snapshot(conn,params,tables)==before
     results.append({'query_id':label,'access_days':days,'access_at':at,'request':payload,'result':result})
   assert snapshot(conn,params,tables)==before
  with conn.transaction(force_rollback=True):
   conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",(params[0],params[1]))
   assert snapshot(conn,params,tables)==before
 assert files=={name:digest((C/name).read_text()) for name in files}
 report={'age_diagnostic_plan_sha256':digest(aging),'runtime_build':BUILD_ID,'source_head_sha256':j.events[-1]['sha256'],'plan_sha256':digest(p),
  'scope':'Final frozen same-brain snapshot, validated access-time seam only. Not actual ten-year operation, new learning or elapsed aging.',
  'provider_calls':0,'all_tables_unchanged_after_rollback':True,'source_files_unchanged':True,'snapshot':before,
  'model_created_summary_count':sum('recall_summary' in m for m in memories),'summary_claim_kinds':{kind:sum('recall_summary' in m and m.get('claim_kind')==kind for m in memories) for kind in sorted({m.get('claim_kind','unknown') for m in memories})},'memory_catalog':memories,'retrievals':results,'semantic_review':'pending'}
 OUT.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('memory_catalog','retrievals','snapshot')}))
