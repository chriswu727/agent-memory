import os,subprocess,sys
from pathlib import Path
from agent_memory.config import Settings
root=Path.cwd();work=root/'.local/belief-inheritance';settings=Settings.from_env()
env={k:v for k,v in os.environ.items() if not k.startswith('MEMORY_') and not any(s in k.upper() for s in ('API_KEY','API_TOKEN'))}
env.update(PYTHON_DOTENV_DISABLED='1',MEMORY_DATABASE_URL=settings.database_url)
for name in ('measure-fixed-retrieval.py','measure-capabilities.py'):
 with (work/(name+'.log')).open('w') as log:
  result=subprocess.run([str(work/'wheel-env/bin/python'),'-I',str(work/name)],cwd='/tmp',env=env,stdout=log,stderr=subprocess.STDOUT)
 print(name,result.returncode)
 if result.returncode:sys.exit(result.returncode)
