import copy,json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import psycopg
from psycopg.rows import dict_row
from dotenv import dotenv_values
from agent_memory import cognition,candidates
from agent_memory.belief_store import relation_versions
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import Principal,digest
from agent_memory.service import MemoryService
from agent_memory.storage import Database
w=Path('.local/shared-communication');es=[json.loads(x) for x in (w/'campaign/journal.jsonl').read_text().splitlines()];assert es[-1]['kind']=='stopped'
i=next(e['payload'] for e in es if e['kind']=='initialized');p=Principal(**i['principal']);params=(p.tenant_id,p.principal_id,i['brain_id'])
saved=json.loads((w/'failed-runtime-context.json').read_text());request=saved['orientation_preflight']['request'];reference=saved['prepared_memory_selection']['prepared_at'];failed=json.loads((w/'failed-host-request.json').read_text());dsn=dotenv_values('.env')['MEMORY_DATABASE_URL'];service=MemoryService(Database(dsn),access_time_provider=lambda:reference)
old_collect=candidates.collect_candidates;old_merge=candidates.merge_belief_candidates;captured={}
def collect(*args,**kwargs):
 memories,state=old_collect(*args,**kwargs);captured['before_merge']=copy.deepcopy(state);return memories,state
def instrumented(memories,state,package,**kwargs):
 before=copy.deepcopy(state['rank_signals']);result=old_merge(memories,state,package,**kwargs)
 added={k:state['rank_signals'][k] for k in state['rank_signals'] if k not in before};captured['added']=added;captured['package']=copy.deepcopy(package)
 return result


with psycopg.connect(dsn,row_factory=dict_row,autocommit=True) as conn:
 def hash_tables():
  tables=conn.execute("SELECT table_name,array_agg(column_name::text) AS columns FROM information_schema.columns WHERE table_schema=current_schema() AND table_name LIKE 'memory_%' GROUP BY table_name").fetchall();out={}
  for row in tables:
   cols=set(row['columns']);key='id' if row['table_name']=='memory_brains' else 'brain_id'
   if not {'tenant_id',key}<=cols:continue
   from psycopg import sql
   own='owner_id' in cols
   rows=conn.execute(sql.SQL('SELECT row_to_json(t) AS data FROM {} t WHERE tenant_id=%s {} AND {}=%s').format(sql.Identifier(row['table_name']),sql.SQL('AND owner_id=%s') if own else sql.SQL(''),sql.Identifier(key)),params if own else (params[0],params[2])).fetchall()
   out[row['table_name']]={'rows':len(rows),'sha256':digest(sorted(digest(r['data']) for r in rows))}
  return out
 results=[]
 for label,merge in [('production_candidate',instrumented)]:
  candidates.collect_candidates=collect;candidates.merge_belief_candidates=merge;captured={}
  with conn.transaction(force_rollback=True):
   conn.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",params[:2]);before=hash_tables()
   brain=conn.execute('SELECT * FROM memory_brains WHERE tenant_id=%s AND owner_id=%s AND id=%s',params).fetchone();brain=dict(brain);brain.update(saved['orientation_preflight']['assessment']['snapshot'])
   packet=service._prepare(conn,p,brain,request,persist_preflight=False);context=cognition.render_context(packet)
   results.append({'label':label,'context':context,'context_bytes':len(context.encode()),'budget':request['payload']['budget']['max_context_tokens'],'matches_delivered_failed_context':context==failed['memory_context'],'has_original_scene':'blue paper map' in context,'has_torn_corner':'two strips of clear tape' in context,'has_original_meaning':'capable' in context,'diagnostic':{k:({str(x):y for x,y in v.items()} if k in {'added'} else v) for k,v in captured.items() if k!='before_merge'},'ranks_before_merge':{str(k):v for k,v in captured['before_merge']['rank_signals'].items()}})
  with conn.transaction(force_rollback=True):
   conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",params[:2]);assert hash_tables()==before
 candidates.collect_candidates=old_collect;candidates.merge_belief_candidates=old_merge
 report={'runtime_build':BUILD_ID,'source_head_sha256':es[-1]['sha256'],'provider_calls':0,'database_tables_unchanged_after_rollback':True,'scope':'Post-stop same-brain SQL diagnostic with original prepared request, original access timestamp and frozen brain sequence/index/generation. Final extra rows remain in underlying projections; not an exact historical database replay. Original failed delivery and journal unchanged. Runs the actual production candidate; no rank monkeypatch. Original failed transport and its exact source-sharing baseline are preserved.','runs':results}
 assert results[0]['has_original_scene'] and results[0]['has_torn_corner'] and results[0]['has_original_meaning']
 assert results[0]['context_bytes'] <= results[0]['budget']
 (Path('.local/belief-inheritance')/'recorded-sql-replay.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k not in ('context','diagnostic','ranks_before_merge')} for r in results],indent=2))
 for r in results:print(r['label'],r['diagnostic'].get('added'),r['diagnostic'].get('inherited'))
