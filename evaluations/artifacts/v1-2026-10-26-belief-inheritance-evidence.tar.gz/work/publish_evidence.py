import hashlib,io,json,os,re,subprocess,tarfile
from pathlib import Path
from urllib.parse import urlsplit
from dotenv import dotenv_values
root=Path.cwd();work=root/'.local/belief-inheritance';prefix='v1-2026-10-26-belief-inheritance';entries={}
review=json.loads((work/'final-review.json').read_text());assert review['checks']['passed'] and review['new_paid_provider_calls']==0
for path in work.iterdir():
 if path.is_file() and path.suffix in {'.py','.json','.log','.txt'}:entries['work/'+path.name]=path.read_bytes()
patch=subprocess.check_output(['git','diff','--binary',review['source_parent'],review['source_commit'],'--','src','tests']);assert hashlib.sha256(patch).hexdigest()==review['tested_source_patch_sha256'];entries['tested-source.patch']=patch
old=json.loads((root/'evaluations/v1-2026-10-26-shared-communication-evidence.json').read_text());assert hashlib.sha256((root/old['bundle']).read_bytes()).hexdigest()==old['sha256']
entries['closed-primary-manifest.json']=json.dumps(old,indent=2).encode()
configured={**dotenv_values(root/'.env'),**os.environ};secrets={v.encode() for k,v in configured.items() if v and len(v)>=12 and any(t in k.upper() for t in ('API_KEY','API_TOKEN','SECRET','PASSWORD'))}
for key,value in configured.items():
 if value and 'URL' in key.upper():
  try:password=urlsplit(value).password
  except ValueError:continue
  if password and len(password)>=8:secrets.add(password.encode())
def scan(value):
 if isinstance(value,dict):
  assert not any(k in {'reasoning_content','hidden_reasoning','chain_of_thought'} and v for k,v in value.items())
  for v in value.values():scan(v)
 elif isinstance(value,list):
  for v in value:scan(v)
for name,raw in entries.items():
 assert not any(value in raw for value in secrets),name
 assert not re.search(rb'sk-[A-Za-z0-9]{16,}',raw),name
 if name.endswith('.json'):scan(json.loads(raw))
bundle=root/'evaluations/artifacts'/(prefix+'-evidence.tar.gz')
with tarfile.open(bundle,'w:gz') as stream:
 for name,raw in sorted(entries.items()):
  member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o600;stream.addfile(member,io.BytesIO(raw))
with tarfile.open(bundle,'r:gz') as stream:
 assert set(entries)=={m.name for m in stream.getmembers()}
 for member in stream.getmembers():assert member.isfile() and stream.extractfile(member).read()==entries[member.name]
manifest={'runtime_build':review['runtime_build'],'source_commit':review['source_commit'],'source_parent':review['source_parent'],'tested_source_patch_sha256':review['tested_source_patch_sha256'],'bundle':str(bundle.relative_to(root)),'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'bytes':bundle.stat().st_size,'files':{name:hashlib.sha256(raw).hexdigest() for name,raw in sorted(entries.items())},'configured_secret_and_key_pattern_scan':'passed','json_hidden_reasoning_field_scan':'passed','member_bytes_verified':True,'scope':'New source rank repair, source/installed/desktop/performance verification, forced-rollback zero-model SQL evidence and source patch. No new paid call or host-answer retry. Closed failed primary is separately preserved and linked by its manifest.','closed_primary_manifest':'v1-2026-10-26-shared-communication-evidence.json','closed_primary_bundle_sha256':old['sha256'],'preflight_attempts':review['checks']['preflight_attempts'],'acceptance':'G4 not passed; original final answer remains failed. Age/gist and selected-span identity coverage remain unresolved.'}
(root/'evaluations'/(prefix+'-evidence.json')).write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'files':len(entries),'bytes':manifest['bytes'],'sha256':manifest['sha256'],'scans':'passed'}))
