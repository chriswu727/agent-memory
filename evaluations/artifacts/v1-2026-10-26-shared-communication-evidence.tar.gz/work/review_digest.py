import json
import sys
from pathlib import Path
path=Path(sys.argv[1]);sources={};printing=False
for line in path.read_text().splitlines():
    if line.startswith('SOURCE '):
        source=json.loads(line[7:])
        if source and 'event_id' in source:
            sources[source['event_id'],source['revision']]=source
            print('ORIGINAL',source['event_id'],source['revision'],source['observed']['actor_role'],json.dumps(source['observed']['content'].get('text'),ensure_ascii=False))
    elif line.startswith('MEMORY '):
        m=json.loads(line[7:]);print('MEMORY',json.dumps({k:m.get(k) for k in ('memory_id','revision','statement','claim_kind','world','conditions','valid_time','valid_during','recall_summary','supersedes_memory_ids','procedure','representation')},ensure_ascii=False))
        for ref in [*m.get('evidence_refs',[]),*m.get('counterexamples',[])]:
            s=sources.get((ref['event_id'],ref['event_revision']));span=ref.get('span');text=s['observed']['content'].get('text','') if s else None
            print('SELECTED',ref['relationship'],json.dumps(text[span['start']:span['end']] if text is not None and span else text,ensure_ascii=False))
    elif line.startswith(('TURN','USER:','ANSWER:')):
        printing=True;print(line)
    elif line.startswith('LEARNING'):
        printing=False;print(line)
    elif line.startswith(('EPISODE','ROLE_AUDIT','RELATION','UNFINISHED_TURN_ACCEPTED_RESULT','HEAD','SUMMARY')):
        printing=False;print(line)
    elif printing:
        print(line)
