import json
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
from dotenv import dotenv_values
w=Path('.local/shared-communication');c=w/'campaign';es=[json.loads(x) for x in (c/'journal.jsonl').read_text().splitlines()];assert es[-1]['kind']=='stopped'
initial=next(e['payload'] for e in es if e['kind']=='initialized');principal=initial['principal'];params=(principal['tenant_id'],principal['principal_id'],initial['brain_id'])
failed=json.loads((w/'failed-host-request.json').read_text());before=next(e['payload']['before'] for e in reversed(es) if e['kind']=='turn_started');map_source=next(s for s in before['sources'] if s['event_id']=='7857e899-720d-456d-b437-cfbf315d4d75')
with psycopg.connect(dotenv_values('.env')['MEMORY_DATABASE_URL'],row_factory=dict_row) as conn:
 conn.execute('SET TRANSACTION READ ONLY')
 conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",params[:2])
 source=conn.execute('SELECT id,revision,sequence,is_current,deleted,suppressed,document FROM memory_events WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s AND id=%s',(*params,map_source['event_id'])).fetchone();assert source and source['document']==map_source
 context=conn.execute('SELECT orientation_preflight,prepared_memory_selection,context_event_refs,created_at,updated_at FROM memory_runtime_turns WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s AND turn_id=%s',(*params,failed['turn_id'])).fetchone()
 prepared_at=context['prepared_memory_selection']['prepared_at']
 traces=conn.execute("SELECT document FROM memory_traces WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s AND (document->>'recorded_at')::timestamptz BETWEEN %s::timestamptz-interval '5 seconds' AND %s::timestamptz+interval '1 second' LIMIT 513",(*params,prepared_at,prepared_at)).fetchall();assert len(traces)<=512
 keys={(r['document']['memory_id'],r['document']['memory_revision']) for r in traces}
 trace_memories=conn.execute('SELECT document FROM memory_assertions WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s AND (id,revision) IN (SELECT * FROM unnest(%s::text[],%s::bigint[]))',(*params,[k[0] for k in keys],[k[1] for k in keys])).fetchall()
 all_memories=conn.execute('SELECT document FROM memory_assertions WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s AND is_current AND NOT invalidated AND NOT deleted AND NOT suppressed AND document IS NOT NULL',params).fetchall()
 operations=conn.execute('SELECT outcome,count(*) AS count FROM memory_cognitive_operations WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s GROUP BY outcome',params).fetchall()
 jobs=conn.execute("SELECT id,kind,state,attempts,model_calls,payload,result,last_error FROM memory_jobs WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s AND state NOT IN ('completed','cancelled') LIMIT 129",params).fetchall();assert len(jobs)<=128
 data={'source_head_sha256':es[-1]['sha256'],'plan_sha256':es[-1]['plan_sha256'],'source_original_unchanged_and_current':True,'map_source':dict(source),'runtime_context':dict(context),'traces_near_prepared_time':[r['document'] for r in traces],'trace_memories':[r['document'] for r in trace_memories],'current_memory_documents':[r['document'] for r in all_memories],'operation_outcomes':[dict(v) for v in operations],'remaining_jobs':[dict(v) for v in jobs],'scope':'Read-only SQL inspection of stored original response and job/source state. No replay, retrieval, re-encoding or provider call.'}
 (w/'failed-retrieval-snapshot.json').write_text(json.dumps(data,indent=2,default=str)+'\n')
 print('source_unchanged',True,'trace_count',len(traces),'operation_outcomes',operations,'remaining_jobs',[(v['kind'],v['state'],v['attempts']) for v in jobs])
