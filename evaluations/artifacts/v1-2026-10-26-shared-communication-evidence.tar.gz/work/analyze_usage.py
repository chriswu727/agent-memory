import json
import statistics
from pathlib import Path
work=Path('.local/shared-communication')
events=[]
for raw in (work/'campaign/journal.jsonl').read_bytes().splitlines(keepends=True):
    if raw.endswith(b'\n'):
        events.append(json.loads(raw))
roles={};role_tokens={};previous_usage={};turns={};turn=None
for e in events:
    p=e['payload']
    if e['kind']=='turn_started':
        turn=p['turn_id'];turns[turn]={'calls':{},'provider_seconds':0}
    if e['kind']=='provider_completed':
        role=p['role'];roles.setdefault(role,[]).append(p['elapsed_seconds'])
        current=p['usage_after']['usage_totals'];totals=role_tokens.setdefault(role,{})
        for key,value in current.items():
            totals[key]=totals.get(key,0)+value-previous_usage.get(key,0)
        previous_usage=current
        if role != 'user':
            turns[turn]['calls'][role]=turns[turn]['calls'].get(role,0)+1
            turns[turn]['provider_seconds']+=p['elapsed_seconds']
usage=next((e['payload'].get('usage_after') or e['payload'].get('usage') for e in reversed(events) if e['payload'].get('usage_after') or e['payload'].get('usage')),None)
report={'journal_head':events[-1]['sha256'],'roles':{k:{'completed':len(v),'tokens':role_tokens[k],'sum_seconds':sum(v),'median_seconds':statistics.median(v),'max_seconds':max(v)} for k,v in roles.items()},'turns':turns,'usage':usage,'scope':'Transport elapsed only, excluding local retrieval, worker processing, review pauses and fictionally elapsed days. Role totals include simulator calls. Not a billing-price estimate or user-visible latency SLA.'}
assert all(sum(t.get(key,0) for t in role_tokens.values())==value for key,value in usage['usage_totals'].items())
(work/'usage-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('roles','usage')},indent=2))
