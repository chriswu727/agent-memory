import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from agent_memory.belief_store import assertion_fingerprint
from agent_memory.contracts import validate
from examples.longitudinal_journal import CampaignJournal
w=Path('.local/shared-communication');c=w/'campaign';p=json.loads((c/'plan.json').read_text());stage=int(sys.argv[1]);seen={};episodes=[];refs=0;ordinary=0;catalog={};relations={}
with CampaignJournal(c,p) as j:
 assert j.events[-1]['kind'] in {'paused','completed'}
 assert sum(e['kind']=='session_completed' for e in j.events)==stage
 for e in j.events:
  v=e['payload']
  if e['kind']=='turn_completed':
   sources={(s['event_id'],s['revision']):s for s in v['after']['sources']}
   for s in sources.values():assert digest(s['observed']['content'])==s['content_sha256']
   catalog.update({(m['memory_id'],m['revision']):m for m in v['after']['documents']['memories']})
   for relation in v['after']['documents'].get('relations',[]):
    validate('BeliefRelation',relation)
    relations[relation['relation_id'],relation['revision']]=relation
    for endpoint in relation['endpoint_snapshots']:
     version=endpoint['memory_version'];memory=catalog[version['memory_id'],version['revision']]
     assert assertion_fingerprint(memory)==endpoint['content_sha256']
    for ref in relation['evidence_refs']:
     source=sources[ref['event_id'],ref['event_revision']]
     assert source['content_sha256']==ref['source_content_sha256']
     assert 0<=ref['span']['start']<ref['span']['end']<=len(source['observed']['content']['text'])
     refs+=1
   for m in v['after']['documents']['memories']:
    if m['derivation']['method']=='direct_capture':continue
    seen[m['memory_id'],m['revision']]=m
    for ref in m['evidence_refs']+m.get('counterexamples',[]):
     source=sources[ref['event_id'],ref['event_revision']]
     assert source['content_sha256']==ref['source_content_sha256']
     assert 0<=ref['span']['start']<ref['span']['end']<=len(source['observed']['content']['text'])
     refs+=1
  if e['kind']=='learning_completed':assert not v['stop_reason'] and v['encoding_coverage']['complete']
  if e['kind']=='learning_job' and v.get('record_type')=='finished':
   result=v.get('result') or {};audits={a['proposal_id']:a for a in result.get('verification_assessments',[])}
   for a in result.get('episode_actions',[]):
    audit=audits[a['proposal_id']];assert set(audit['organization_fidelity'])=={'attribution','modality','specificity','boundary','participant_actions'}
    assert set(audit['organization_fidelity'].values())=={'supports'};episodes.append(a)
   for group in ('claims','situation_updates','belief_links'):
    for item in result.get(group,[]):
     if 'proposal_id' not in item:continue
     assert audits[item['proposal_id']]['participant_actions_verdict']=='supports';ordinary+=1
 usage=j.events[-1]['payload']['usage'];assert usage['reserved_calls']==usage['completed_calls']==usage['usage_confirmed_calls'] and usage['usage_unknown_calls']==0
 proof={'plan_sha256':digest(p),'source_head_sha256':j.events[-1]['sha256'],'stage':stage,'derived_versions':len(seen),'stored_relation_versions':len(relations),'episode_organizations':len(episodes),'reference_checks':refs,'accepted_ordinary_verdicts_checked':ordinary,'short_views':sum('recall_summary' in m for m in seen.values()),'usage':usage,'mechanical_checks':'passed','semantic_review':'required_separately'}
 (w/f'stage-{stage}-mechanical.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
