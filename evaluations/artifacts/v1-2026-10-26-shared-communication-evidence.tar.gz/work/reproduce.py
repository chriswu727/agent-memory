import json
import sys
from pathlib import Path

ROOT=Path('/Users/yichen/projects/agent-memory')
sys.path.insert(0,str(ROOT/'tests'))
from pytest import MonkeyPatch
from test_shared_communication import replay
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
from agent_memory.source_composition import COMMUNICATION_VIEW_INPUT_VERSION, SHARED_COMMUNICATION_INPUT_VERSION

runs=[]
for version in (COMMUNICATION_VIEW_INPUT_VERSION,SHARED_COMMUNICATION_INPUT_VERSION):
    with MonkeyPatch.context() as patch:
        data,result,requests,sizes=replay(patch,version)
    entry={'contract':version,'status':result.status,'synthetic_phases':result.model_calls,
           'request_bytes':dict(sizes),'verification_invocations':len(requests),
           'claims':len(result.claims),'episodes':len(result.episode_actions)}
    if requests:
        body=json.loads(requests[0].messages[-1]['content']);table=body['verification_sources']
        entry.update(unique_sources=len(table),exact_references=sum(len(p['evidence']) for p in body['proposals']),
                     all_full_sources_match_originals=sorted(digest(s) for s in table)==sorted(digest(s) for s in data.sources),
                     source_table_sha256=digest(table),proposal_data_sha256=digest(body))
        (ROOT/'.local/shared-communication/verification-request.json').write_text(json.dumps({
            'messages':requests[0].messages,'response_schema':requests[0].response_schema},indent=2)+'\n')
    runs.append(entry)
report={'runtime_build':BUILD_ID,'provider_calls':0,'scope':'Exact closed-campaign source and model-proposal fixture in isolated installed wheel; synthetic IDs and always-supports verifier. No source/database write, old-operation retry or real-model acceptance.',
        'fixed_limits':{'per_request_bytes':98304,'total_input_bytes':196608,'model_calls':2},'runs':runs,
        'old_verification_bytes_unchanged':runs[0]['request_bytes']['verification']==121913,
        'candidate_fits_existing_limits':all(size<=98304 for size in runs[1]['request_bytes'].values()) and sum(runs[1]['request_bytes'].values())<=196608,
        'all_positive_verdicts_do_not_restore_unsafe_narration':'Source-rendered speech claims and mixed episode views are retained and publication rechecks them; test_shared_communication also tampers an accepted speech statement and requires rejection.'}
assert report['old_verification_bytes_unchanged'] and report['candidate_fits_existing_limits'] and runs[1]['status']=='completed' and runs[1]['all_full_sources_match_originals']
(ROOT/'.local/shared-communication/reproduction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
