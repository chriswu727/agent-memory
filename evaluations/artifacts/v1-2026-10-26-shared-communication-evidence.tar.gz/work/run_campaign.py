import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/yichen/projects/agent-memory')
sys.path.insert(0, str(ROOT))
import agent_memory
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
from examples import evaluate_longitudinal as evaluation
from examples.longitudinal_journal import CampaignJournal

WORK = ROOT / '.local/shared-communication'
CAMPAIGN = WORK / 'campaign'
BASE_RUNNER = evaluation.SessionRunner
BASE_PROVIDER = evaluation.RecordedProvider


class GracefulRunner(BASE_RUNNER):
    def check(self):
        super().check()
        if (self.journal.path / 'GRACEFUL_STOP').exists():
            raise evaluation.CampaignStopped('operator_stop_after_current_job')


class NoReplayProvider(BASE_PROVIDER):
    def __call__(self, request):
        if any(event['kind'] == 'provider_started'
               and event['payload']['request']['request_id'] == request.request_id
               for event in self.journal.events):
            raise evaluation.CampaignStopped('logical_request_replay_forbidden')
        return super().__call__(request)


def execute(target):
    checks = json.loads((WORK / 'checks.json').read_text())
    assert checks['passed'] and checks['runtime_build'] == BUILD_ID
    assert str(WORK / 'wheel-env') in agent_memory.__file__
    frozen = json.loads((WORK / 'frozen-plan.json').read_text())
    assert evaluation.plan(fixture='release') == frozen
    review = json.loads((WORK / 'pre-execution-review.json').read_text())
    assert review['plan_sha256'] == digest(frozen) and review['approved_for_execution']
    assert review['executor_sha256'] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == review['source_commit']
    completed = 0
    if CAMPAIGN.exists():
        with CampaignJournal(CAMPAIGN, frozen) as journal:
            journal.assert_resumable()
            completed = sum(event['kind'] == 'session_completed' for event in journal.events)
            approval = json.loads((WORK / f'stage-{completed}-review.json').read_text())
            assert approval['continue_permitted'] and approval['source_head_sha256'] == journal.events[-1]['sha256']
            assert approval['plan_sha256'] == digest(frozen)
    assert target == {0: 4, 4: 7, 7: 10, 10: 11, 11: 14}[completed]
    evaluation.SessionRunner = GracefulRunner
    evaluation.RecordedProvider = NoReplayProvider
    result = evaluation.live(CAMPAIGN, continuing=CAMPAIGN.exists(), sessions=target-completed, fixture='release')
    (WORK / f"stage-{len(result['sessions_completed'])}-report.json").write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({key: result[key] for key in (
        'state', 'sessions_completed', 'turns_completed', 'turns_delivered', 'unsettled_deliveries',
        'user_assistance', 'timing',
    )}))


if __name__ == '__main__':
    execute(int(sys.argv[1]))
