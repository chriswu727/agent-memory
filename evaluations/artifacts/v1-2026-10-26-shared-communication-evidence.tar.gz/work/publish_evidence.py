import hashlib,io,json,os,re,subprocess,tarfile
from pathlib import Path
from urllib.parse import urlsplit
from dotenv import dotenv_values
ROOT=Path.cwd();WORK=ROOT/'.local/shared-communication';PREFIX='v1-2026-10-26-shared-communication';entries={}
assert (WORK/'final-review.json').is_file()
for p in WORK.iterdir():
 if p.is_file() and p.name != 'work-state.json' and (p.suffix in {'.py','.json','.log','.txt'} or '.before-' in p.name):entries['work/'+p.name]=p.read_bytes()
for p in (WORK/'campaign').iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl'}:entries['campaign/'+p.name]=p.read_bytes()
entries['tested-source.patch']=subprocess.check_output(['git','diff','--binary','e7b94182b0833d06c433af5ff6737d3ba528288e','9778420dde4d78f6bdf5ea13db6d4f763533c609','--','src','tests','examples'])
configured={**dotenv_values(ROOT/'.env'),**os.environ}
secrets={v.encode() for k,v in configured.items() if v and len(v)>=12 and any(x in k.upper() for x in ('API_KEY','API_TOKEN','SECRET','PASSWORD'))}
for k,v in configured.items():
 if v and 'URL' in k.upper():
  try:password=urlsplit(v).password
  except ValueError:continue
  if password and len(password)>=8:secrets.add(password.encode())
def scan(v):
 if isinstance(v,dict):
  assert not any(k in {'reasoning_content','hidden_reasoning','chain_of_thought'} and x for k,x in v.items())
  for x in v.values():scan(x)
 elif isinstance(v,list):
  for x in v:scan(x)
for name,raw in entries.items():
 assert not any(v in raw for v in secrets),name
 assert not re.search(rb'sk-[A-Za-z0-9]{16,}',raw),name
 if '.jsonl' in name:
  for line in raw.splitlines():scan(json.loads(line))
 elif '.json' in name:scan(json.loads(raw))
bundle=ROOT/'evaluations/artifacts'/(PREFIX+'-evidence.tar.gz')
with tarfile.open(bundle,'w:gz') as stream:
 for name,raw in sorted(entries.items()):
  member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o600;stream.addfile(member,io.BytesIO(raw))
with tarfile.open(bundle,'r:gz') as stream:
 assert set(entries)=={m.name for m in stream.getmembers()}
 for m in stream.getmembers():assert m.isfile() and stream.extractfile(m).read()==entries[m.name]
manifest={'runtime_build':'6037bc9f9b0ec2b5c7decdfe030c8db167d5a900e39d7bc78aa4188c4b8c599a','source_commit':'9778420dde4d78f6bdf5ea13db6d4f763533c609','bundle':str(bundle.relative_to(ROOT)),'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'bytes':bundle.stat().st_size,'files':{n:hashlib.sha256(raw).hexdigest() for n,raw in sorted(entries.items())},'configured_secret_and_key_pattern_scan':'passed','json_hidden_reasoning_field_scan':'passed','member_bytes_verified':True,'campaign':json.loads((WORK/'final-review.json').read_text()),'earlier_failed_full_run':'Both earlier source-table test callback failures are included under before-update suffixes; final 5717 source tests passed. Synthetic paired replay is not a paid call or historical operation retry.'}
(ROOT/'evaluations'/(PREFIX+'-evidence.json')).write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'files':len(entries),'bytes':manifest['bytes'],'sha256':manifest['sha256'],'scans':'passed'}))
