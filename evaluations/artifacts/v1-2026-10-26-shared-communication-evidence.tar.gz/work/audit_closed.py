import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from agent_memory.contracts import validate
from agent_memory.belief_store import assertion_fingerprint
from agent_memory.source_composition import communication_view
from examples.longitudinal_journal import CampaignJournal
w=Path('.local/shared-communication');p=json.loads((w/'campaign/plan.json').read_text());stored=json.loads((w/'failed-retrieval-snapshot.json').read_text());sources={};catalog={};relations={};episodes=[];ordinary=0
with CampaignJournal(w/'campaign',p) as j:
 assert j.events[-1]['kind']=='stopped'
 for e in j.events:
  v=e['payload']
  if e['kind'] in {'turn_started','turn_completed'}:
   snapshot=v['before' if e['kind']=='turn_started' else 'after'];sources.update({(s['event_id'],s['revision']):s for s in snapshot['sources']});catalog.update({(m['memory_id'],m['revision']):m for m in snapshot['documents']['memories']});relations.update({(r['relation_id'],r['revision']):r for r in snapshot['documents'].get('relations',[])})
  if e['kind']=='runtime_completed':
   for group in ('input_events','output_events'):
    sources.update({(s['event_id'],s['revision']):s for s in v['sources'].get(group,[]) if 'observed' in s})
  if e['kind']=='learning_completed':assert v['encoding_coverage']['complete'] and not v['stop_reason']
  if e['kind']=='learning_job' and v.get('record_type')=='finished':
   result=v.get('result') or {};audits={a['proposal_id']:a for a in result.get('verification_assessments',[])}
   for action in result.get('episode_actions',[]):
    assert set(audits[action['proposal_id']]['organization_fidelity'].values())=={'supports'}
    refs=[{'event_id':r['event_id'],'event_revision':r['revision']} for r in action['member_refs']]
    assert communication_view('episode_actions',action,sources,episode_references=refs)['organization_statement']==action['organization_statement'];episodes.append(action)
   for group in ('claims','situation_updates','belief_links'):
    for item in result.get(group,[]):
     if 'proposal_id' in item:assert audits[item['proposal_id']]['participant_actions_verdict']=='supports';ordinary+=1
 catalog.update({(m['memory_id'],m['revision']):m for m in stored['current_memory_documents']})
 references=0;speech=0
 for s in sources.values():assert digest(s['observed']['content'])==s['content_sha256']
 for m in catalog.values():
  validate('MemoryAssertion',m)
  for ref in [*m['evidence_refs'],*m.get('counterexamples',[])]:
   source=sources[ref['event_id'],ref['event_revision']];assert source['content_sha256']==ref['source_content_sha256'];span=ref.get('span')
   if span:assert 0<=span['start']<span['end']<=len(source['observed']['content']['text'])
   references+=1
  if m.get('claim_kind') in {'agent_said','proposal_offered','commitment_expressed'}:
   assert communication_view('claims',m,sources)['statement']==m['statement'];speech+=1
 for r in relations.values():
  validate('BeliefRelation',r)
  for endpoint in r['endpoint_snapshots']:
   v=endpoint['memory_version'];assert assertion_fingerprint(catalog[v['memory_id'],v['revision']])==endpoint['content_sha256']
 usage=j.events[-1]['payload']['usage'];assert usage['completed_calls']==usage['reserved_calls']==usage['usage_confirmed_calls'] and usage['usage_unknown_calls']==0
 assert stored['operation_outcomes']==[{'outcome':'completed','count':78}]
 assert len(stored['remaining_jobs'])==1 and stored['remaining_jobs'][0]['attempts']==0 and stored['remaining_jobs'][0]['state']=='queued'
 result={'source_head_sha256':j.events[-1]['sha256'],'plan_sha256':digest(p),'campaign_state':'stopped','source_versions':len(sources),'stored_memory_versions_checked':len(catalog),'derived_versions':sum(m['derivation']['method']!='direct_capture' for m in catalog.values()),'exact_speech_quotes_recomputed':speech,'episodes_recomputed':len(episodes),'stored_relations':len(relations),'reference_hash_and_span_checks':references,'accepted_participant_verdicts_checked':ordinary,'optional_short_views':sum('recall_summary' in m for m in catalog.values()),'final_turn_encoding_settled':True,'unfinished_history_jobs':1,'unknown_provider_usage':0,'mechanical_checks':'passed','semantic_citation_coverage':'Not passed: three first-turn named statements omit the self-introduction from their selected spans; facts are present in the same complete source.','behavioral_acceptance':'failed last-map-label; mechanical source integrity is not useful-memory acceptance.','source_original_unchanged':stored['source_original_unchanged_and_current']}
 (w/'closed-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
