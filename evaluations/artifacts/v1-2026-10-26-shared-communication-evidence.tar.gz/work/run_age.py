import os
import subprocess
from pathlib import Path
from dotenv import dotenv_values
root=Path('/Users/yichen/projects/agent-memory')
config=dotenv_values(root/'.env')
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('API_KEY','API_TOKEN'))}
env['PYTHON_DOTENV_DISABLED']='1'
env['MEMORY_DATABASE_URL']=config['MEMORY_DATABASE_URL']
subprocess.run([str(root/'.local/shared-communication/wheel-env/bin/python'),'-I',str(root/'.local/shared-communication/access_age.py')],cwd=root,env=env,check=True)
