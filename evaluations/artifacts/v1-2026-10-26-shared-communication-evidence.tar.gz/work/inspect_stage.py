import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from examples.evaluate_longitudinal import report
from examples.longitudinal_journal import CampaignJournal

WORK=Path('.local/shared-communication');CAMPAIGN=WORK/'campaign'
plan=json.loads((CAMPAIGN/'plan.json').read_text());start=int(sys.argv[1]) if len(sys.argv)>1 else 0
sources={};memories={};seen_memories=set();seen_relations=set();printed_sources=set();n=0;turn=None


def remember(snapshot):
    sources.update({(s['event_id'],s['revision']):s for s in snapshot.get('sources',[])})
    memories.update({(m['memory_id'],m['revision']):m for m in snapshot.get('documents',{}).get('memories',[])})


def references(item):
    refs=[*item.get('evidence_refs',[]),*item.get('counterexamples',[])]
    for ref in refs:
        key=(ref['event_id'],ref['event_revision'])
        if key not in printed_sources:
            source=sources.get(key)
            print('SOURCE',json.dumps(source if source else {'MISSING_SOURCE':key},ensure_ascii=False))
            printed_sources.add(key)
    return refs


with CampaignJournal(CAMPAIGN,plan) as journal:
    completed={e['payload']['transcript']['turn_id'] for e in journal.events if e['kind']=='turn_completed'}
    for event in journal.events:
        value=event['payload']
        if event['kind']=='turn_started':
            turn=value['turn_id'];remember(value['before'])
        if event['kind']=='runtime_completed':
            for group in ('input_events','output_events'):
                for source in value['sources'].get(group,[]):
                    if 'observed' in source:sources[source['event_id'],source['revision']]=source
        if event['kind']=='delivered_exchange':
            n+=1
            if n>start:
                t=value['transcript'];print('\nTURN',n,t['turn_id'],'BRANCH',value['branch'])
                print('USER:',t['user_text']);print('ANSWER:',t['assistant_text'])
        if event['kind']=='learning_job' and value.get('record_type')=='finished' and n>start:
            result=value.get('result') or {}
            print('LEARNING',value.get('learning_phase'),value['state'],result.get('status'),
                  'REJECTED',json.dumps(result.get('rejected')))
            print('PUBLICATION',json.dumps(result.get('publication')))
            for action in result.get('episode_actions',[]):
                for ref in action['member_refs']:
                    key=(ref['event_id'],ref['revision'])
                    if key not in printed_sources:
                        print('SOURCE',json.dumps(sources.get(key,{'MISSING_SOURCE':key}),ensure_ascii=False));printed_sources.add(key)
                print('EPISODE',json.dumps(action,ensure_ascii=False))
            for assessment in result.get('verification_assessments',[]):
                if 'organization_fidelity' in assessment:print('ROLE_AUDIT',json.dumps(assessment,ensure_ascii=False))
            if turn not in completed:
                for group in ('claims','situation_updates','belief_links'):
                    for item in result.get(group,[]):
                        references(item)
                        print('UNFINISHED_TURN_ACCEPTED_RESULT',group,json.dumps(item,ensure_ascii=False))
        if event['kind']=='turn_completed':
            remember(value['after'])
            for memory in value['after']['documents']['memories']:
                key=(memory['memory_id'],memory['revision'])
                if key not in seen_memories and memory['derivation']['method']!='direct_capture' and n>start:
                    references(memory)
                    print('MEMORY',json.dumps(memory,ensure_ascii=False))
                seen_memories.add(key)
            for relation in value['after']['documents'].get('relations',[]):
                key=(relation['relation_id'],relation['revision'])
                if key not in seen_relations and n>start:
                    references(relation)
                    endpoints=[]
                    for ref in [relation['source_memory_version'],*relation['target_memory_versions']]:
                        m=memories.get((ref['memory_id'],ref['revision']))
                        endpoints.append(m if m else {'MISSING_ENDPOINT':ref})
                        if m:references(m)
                    print('RELATION',json.dumps(relation,ensure_ascii=False))
                    print('RELATION_ENDPOINTS',json.dumps(endpoints,ensure_ascii=False))
                seen_relations.add(key)
    summary=report(journal)
    print('\nSUMMARY',json.dumps({k:summary[k] for k in (
        'state','turns_delivered','turns_completed','sessions_completed','user_assistance','timing')}))
    print('HEAD',journal.events[-1]['sha256'],'USAGE',json.dumps(journal.events[-1]['payload'].get('usage')))
    (WORK/f"stage-{len(summary['sessions_completed'])}-report.json").write_text(json.dumps(summary,indent=2)+'\n')
