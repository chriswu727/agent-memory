import json,platform,statistics,sys,time
from pathlib import Path
root=Path('/Users/yichen/projects/agent-memory');sys.path.insert(0,str(root/'tests'))
from test_belief_semantic import known
from test_cognition import event,scope
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
from agent_memory.semantic import LATEST_INPUT_CONTRACT_VERSION,belief_capabilities
sources=[event(f'Before study session {i}, I talk about my day.',i+1) for i in range(32)]
memories=[known(source,'The user reports talking about their day before studying.') for source in sources]
samples=[]
for _ in range(5):
 start=time.perf_counter_ns();result=belief_capabilities(scope(),sources,memories,input_contract_version=LATEST_INPUT_CONTRACT_VERSION)
 samples.append((time.perf_counter_ns()-start)/1e6)
 assert len(result['endpoints'])==32 and all(len(entry['abstraction_partner_indices'])==31 for entry in result['endpoints'])
report={'version':'relation-capability-performance-v1','runtime_build':BUILD_ID,'input_contract':LATEST_INPUT_CONTRACT_VERSION,
 'platform':platform.platform(),'processor':'Apple M4','python':platform.python_version(),'endpoint_count':32,
 'eligible_pair_count':496,'samples_ms':samples,'median_ms':statistics.median(samples),'median_limit_ms':100,
 'passed':statistics.median(samples)<100,'cache_state':'No discarded warmup; five consecutive calls in one process.',
 'fixture':'Thirty-two independent user-source study reports with complete known semantic endpoint metadata.',
 'fixture_sha256':digest({'sources':sources,'memories':memories}),'metadata_bytes':len(json.dumps(result,separators=(',',':')).encode()),
 'provider_calls':0,'embedding_calls':0}
(root/'.local/shared-communication/capability-performance.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
