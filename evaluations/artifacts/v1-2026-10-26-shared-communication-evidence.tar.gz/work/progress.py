import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
w=Path('.local/shared-communication');c=w/'campaign';p=json.loads((c/'plan.json').read_text());events=[];previous=digest(p)
for line in (c/'journal.jsonl').read_bytes().splitlines(keepends=True):
 if not line.endswith(b'\n'):break
 e=json.loads(line);assert e['previous_sha256']==previous and e['plan_sha256']==digest(p)
 assert digest({k:v for k,v in e.items() if k!='sha256'})==e['sha256']
 previous=e['sha256'];events.append(e)
usage=next((e['payload'].get('usage_after') or e['payload'].get('usage') for e in reversed(events) if e['payload'].get('usage_after') or e['payload'].get('usage')),None)
turn=next((e['payload']['turn_id'] for e in reversed(events) if e['kind']=='turn_started'),None)
print(json.dumps({'last_event':events[-1]['kind'],'current_turn':turn,'sessions_complete':sum(e['kind']=='session_completed' for e in events),'replies_delivered':sum(e['kind']=='delivered_exchange' for e in events),'turns_learning_complete':sum(e['kind']=='turn_completed' for e in events),'usage':usage,'head':previous}))
if len(sys.argv)>1:
 start=int(sys.argv[1]);count=0
 for e in events:
  if e['kind']=='delivered_exchange':
   count+=1
   if count>start:
    t=e['payload']['transcript'];print('TURN',count,t['turn_id'],e['payload']['branch']);print('USER',t['user_text']);print('ANSWER',t['assistant_text'])
