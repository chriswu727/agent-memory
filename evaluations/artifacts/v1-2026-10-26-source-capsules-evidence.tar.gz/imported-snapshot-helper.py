import copy,hashlib,json,sys
from datetime import UTC,datetime
from pathlib import Path
ROOT=Path('/Users/yichen/projects/agent-memory');sys.path.insert(0,str(ROOT))
import agent_memory
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import Principal,digest,uid
from agent_memory.config import Settings
from agent_memory.storage import Database
from agent_memory.service import MemoryService
from agent_memory.api import create_app
from agent_memory.client import MemoryClient
from agent_memory.runtime_client import RuntimeClient
from examples import evaluate_longitudinal as evaluation
from examples.evaluation_host import loopback_server
from examples.longitudinal_journal import CampaignJournal
from examples.longitudinal_scenario import validate_scenario
WORK=ROOT/'.local/coherent-recall';PRIMARY=WORK/'campaign';TAIL=WORK/'tail';TAIL.mkdir(exist_ok=True)
BASE_PLAN=evaluation.plan

def source_events():
 p=json.loads((PRIMARY/'plan.json').read_text())
 with CampaignJournal(PRIMARY,p) as journal:
  events=journal.events;assert events[-1]['kind']=='stopped'
  assert events[-1]['payload']['error']['code']=='incomplete_response'
  assert events[-1]['payload']['usage']['completed_calls']==40
  assert events[-1]['payload']['usage']['usage_unknown_calls']==0
  return p,events

def snapshot(initial):
 settings=Settings.from_env();principal=Principal(**initial['principal']);service=MemoryService(Database(settings.database_url,settings.migration_database_url));token=uid()
 config=Settings(database_url=settings.database_url,api_keys={hashlib.sha256(token.encode()).hexdigest():principal})
 with loopback_server(create_app(config,service=service)) as url,MemoryClient(url,token,initial['brain_id']) as memory:
  documents=evaluation.Trial(service,principal,memory.brain_id).documents()
  sources=evaluation.source_snapshot(service,principal,memory.brain_id,limit=1024)
  return {'sources':sorted(sources,key=lambda s:(s['sequence'],s['event_id'])),'documents':{k:sorted(v,key=digest) for k,v in documents.items()},'cognitive_usage':RuntimeClient(memory).cognitive_usage()}

def freeze():
 assert not (TAIL/'frozen-plan.json').exists()
 primary,events=source_events();assert BASE_PLAN(fixture='release')==primary
 initial=next(e['payload'] for e in events if e['kind']=='initialized');frozen_snapshot=snapshot(initial)
 completed=[e for e in events if e['kind']=='turn_completed'];assert len(completed)==9
 assert sum(e['kind']=='session_completed' for e in events)==5
 failed_text=primary['scenario']['sessions'][5]['turns'][0]['choices'][0]['text']
 assert any(s['observed']['content']['text']==failed_text for s in frozen_snapshot['sources'])
 ledger_raw=(PRIMARY/'calls.jsonl').read_bytes();records=[json.loads(l) for l in ledger_raw.splitlines()]
 last=records[-1];assert last['finish_reason']=='length'
 assert last['usage']['completion_tokens']==last['usage']['completion_tokens_details']['reasoning_tokens']==4096
 planned=copy.deepcopy(primary);story=planned['scenario'];omitted={'first-caption','caption-tone'}
 omitted_cases=[c for c in story['private_review']['cases'] if c['at_turn'] in omitted]
 story['sessions']=[s for s in story['sessions'] if s['id']!='map-caption']
 story['private_review']['cases']=[c for c in story['private_review']['cases'] if c['at_turn'] not in omitted]
 story['fixture_id']='release-life-v1-diagnostic-tail';validate_scenario(story)
 remaining=story['sessions'][5:];turns=[t for s in remaining for t in s['turns']]
 actor_calls=sum(len(t['choices'])>1 for t in turns);assert len(turns)==15 and actor_calls==7
 additions={'host':15,'cognition':90,'user':7}
 planned.update(diagnostic_only=True,semantic_acceptance='primary_failed_two_required_cases_unpassed',fixture='release-tail',
  host_output_tokens=16384,alternate_callback_from_session=6,allocation=additions,
  max_calls=40+sum(additions.values()),max_reserved_output_tokens=468992+15*16384+90*16384+7*512,
  imported_primary_plan_sha256=digest(primary),imported_primary_head_sha256=events[-1]['sha256'],
  imported_primary_ledger_sha256=hashlib.sha256(ledger_raw).hexdigest(),imported_snapshot_sha256=digest(frozen_snapshot),
  inherited_usage=events[-1]['payload']['usage'],unpassed_primary_cases=omitted_cases,
  executor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  review='Separately reviewed diagnostic tail; original primary remains failed. No failed host call is retried.',
  amendment={'reason':'Known finish_reason=length with all 4096 output tokens consumed by reasoning; no caption body delivered. Keep failed input and runtime row unchanged. Skip caption and its dependent tone revision, continue only distinct remaining authored tasks.',
   'authority':'Current user requests substantial varied longitudinal testing and earlier explicitly authorizes purposeful DeepSeek usage. This is a manually reviewed separate diagnostic, not an automatic replacement or an allowance reset.',
   'host_output':'16384 includes reasoning and visible output; no retry, no new paid judge or cue probes.',
   'case_boundary':'Original eighteen-case rubric remains authoritative in the closed primary. Two omitted cases remain unpassed; diagnostic subset cannot pass G4.',
   'continuity':'Import actual nine delivered/learning-complete turns and five completed sessions with explicit original event hashes. Adopt the current post-failure source snapshot and forty-call ledger for the first diagnostic checkpoint. No source edit, hidden memory injection, replayed generation or old job retry.',
   'callback':'Core callback from the second new tail session; same provider, model and settings. Not cross-vendor testing.',
   'review_schedule':[8,10,13], 'new_call_ceiling':112,'new_reserved_output_ceiling':1723904,
   'stop':'Any new failed provider/required processing, unknown usage or critical source/answer defect closes the tail; no automatic follow-up.'})
 assert planned['max_calls']==152 and planned['max_reserved_output_tokens']==2192896
 (TAIL/'frozen-plan.json').write_text(json.dumps(planned,indent=2)+'\n')
 (TAIL/'initial-snapshot.json').write_text(json.dumps(frozen_snapshot,indent=2)+'\n')
 (TAIL/'calls.jsonl').write_bytes(ledger_raw)
 adopted_at=datetime.now(UTC).isoformat()
 with CampaignJournal(TAIL/'run',planned) as journal:
  for e in events:
   if e['kind'] not in {'initialized','delivered_exchange','runtime_completed','turn_completed','session_completed'}:continue
   payload=copy.deepcopy(e['payload']);payload['imported_from_primary_event_sha256']=e['sha256']
   if e['kind']=='session_completed' and payload['session_id']=='fiction':
    payload['original_checkpoint']={k:payload[k] for k in ('snapshot_sha256','ledger_sha256')}
    payload.update(snapshot_sha256=digest(frozen_snapshot),ledger_sha256=digest(records),checkpoint_adopted_at=adopted_at,adoption_reason='Known failed caption input remains in storage; charged host failure remains in ledger. This adoption does not complete or retry that turn.')
   journal.append(e['kind'],payload)
  journal.append('diagnostic_checkpoint_adopted',{'primary_head_sha256':events[-1]['sha256'],'snapshot_sha256':digest(frozen_snapshot),'ledger_sha256':digest(records),'omitted_primary_cases':[c['id'] for c in omitted_cases],'new_call_ceiling':112,'new_reserved_output_ceiling':1723904})
  journal.append('paused',{'reason':'diagnostic_initialized_after_source_review','usage':planned['inherited_usage']})
 # The metering ledger belongs to the diagnostic run directory.
 (TAIL/'run/calls.jsonl').write_bytes(ledger_raw)
 review={'approved_for_execution':False,'plan_sha256':digest(planned),'executor_sha256':planned['executor_sha256'],'snapshot_sha256':digest(frozen_snapshot),'primary_source_review':'Read all nine answers and twenty-nine published derived versions, including eight episode organizations. No new critical publication defect. Initial stage limits and rejected proposals remain recorded. No personal short views formed.','pending':'Check frozen plan, imported prefix provenance, source identity and finite budget before dispatch.'}
 (TAIL/'pre-execution-review.json').write_text(json.dumps(review,indent=2)+'\n')
 print(json.dumps({'plan_sha256':digest(planned),'new_inputs':15,'new_calls_max':112,'primary_stays_failed':True,'output_limit':16384}))

def execute(target):
 planned=json.loads((TAIL/'frozen-plan.json').read_text());review=json.loads((TAIL/'pre-execution-review.json').read_text())
 assert review['approved_for_execution'] and review['plan_sha256']==digest(planned)
 assert planned['executor_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 assert BUILD_ID==planned['runtime_build'] and 'wheel-env' in agent_memory.__file__
 base=BASE_PLAN(fixture='release');original,_=source_events();assert base==original
 assert base['code_fingerprints']==planned['code_fingerprints']
 with CampaignJournal(TAIL/'run',planned) as journal:
  journal.assert_resumable();count=sum(e['kind']=='session_completed' for e in journal.events)
  assert target=={5:8,8:10,10:13}[count]
  if count!=5:
   approval=json.loads((TAIL/f'stage-{count}-review.json').read_text());assert approval['continue_permitted'] and approval['source_head_sha256']==journal.events[-1]['sha256']
 evaluation.plan=lambda **_:copy.deepcopy(planned)
 result=evaluation.live(TAIL/'run',continuing=True,sessions=target-count,fixture='release')
 (TAIL/f'stage-{len(result["sessions_completed"])}-report.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ('state','sessions_completed','turns_completed','turns_delivered','timing','user_assistance')}))

if __name__=='__main__':
 if sys.argv[1]=='freeze':freeze()
 else:execute(int(sys.argv[1]))
