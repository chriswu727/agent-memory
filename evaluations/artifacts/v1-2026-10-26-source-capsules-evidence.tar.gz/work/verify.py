import json,os,subprocess,sys
from pathlib import Path
from agent_memory.build_identity import BUILD_ID
from agent_memory.config import Settings
root=Path.cwd();w=root/'.local/source-capsules';settings=Settings.from_env()
env={k:v for k,v in os.environ.items() if not k.startswith(('DEEPSEEK','OPENAI','ANTHROPIC','MEMORY_'))}
env.update(PYTHON_DOTENV_DISABLED='1',MEMORY_DATABASE_URL=settings.database_url,MEMORY_MIGRATION_DATABASE_URL=settings.migration_database_url or settings.database_url)
build=BUILD_ID
with (w/'full-final.log').open('w') as stream:
 result=subprocess.run([sys.executable,'-m','pytest','-q'],env=env,stdout=stream,stderr=subprocess.STDOUT)
from agent_memory.build_identity import manifest_digest,package_manifest
assert manifest_digest(package_manifest(root/'src/agent_memory',root))==build
(w/'full-final-result.json').write_text(json.dumps({'runtime_build':build,'exit_code':result.returncode})+'\n')
print(result.returncode)
raise SystemExit(result.returncode)
