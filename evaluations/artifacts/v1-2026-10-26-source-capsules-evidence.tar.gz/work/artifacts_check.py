import hashlib,json,subprocess,tarfile,zipfile
from pathlib import Path
from agent_memory.build_identity import BUILD_ID, package_manifest
root=Path.cwd();directory=root/'.local/source-capsules'; source=package_manifest(root/'src/agent_memory',root)
wheel=directory/'dist/agent_memory_runtime-0.1.0-py3-none-any.whl'
sdist=directory/'dist/agent_memory_runtime-0.1.0.tar.gz'
installed=json.loads(subprocess.check_output([str(directory/'wheel-env/bin/python'),'-c',
 "import json,hashlib; from pathlib import Path; import agent_memory; from agent_memory.build_identity import BUILD_ID,package_manifest; p=Path(agent_memory.__file__).parent; print(json.dumps({'path':str(p),'build':BUILD_ID,'files':{k:hashlib.sha256(v).hexdigest() for k,v in package_manifest(p,p.parent).items()}}))"]))
assert str(directory/'wheel-env') in installed['path']
with zipfile.ZipFile(wheel) as w,tarfile.open(sdist) as t:
 for name,raw in source.items():
  assert w.read('agent_memory/'+name)==raw,name
  source_name=('architecture/memory-contract.schema.json' if name=='resources/memory-contract.schema.json'
               else 'migrations/'+Path(name).name if name.startswith('resources/migrations/')
               else 'src/agent_memory/'+name)
  assert t.extractfile('agent_memory_runtime-0.1.0/'+source_name).read()==raw,name
  assert installed['files'][name]==hashlib.sha256(raw).hexdigest(),name
assert installed['build']==BUILD_ID
report={'runtime_build':BUILD_ID,'source_sdist_wheel_installed_match':True,
 'files':{name:hashlib.sha256(raw).hexdigest() for name,raw in source.items()},
 'archives':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (wheel,sdist)}}
(directory/'artifacts.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'runtime_build':BUILD_ID,'matching_runtime_files':len(source)}))
