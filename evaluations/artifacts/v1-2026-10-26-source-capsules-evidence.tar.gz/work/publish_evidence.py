import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
from pathlib import Path
from urllib.parse import urlsplit

from dotenv import dotenv_values

ROOT = Path.cwd()
WORK = ROOT / '.local/source-capsules'
PREFIX = 'v1-2026-10-26-source-capsules'
entries = {}
for path in WORK.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.log'}:
        entries['work/' + path.name] = path.read_bytes()
for path in (WORK / 'remaining').rglob('*'):
    if path.is_file() and path.suffix in {'.py', '.json', '.jsonl', '.log', '.txt'}:
        entries['remaining/' + str(path.relative_to(WORK / 'remaining'))] = path.read_bytes()
entries['imported-snapshot-helper.py'] = (ROOT / '.local/coherent-recall/diagnostic_tail.py').read_bytes()
entries['tested-source.patch'] = subprocess.check_output([
    'git', 'diff', '--binary', 'b6e44d06d7bbb0593d03aee1116c0751dabb3fa0',
    'd05bc3839bb5728f65ff89af57a27107173507f7', '--',
    'src', 'sdk/typescript', 'tests', 'examples', 'architecture/memory-contract.schema.json',
])
configured = {**dotenv_values(ROOT / '.env'), **os.environ}
secrets = {value.encode() for key, value in configured.items()
           if value and len(value) >= 12
           and any(part in key.upper() for part in ('API_KEY', 'API_TOKEN', 'SECRET', 'PASSWORD'))}
for key, value in configured.items():
    if value and 'URL' in key.upper():
        try:
            password = urlsplit(value).password
        except ValueError:
            continue
        if password and len(password) >= 8:
            secrets.add(password.encode())


def scan(value):
    if isinstance(value, dict):
        assert not any(key in {'reasoning_content', 'hidden_reasoning', 'chain_of_thought'} and item
                       for key, item in value.items())
        for item in value.values():
            scan(item)
    elif isinstance(value, list):
        for item in value:
            scan(item)


for name, raw in entries.items():
    assert not any(secret in raw for secret in secrets), name
    assert not re.search(rb'sk-[A-Za-z0-9]{16,}', raw), name
    if name.endswith('.json'):
        scan(json.loads(raw))
    if name.endswith('.jsonl'):
        for line in raw.splitlines():
            scan(json.loads(line))
bundle = ROOT / 'evaluations/artifacts' / (PREFIX + '-evidence.tar.gz')
with tarfile.open(bundle, 'w:gz') as stream:
    for name, raw in sorted(entries.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        member.mode = 0o600
        stream.addfile(member, io.BytesIO(raw))
with tarfile.open(bundle, 'r:gz') as stream:
    assert {member.name for member in stream.getmembers()} == set(entries)
    for member in stream.getmembers():
        assert member.isfile() and stream.extractfile(member).read() == entries[member.name]
manifest = {
    'runtime_build': 'd6b347347d30f283db8efa8f5b344211985722536e6e06acbb4223d6900cc7e5',
    'source_commit': 'd05bc3839bb5728f65ff89af57a27107173507f7',
    'bundle': str(bundle.relative_to(ROOT)),
    'sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(),
    'bytes': bundle.stat().st_size,
    'files': {name: hashlib.sha256(raw).hexdigest() for name, raw in sorted(entries.items())},
    'configured_secret_and_key_pattern_scan': 'passed',
    'json_hidden_reasoning_field_scan': 'passed',
    'member_bytes_verified': True,
    'remaining_diagnostic': 'Closed by bound stage-8 review; journal remains paused, continue_permitted=false. No current paid operation was interrupted.',
    'usage': 'Cumulative66 includes inherited52. New14 calls,163822 known tokens. Do not add cumulative and inherited counts.',
    'original_failed_history': 'Preserved separately by v1-2026-10-26-coherent-recall-evidence.json; unchanged and not reclassified.',
}
(ROOT / 'evaluations' / (PREFIX + '-evidence.json')).write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(entries), 'bytes': manifest['bytes'], 'sha256': manifest['sha256'], 'scans': 'passed'}))
