import hashlib,io,json,os,re,subprocess,tarfile
from pathlib import Path
from dotenv import dotenv_values
ROOT=Path.cwd();W=ROOT/'.local/coherent-recall';OUT=ROOT/'evaluations';PREFIX='v1-2026-10-26-coherent-recall'
names=['artifacts.json','checks.json','frozen-plan.json','pre-execution-review.json','source-binding-amendment.json','full-final.log','full-final-result.json','installed-delivery-final.log','desktop-delivery-final.log','typescript-tests-complete.log','typescript-typecheck-final.log','ruff-final.log','retrieval-performance.json','capability-performance.json','stage-4-report.json','stage-4-inspection.txt','stage-4-review.json','stage-4-mechanical.json','early-answer-review.json','stage-5-report.json','stopped-inspection.txt','stopped-review.json','failed-caption-request.json','run_campaign.py','inspect_stage.py','review_checks.py','diagnostic_tail.py','full-source-before-schema-sharing.log','full-source-result-before-schema-sharing.json','first-full-interruption.json','schema-sharing-followup.log','schema-sharing-fixed.log','schema-sharing-fixed.log','scoped-interruption.json','typescript-tests.log','typescript-tests-final.log','source-context-initial.log','source-context-regressions.log','known-malformed.log']
entries={'work/'+name:(W/name).read_bytes() for name in names if (W/name).is_file()}
for p in (W/'campaign').iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl'}:entries['primary/'+p.name]=p.read_bytes()
for name in ('frozen-plan.json','pre-execution-review.json','initial-snapshot.json','stopped-inspection.txt','stopped-review.json','regular-week-request.json','pre-regular-week-snapshot.json','stage-6-report.json','stage-8.log'):
 p=W/'tail'/name
 if p.is_file():entries['tail/'+name]=p.read_bytes()
for p in (W/'tail/run').iterdir():
 if p.is_file() and (p.suffix in {'.json','.jsonl'} or p.name=='STOP'):entries['tail/run/'+p.name]=p.read_bytes()
entries['tested-source.patch']=subprocess.check_output(['git','diff','--binary','ef4567b57528d1112080afcb1eb6014c98f196bc','b6e44d06d7bbb0593d03aee1116c0751dabb3fa0','--','src','sdk/typescript','tests','examples','architecture/memory-contract.schema.json'])
secrets={v.encode() for k,v in {**dotenv_values(ROOT/'.env'),**os.environ}.items() if v and len(v)>=12 and any(x in k.upper() for x in ('API_KEY','API_TOKEN','SECRET','PASSWORD'))}
def scan(v):
 if isinstance(v,list):
  for x in v:scan(x)
 if isinstance(v,dict):
  assert not any(k in {'reasoning_content','hidden_reasoning','chain_of_thought'} and x for k,x in v.items())
  for x in v.values():scan(x)
for name,raw in entries.items():
 assert not any(v in raw for v in secrets),name
 assert not re.search(rb'sk-[A-Za-z0-9]{16,}',raw),name
 if name.endswith('.json'):scan(json.loads(raw))
 if name.endswith('.jsonl'):
  for line in raw.splitlines():scan(json.loads(line))
bundle=OUT/'artifacts'/(PREFIX+'-evidence.tar.gz')
with tarfile.open(bundle,'w:gz') as stream:
 for name,raw in sorted(entries.items()):
  member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o600;stream.addfile(member,io.BytesIO(raw))
with tarfile.open(bundle,'r:gz') as stream:
 assert {m.name for m in stream.getmembers()}==set(entries)
 for m in stream.getmembers():assert m.isfile() and stream.extractfile(m).read()==entries[m.name]
manifest={'runtime_build':'1a418e3a7e5446f3b69cd50437e36454556cd405492cf4dc5ff9c96141a1890e','source_commit':'b6e44d06d7bbb0593d03aee1116c0751dabb3fa0','bundle':str(bundle.relative_to(ROOT)),'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'bytes':bundle.stat().st_size,'files':{n:hashlib.sha256(v).hexdigest() for n,v in sorted(entries.items())},'configured_secret_and_key_pattern_scan':'passed','json_hidden_reasoning_field_scan':'passed','member_bytes_verified':True,'original_primary_and_tail_journals_closed':True,'usage':'Tail ledger cumulative52 includes imported primary40; do not double-count.'}
(OUT/(PREFIX+'-evidence.json')).write_text(json.dumps(manifest,indent=2)+'\n');print({'files':len(entries),'bytes':manifest['bytes'],'sha256':manifest['sha256']})
