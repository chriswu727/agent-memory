import copy,json,sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path.cwd()))
from agent_memory import cognition
from agent_memory.build_identity import BUILD_ID
from agent_memory.runtime import BrainRuntime,RuntimePolicy
from agent_memory.client import default_budget,default_read_fence,integration_capabilities
from agent_memory.helpers import digest
inputs=Path('.local/coherent-recall');w=Path('.local/source-capsules');snapshot=json.loads((inputs/'tail/pre-regular-week-snapshot.json').read_text());frozen=json.loads((inputs/'tail/regular-week-request.json').read_text());plan=json.loads((inputs/'tail/frozen-plan.json').read_text())
memories=snapshot['documents']['memories'];events=snapshot['sources'];scope=copy.deepcopy(memories[0]['scope']);scope.update(conversation_id='morgan-return-normal',branch_id='main');seq=max(e['sequence'] for e in events);generations={m['disclosure_basis']['dependency_generation'] for m in memories};assert len(generations)==1
state={'durable_sequence':seq,'indexed_sequence':seq,'dependency_generation':generations.pop(),'scope_generation':scope['scope_generation'],'candidate_total':len(memories),'belief_relations':snapshot['documents']['relations']}
runtime=BrainRuntime(SimpleNamespace(brain_id=scope['brain_id']),lambda _:None,instructions=plan['host_instructions'],policy=RuntimePolicy(**plan['runtime_policy']));query=frozen['messages'][-1]['content'];limit=runtime._memory_budget(frozen['turn_id'],query)
request={'query':query,'intent':'continue_conversation','cue_event_ids':[],'additional_cues':[],'budget':default_budget(limit),'read_fence':default_read_fence(seq),'evidence_mode':'prior_record_check','evidence_cutoff':{'mode':'through_sequence','through_sequence':seq}}
old=digest(snapshot);result=cognition.recall(scope,request,memories,events,state)
working={'scope':scope,'revision':0,'through_sequence':seq,'items':[],'open_loops':[],'updated_at':events[-1]['system_time']['recorded_at']}
payload={'turn_id':frozen['turn_id'],'latest_input_event_ids':[],'read_fence':default_read_fence(seq),'budget':default_budget(limit),'capabilities':integration_capabilities(),'evidence_mode':'prior_record_check','evidence_cutoff':{'mode':'through_sequence','through_sequence':seq}}
packet=cognition.prepare(scope,payload,working,result,state);prompt=runtime._prompt(frozen['turn_id'],query,packet)
full=cognition.recall(scope,{**request,'budget':default_budget(200000)},memories,events,state)
initial=next(e for e in events if e['observed']['content']['text'].startswith("I'm Morgan."))
report={'runtime_build':BUILD_ID,'snapshot_sha256':old,'original_context_has_monday':'monday' in frozen['memory_context'].lower(),'new_context_has_monday':'monday' in prompt.memory_context.lower(),'original_bytes':len(frozen['memory_context'].encode()),'new_bytes':len(prompt.memory_context.encode()),'budget_bytes':limit,'recall':result,'full':full,'packet':packet,'initial_event_id':initial['event_id'],'source_unchanged':digest(snapshot)==old,'provider_calls':0}
(w/'schedule-reproduction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'recall','full','packet'}}))
for i,item in enumerate(full['items']):
 m=item['memory'];refs={r['event_id'] for r in m['evidence_refs']};print(i,initial['event_id'] in refs,m['statement'],item.get('relevance'),item.get('score'))
print('PASSAGE ORIGINS',[(p['evidence_ref']['event_id'],p['text'][:100]) for p in result.get('source_passages',[])])
