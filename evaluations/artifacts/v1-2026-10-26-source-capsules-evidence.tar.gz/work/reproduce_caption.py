import copy,json,sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path.cwd()))
from agent_memory import cognition
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
from agent_memory.runtime import BrainRuntime,RuntimePolicy
w=Path('.local/source-capsules');old=Path('.local/source-composition')
snapshot=json.loads((old/'pre-caption-snapshot.json').read_text());frozen=json.loads((old/'first-caption-request.json').read_text());plan=json.loads((old/'frozen-plan.json').read_text())
memories=snapshot['documents']['memories'];events=snapshot['sources'];scope=copy.deepcopy(memories[0]['scope']);scope['conversation_id']='morgan-map-caption';scope['branch_id']='main';sequence=max(e['sequence'] for e in events)
assert all(e['observed']['content']['text']!=frozen['messages'][-1]['content'] for e in events)
generations={m['disclosure_basis']['dependency_generation'] for m in memories};assert len(generations)==1
state={'durable_sequence':sequence,'indexed_sequence':sequence,'dependency_generation':generations.pop(),'scope_generation':scope['scope_generation'],'candidate_total':len(memories),'belief_relations':snapshot['documents']['relations']}
runtime=BrainRuntime(SimpleNamespace(brain_id=scope['brain_id']),lambda _:None,instructions=plan['host_instructions'],policy=RuntimePolicy(**plan['runtime_policy']))
query=frozen['messages'][-1]['content'];limit=runtime._memory_budget(frozen['turn_id'],query)
from agent_memory.client import default_budget,default_read_fence,integration_capabilities
request={'query':query,'intent':'continue_conversation','cue_event_ids':[],'additional_cues':[],
 'budget':default_budget(limit),'read_fence':default_read_fence(sequence),'evidence_mode':'prior_record_check',
 'evidence_cutoff':{'mode':'through_sequence','through_sequence':sequence}}
before=digest(snapshot)
result=cognition.recall(scope,request,memories,events,state)
working={'scope':scope,'revision':0,'through_sequence':sequence,'items':[],'open_loops':[], 'updated_at':events[-1]['system_time']['recorded_at']}
payload={'turn_id':frozen['turn_id'],'latest_input_event_ids':[],'read_fence':default_read_fence(sequence),
 'budget':default_budget(limit),'capabilities':integration_capabilities(),'evidence_mode':'prior_record_check',
 'evidence_cutoff':{'mode':'through_sequence','through_sequence':sequence}}
packet=cognition.prepare(scope,payload,working,result,state);prompt=runtime._prompt(frozen['turn_id'],query,packet)
assert digest(snapshot)==before
new_context=prompt.memory_context
report={'runtime_build':BUILD_ID,'source_snapshot_sha256':before,'frozen_request_sha256':digest(frozen),
 'scope':'Frozen pre-caption sources/assertions and original query, in-process recall/prepare; no future facts, provider calls or source writes. Not an exact reproduction of the old SQL route, live clock or asynchronous indexing.',
 'original_context_contains_expressed_meaning':'capable' in frozen['memory_context'].lower(),
 'new_context_contains_expressed_meaning':'capable' in new_context.lower(),'source_passages':len(result.get('source_passages',[])),
 'original_context_bytes':len(frozen['memory_context'].encode()),'new_context_bytes':len(new_context.encode()),
 'memory_budget_bytes':limit,'complete_prompt_bytes':prompt.input_tokens_estimate,'max_prompt_bytes':runtime.policy.max_input_tokens,
 'provider_calls':0,'source_unchanged':True,'request':request,'recall':result,'packet':packet,'prompt':list(prompt.messages)}
(w/'caption-reproduction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('request','recall','packet','prompt')}))
assert report['new_context_contains_expressed_meaning'] and not report['original_context_contains_expressed_meaning']
