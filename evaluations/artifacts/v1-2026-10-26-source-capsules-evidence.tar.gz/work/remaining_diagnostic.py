import copy,hashlib,importlib.util,json,sys
from datetime import UTC,datetime
from pathlib import Path
ROOT=Path('/Users/yichen/projects/agent-memory');sys.path.insert(0,str(ROOT))
import agent_memory
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
from examples import evaluate_longitudinal as evaluation
from examples.longitudinal_journal import CampaignJournal
from examples.longitudinal_scenario import validate_scenario
WORK=ROOT/'.local/source-capsules';SOURCE=ROOT/'.local/coherent-recall/tail/run';RUN=WORK/'remaining/run';DIRECTORY=RUN.parent
BASE_PLAN=evaluation.plan;BASE_RUNNER=evaluation.SessionRunner;BASE_PROVIDER=evaluation.RecordedProvider
SNAPSHOT_HELPER=ROOT/'.local/coherent-recall/diagnostic_tail.py'
spec=importlib.util.spec_from_file_location('diagnostic_snapshot',SNAPSHOT_HELPER);snapshot_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(snapshot_module)

def source_history():
 plan=json.loads((SOURCE/'plan.json').read_text())
 with CampaignJournal(SOURCE,plan) as journal:
  events=journal.events;assert events[-1]['kind']=='stopped' and events[-1]['payload']['error']['code']=='operator_stop'
  usage=events[-1]['payload']['usage'];assert usage['completed_calls']==52 and usage['usage_unknown_calls']==0
 return plan,events

def freeze():
 DIRECTORY.mkdir(exist_ok=True);assert not (DIRECTORY/'frozen-plan.json').exists()
 source,events=source_history();planned=BASE_PLAN(fixture='release');assert planned['code_fingerprints']==source['code_fingerprints']
 initial=next(e['payload'] for e in events if e['kind']=='initialized');snapshot=snapshot_module.snapshot(initial)
 story=copy.deepcopy(source['scenario']);skipped=[c for c in story['private_review']['cases'] if c['at_turn']=='regular-week']
 story['sessions']=[s for s in story['sessions'] if s['id']!='return-normal'];story['private_review']['cases']=[c for c in story['private_review']['cases'] if c['at_turn']!='regular-week'];story['fixture_id']='release-life-v1-final-diagnostic-remaining';validate_scenario(story)
 new_turns=[t for s in story['sessions'][6:] for t in s['turns']];assert len(new_turns)==11 and sum(len(t['choices'])>1 for t in new_turns)==5
 prefix_complete=[e for e in events if e['kind']=='turn_completed'];assert len(prefix_complete)==11
 assert sum(e['kind']=='session_completed' for e in events)==6 and sum(e['kind']=='delivered_exchange' for e in events)==12
 primary=ROOT/'.local/coherent-recall/campaign/journal.jsonl';all_previous=[json.loads(l) for l in primary.read_text().splitlines()]+events
 prohibited=sorted({e['payload']['request']['request_id'] for e in all_previous if e['kind']=='provider_started'})
 ledger=(SOURCE/'calls.jsonl').read_bytes();records=[json.loads(l) for l in ledger.splitlines()];usage=events[-1]['payload']['usage']
 planned.update(scenario=story,fixture='release-remaining-diagnostic',diagnostic_only=True,
  semantic_acceptance='original_primary_and_tail_failed_no_G4_credit_for_omitted_cases',host_output_tokens=16384,alternate_callback_from_session=6,
  allocation={'host':11,'cognition':66,'user':5},max_calls=134,max_reserved_output_tokens=1913856,
  inherited_usage=usage,imported_source_plan_sha256=digest(source),imported_source_head_sha256=events[-1]['sha256'],
  imported_source_ledger_sha256=hashlib.sha256(ledger).hexdigest(),imported_snapshot_sha256=digest(snapshot),
  unpassed_original_cases=source['unpassed_primary_cases']+skipped,unexecuted_dependent_turns=['caption-tone','short-plan'],
  forbidden_inherited_request_ids=prohibited,executor_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  snapshot_helper_sha256=hashlib.sha256(SNAPSHOT_HELPER.read_bytes()).hexdigest(),
  amendment={'authority':'Current user requests substantial varied testing and authorizes purposeful DeepSeek usage; this is a manually reviewed distinct-input diagnostic after locally verified production retrieval repairs, not an automatic retry/reset or a clean replacement campaign.',
   'source_preservation':'Keep all sources, twelve actual deliveries, eleven learning-complete exchanges, six completed sessions, charged fifty-two-call ledger, and original cancelled/uncertain operation. Do not recover, settle, retry or relabel it.',
   'known_usage_boundary':'All actual provider dispatches have complete independently metered transport usage and responses. The original operator-stop wrapper nevertheless classified one cognitive operation uncertain; that discrepancy remains visible and charged.',
   'excluded_cases':'Caption and dependent revision remain unpassed; regular-week remains failed, dependent short-plan unexecuted. Original eighteen-case rubric is retained in the primary; diagnostic subset cannot pass G4.',
   'prefix':'Actual completed transcripts imported with original event hashes; failed regular-week delivery retained as delivery/runtime completion only, never a learning-complete turn. Actor history follows only actual learning-complete exchanges; upcoming fixed class-change does not react to or repair the failed answer.',
   'checkpoint':'Adopt current post-failure source snapshot and unchanged fifty-two-call ledger; replay only cached last good turn zine-progress, with forbidden generation/delivery callbacks. No source edit or future-fact injection.',
   'new_runtime':'Source-unit family admission plus bounded-source-context-v2; no semantic re-encoding or source migration.',
   'limits':{'additional_calls':82,'additional_reserved_output_tokens':1264128,'cumulative_calls':134,'cumulative_reserved_output_tokens':1913856,'brain_budget':'Existing156-call cognitive quota unchanged; failed reservations remain charged.'},
   'reviews_after_total_completed_sessions':[8,9,12],
   'stop':'Any new provider/required-processing/unknown-usage or critical answer/publication failure closes this diagnostic. No further automatic diagnostic. GRACEFUL_STOP is checked only at runner/job boundaries so a current paid semantic job can return and settle normally; no next job is claimed. RecordedProvider does not consume that marker.',
   'no_replay':'Prior logical request IDs are forbidden before dispatch. No additional paid short probes or answer judge.'})
 assert sum(planned['allocation'].values())==82 and 52+82==planned['max_calls']
 assert usage['reserved_output_tokens']+1264128==planned['max_reserved_output_tokens']
 (DIRECTORY/'frozen-plan.json').write_text(json.dumps(planned,indent=2)+'\n');(DIRECTORY/'initial-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
 with CampaignJournal(RUN,planned) as journal:
  for e in events:
   if e['kind'] not in {'initialized','delivered_exchange','runtime_completed','turn_completed','session_completed'}:continue
   p=copy.deepcopy(e['payload']);p['imported_from_source_event_sha256']=e['sha256']
   if e['kind']=='session_completed' and p['session_id']=='correction-and-tool':
    p['previous_checkpoint']={k:p[k] for k in ('snapshot_sha256','ledger_sha256')};p.update(snapshot_sha256=digest(snapshot),ledger_sha256=digest(records),checkpoint_adopted_at=datetime.now(UTC).isoformat(),adoption_reason='Keep failed regular-week delivery and uncertain cancelled encoding; do not complete or retry them. Last good cached reply is zine-progress.')
   journal.append(e['kind'],p)
  journal.append('diagnostic_checkpoint_adopted',{'source_head_sha256':events[-1]['sha256'],'snapshot_sha256':digest(snapshot),'excluded_failed_or_dependent_turns':['first-caption','caption-tone','regular-week','short-plan'],'inherited_usage':usage})
  journal.append('paused',{'reason':'initialized_distinct_remaining_diagnostic','usage':usage})
 (RUN/'calls.jsonl').write_bytes(ledger)
 review={'approved_for_execution':False,'plan_sha256':digest(planned),'executor_sha256':planned['executor_sha256'],'snapshot_helper_sha256':planned['snapshot_helper_sha256'],'scope':'Only eleven distinct remaining authored inputs. Original gate failed; omitted cases never become passes. No old host/learning request regenerated.','pending':'Final local checks, source commit, prefix/source/ledger validation and graceful-stop control check.'}
 (DIRECTORY/'pre-execution-review.json').write_text(json.dumps(review,indent=2)+'\n')
 print(json.dumps({'plan_sha256':digest(planned),'new_inputs':11,'additional_call_ceiling':82,'original_gate':'failed','runtime_build':BUILD_ID}))

class GracefulRunner(BASE_RUNNER):
 def check(self):
  super().check()
  if (self.journal.path/'GRACEFUL_STOP').exists():raise evaluation.CampaignStopped('operator_stop_after_current_job')

class NoReplayProvider(BASE_PROVIDER):
 def __call__(self,request):
  if request.request_id in self.journal.plan.get('forbidden_inherited_request_ids',[]):raise evaluation.CampaignStopped('inherited_request_replay_forbidden')
  if any(e['kind']=='provider_started' and e['payload']['request']['request_id']==request.request_id for e in self.journal.events):raise evaluation.CampaignStopped('logical_request_replay_forbidden')
  return super().__call__(request)

def execute(target):
 planned=json.loads((DIRECTORY/'frozen-plan.json').read_text());review=json.loads((DIRECTORY/'pre-execution-review.json').read_text())
 assert review['approved_for_execution'] and review['plan_sha256']==digest(planned)
 assert planned['executor_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 assert planned['snapshot_helper_sha256']==hashlib.sha256(SNAPSHOT_HELPER.read_bytes()).hexdigest()
 assert BUILD_ID==planned['runtime_build'] and 'wheel-env' in agent_memory.__file__
 base=BASE_PLAN(fixture='release');source,events=source_history();assert base['code_fingerprints']==planned['code_fingerprints']
 assert events[-1]['sha256']==planned['imported_source_head_sha256']
 checks=json.loads((WORK/'checks.json').read_text());assert checks['passed'] and checks['runtime_build']==BUILD_ID
 with CampaignJournal(RUN,planned) as journal:
  journal.assert_resumable();count=sum(e['kind']=='session_completed' for e in journal.events);assert target=={6:8,8:9,9:12}[count]
  if count!=6:
   approval=json.loads((DIRECTORY/f'stage-{count}-review.json').read_text());assert approval['continue_permitted'] and approval['source_head_sha256']==journal.events[-1]['sha256']
 evaluation.plan=lambda **_:copy.deepcopy(planned);evaluation.SessionRunner=GracefulRunner;evaluation.RecordedProvider=NoReplayProvider
 result=evaluation.live(RUN,continuing=True,sessions=target-count,fixture='release')
 (DIRECTORY/f'stage-{len(result["sessions_completed"])}-report.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ('state','sessions_completed','turns_completed','turns_delivered','timing','user_assistance')}))

if __name__=='__main__':
 if sys.argv[1]=='freeze':freeze()
 else:execute(int(sys.argv[1]))
