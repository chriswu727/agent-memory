import hashlib
import json
import os
import platform
import re
import statistics
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlparse

import agent_memory
from agent_memory.build_identity import BUILD_ID
from agent_memory.client import default_budget, default_read_fence
from agent_memory.config import Settings
from agent_memory.contracts import CONTRACT_VERSION
from agent_memory.helpers import Principal, uid
from agent_memory.service import MemoryService
from agent_memory.storage import Database

ROOT = Path('/Users/yichen/projects/agent-memory')
BASE = ROOT / '.local/source-capsules'
SOURCE = ROOT / 'evaluations/v1-2026-10-25-retrieval-performance.json'
OUTPUT = BASE / 'retrieval-performance.json'
PUBLIC = ROOT / 'evaluations/v1-2026-10-26-source-capsules-performance.json'
EXPECTED_BUILD = 'd6b347347d30f283db8efa8f5b344211985722536e6e06acbb4223d6900cc7e5'

assert BUILD_ID == EXPECTED_BUILD
assert str(Path(agent_memory.__file__).resolve()).startswith(str(BASE / 'wheel-env/'))
assert sys.flags.isolated == 1 and Path.cwd().resolve() == Path('/tmp').resolve()
assert os.environ.get('PYTHON_DOTENV_DISABLED') == '1'
assert not any('API_KEY' in key or 'API_TOKEN' in key for key in os.environ)
assert not OUTPUT.exists() and not PUBLIC.exists()
suite_log = (BASE / 'full-final.log').read_text()
terminal_summary = re.findall(r'^.*\d+ passed.* in [\d.]+s.*$', suite_log, flags=re.M)
assert terminal_summary
checks = json.loads((BASE / 'checks.json').read_text())
assert checks['passed'] and checks['runtime_build'] == BUILD_ID, 'Resolve and verify every source failure before measurement'
prior = json.loads(SOURCE.read_bytes())
identity = prior['fixture_identity']
queries = [sample['query'] for sample in prior['samples']]
assert queries == [f'zeta{number:05d}' for number in range(94, 988, 47)]
assert prior['records'] == 10000 and len(queries) == 20 and prior['p95_limit_ms'] == 500
settings = Settings.from_env()
connection = urlparse(settings.database_url)
assert connection.hostname in {'127.0.0.1', 'localhost'} and connection.port == 55432
database = Database(settings.database_url)
service = MemoryService(database)
assert service.semantic_processor is None and service.embedding_provider is None
principal = Principal(identity['tenant_id'], identity['principal_id'])
target = {'brain_ref': identity['brain_id'], 'conversation_ref': 'seed', 'branch_ref': 'main'}
params = (identity['tenant_id'], identity['principal_id'], identity['brain_id'])
with database.transaction(principal) as conn:
    brain = conn.execute('SELECT durable_sequence,indexed_sequence FROM memory_brains '
                         'WHERE tenant_id=%s AND owner_id=%s AND id=%s', params).fetchone()
    counts = {}
    for table in ('memory_events', 'memory_assertions'):
        counts[table] = conn.execute('SELECT count(*) AS count FROM ' + table
                                    + ' WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s '
                                    'AND is_current AND NOT deleted AND NOT suppressed', params).fetchone()['count']
assert brain['durable_sequence'] == 10000 and brain['indexed_sequence'] == 10000
assert counts == {'memory_events': 10000, 'memory_assertions': 10000}

report = {
    'version': 'v1-fixed-lexical-retrieval-regression-v1',
    'state': 'started',
    'measured_at': datetime.now(UTC).isoformat(),
    'build_id': BUILD_ID,
    'source': str(SOURCE.relative_to(ROOT)),
    'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'artifact_manifest': 'evaluations/v1-2026-10-26-source-capsules-artifacts.json',
    'fixture_identity': identity,
    'records': 10000,
    'fixture_preflight': {'counts': counts, **brain},
    'platform': platform.platform(),
    'processor': prior['processor'],
    'python': platform.python_version(),
    'execution': 'Installed wheel; isolated Python (-I), working directory /tmp.',
    'cache_state': 'Existing previously used fixture. No discarded warmups; OS/database caches were not flushed.',
    'scope': 'Local in-process public lexical recall, cue_recovery intent; no HTTP or provider waiting.',
    'limitations': [
        'One ordered pass through the existing 20 literal-label queries; no cold-cache or production SLA claim.',
        'This cue_recovery benchmark does not exercise the continue_conversation source-neighborhood route.',
        'No semantic inference, vector provider, relation-fanout, worker-throughput, or model-response benchmark.',
        'The final integrated source suite had finished; other machine load was not controlled or randomized.',
    ],
    'full_source_suite_terminal_summary_before_measurement': terminal_summary[-1].strip(),
    'full_source_suite_build_id': 'd6b347347d30f283db8efa8f5b344211985722536e6e06acbb4223d6900cc7e5',
    'query_contract': {
        'intent': 'cue_recovery', 'additional_cues': [], 'cue_event_ids': [],
        'budget': default_budget(16000), 'read_fence': default_read_fence(),
        'evidence_cutoff': {'mode': 'through_sequence', 'through_sequence': 10000},
    },
    'sample_count_planned': 20,
    'discarded_warmups': 0,
    'p95_definition': 'Nineteenth sorted observation out of twenty (nearest-rank).',
    'p95_limit_ms': 500,
    'samples': [],
    'provider_calls': 0,
}
OUTPUT.write_text(json.dumps(report, indent=2) + '\n')
for query in queries:
    request = {
        'contract_version': CONTRACT_VERSION, 'message_type': 'request', 'request_id': uid(),
        'action': 'recall', 'target': target, 'payload': {'query': query, **report['query_contract']},
    }
    begin = time.perf_counter_ns()
    try:
        response = service.handle(principal, request)
    except Exception as error:
        elapsed_ms = (time.perf_counter_ns() - begin) / 1_000_000
        sample = {'query': query, 'elapsed_ms': elapsed_ms, 'outcome': 'exception',
                  'exception_type': type(error).__name__, 'recall_status': None, 'source_found': False}
    else:
        elapsed_ms = (time.perf_counter_ns() - begin) / 1_000_000
        result = response.get('result') or {}
        sample = {
            'query': query, 'elapsed_ms': elapsed_ms, 'outcome': response['outcome'],
            'recall_status': result.get('status'),
            'source_found': any(query in item['memory']['statement'] for item in result.get('items', [])),
            'provider_calls': result.get('usage', {}).get('model_calls', 0),
            'embedding_calls': result.get('usage', {}).get('embedding_calls', 0),
        }
    report['samples'].append(sample)
    OUTPUT.write_text(json.dumps(report, indent=2) + '\n')
timings = [sample['elapsed_ms'] for sample in report['samples']]
report.update(
    state='finished', finished_at=datetime.now(UTC).isoformat(),
    median_ms=statistics.median(timings), p95_ms=sorted(timings)[18], max_ms=max(timings),
    expected_labels_found=sum(sample['source_found'] for sample in report['samples']),
    all_sources_found=all(sample['source_found'] for sample in report['samples']),
    all_requests_completed=all(sample['outcome'] == 'completed' for sample in report['samples']),
)
report['provider_calls'] = sum(sample.get('provider_calls', 0) for sample in report['samples'])
report['embedding_calls'] = sum(sample.get('embedding_calls', 0) for sample in report['samples'])
report['passed'] = (report['all_sources_found'] and report['all_requests_completed']
                    and report['p95_ms'] <= report['p95_limit_ms']
                    and report['provider_calls'] == report['embedding_calls'] == 0)
OUTPUT.write_text(json.dumps(report, indent=2) + '\n')
with PUBLIC.open('x') as stream:
    stream.write(OUTPUT.read_text())
print(json.dumps({key: report[key] for key in (
    'build_id', 'median_ms', 'p95_ms', 'max_ms', 'expected_labels_found', 'provider_calls', 'embedding_calls', 'passed',
)}, indent=2))
