import json,sys,hashlib,os
from pathlib import Path
from types import SimpleNamespace
import psycopg
from psycopg.rows import dict_row
from agent_memory import cognition
from agent_memory.build_identity import BUILD_ID
from agent_memory.config import Settings
from agent_memory.storage import Database
from agent_memory.service import MemoryService
from agent_memory.helpers import Principal,digest
from agent_memory.client import default_budget,default_read_fence,integration_capabilities
from agent_memory.runtime import BrainRuntime,RuntimePolicy
ROOT=Path('/Users/yichen/projects/agent-memory');old=ROOT/'.local/coherent-recall';work=ROOT/'.local/source-capsules'
frozen=json.loads((old/'tail/regular-week-request.json').read_text());before=json.loads((old/'tail/pre-regular-week-snapshot.json').read_text());plan=json.loads((old/'tail/frozen-plan.json').read_text());principal=Principal(before['sources'][0]['scope']['tenant_id'],before['sources'][0]['scope']['principal_binding_id']);brain_id=before['sources'][0]['scope']['brain_id'];params=(principal.tenant_id,principal.principal_id,brain_id)
query=frozen['messages'][-1]['content'];runtime=BrainRuntime(SimpleNamespace(brain_id=brain_id),lambda _:None,instructions=plan['host_instructions'],policy=RuntimePolicy(**plan['runtime_policy']));limit=runtime._memory_budget(frozen['turn_id'],query);cutoff=max(s['sequence'] for s in before['sources']);at=before['sources'][-1]['system_time']['recorded_at'];settings=Settings.from_env();service=MemoryService(Database(settings.database_url),access_time_provider=lambda:at);assert service.semantic_processor is None and service.embedding_provider is None
request={'query':query,'intent':'continue_conversation','cue_event_ids':[],'additional_cues':[],'budget':default_budget(limit),'read_fence':default_read_fence(cutoff),'evidence_mode':'prior_record_check','evidence_cutoff':{'mode':'through_sequence','through_sequence':cutoff}}
target={'brain_ref':brain_id,'conversation_ref':'schedule-read-only-diagnostic','branch_ref':'main'}
with psycopg.connect(settings.database_url,row_factory=dict_row,autocommit=True) as conn:
 with conn.transaction(force_rollback=True):
  conn.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
  conn.execute("SET LOCAL statement_timeout='15000'")
  conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",(params[0],params[1]))
  def graph():
   tables=('memory_brains','memory_events','memory_assertions','memory_working_states','memory_belief_relations')
   value={}
   for table in tables:
    key='id' if table=='memory_brains' else 'brain_id'
    rows=conn.execute('SELECT row_to_json(t) AS data FROM '+table+' t WHERE tenant_id=%s AND owner_id=%s AND '+key+'=%s',params).fetchall()
    value[table]=sorted(digest(r['data']) for r in rows)
   return digest(value)
  original=graph();trace_before=conn.execute('SELECT document FROM memory_traces WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s',params).fetchall();trace_hash=digest(sorted(digest(r) for r in trace_before));brain=conn.execute('SELECT * FROM memory_brains WHERE tenant_id=%s AND owner_id=%s AND id=%s',params).fetchone()
  recalled,working,state=service._retrieval(conn,principal,brain,target,request)
  payload={'turn_id':frozen['turn_id'],'latest_input_event_ids':[],'read_fence':default_read_fence(cutoff),'budget':default_budget(limit),'capabilities':integration_capabilities(),'evidence_mode':'prior_record_check','evidence_cutoff':request['evidence_cutoff']}
  packet=cognition.prepare(service._scope(principal,brain,target),payload,working,recalled,state)
  rendered=packet['model_context'];known={(s['event_id'],s['revision']):s for s in before['sources']}
  for p in recalled.get('source_passages',[]):
   ref=p['evidence_ref'];source=known[ref['event_id'],ref['event_revision']];assert source['content_sha256']==ref['source_content_sha256'] and source['observed']['content']['text']==p['text']
  versions={(m['memory_id'],m['revision']) for m in before['documents']['memories']}
  assert graph()==original
  report={'runtime_build':BUILD_ID,'scope':'Current actual SQL route under rollback-only repeatable-read transaction, fixed access seam and frozen source cutoff. Later database state is present; this is not an exact replay of the original database snapshot. Full quoted originals are independently matched to the pre-request snapshot.','snapshot_sha256':digest(before),'original_context_has_monday':False,'new_context_has_monday':'monday' in rendered.lower(),'new_context_has_thursday':'thursday' in rendered.lower(),'budget_bytes':limit,'context_bytes':len(rendered.encode()),'all_quotes_match_frozen_originals':True,'all_selected_memory_versions_preexisted':all((i['memory']['memory_id'],i['memory']['revision']) in versions for i in recalled['items']),'source_graph_unchanged':True,'graph_sha256':original,'provider_calls':0,'request':request,'result':recalled,'packet':packet}
  report['instrumentation_writes']='Normal recall traces written only inside forced rollback; original semantic/source graph unchanged.'
 with conn.transaction(force_rollback=True):
  conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",(params[0],params[1]))
  trace_after=conn.execute('SELECT document FROM memory_traces WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s',params).fetchall()
  assert graph()==original and digest(sorted(digest(r) for r in trace_after))==trace_hash
 report['source_and_trace_graphs_unchanged_after_rollback']=True
 (work/('sql-'+sys.argv[1]+'.json')).write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k not in {'request','result','packet'}}))
