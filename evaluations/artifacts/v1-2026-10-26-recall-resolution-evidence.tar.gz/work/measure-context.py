import json
import sys
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / 'tests'))
from test_bounded_learning_semantics import local_claim, process
from test_recall_resolution import TEXT, example, memory_case, read
from test_semantic import proposals

from agent_memory.build_identity import BUILD_ID
from agent_memory.citation_coverage import SOURCE_ACT_INPUT_VERSION

source, batch, result, current = example()
previous_result, previous = process(replace(batch, input_contract_version=SOURCE_ACT_INPUT_VERSION),
                                    proposals(local_claim(source, statement='The user reported: ' + TEXT)))
assert previous_result.status == result.status == 'completed'
def size(request):
    return len(json.dumps(request.messages, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
source, memory = memory_case()
fresh = read(source, memory, at=memory['system_time']['recorded_at'])
aged = read(source, memory)
expanded = read(source, memory, 'Grandma yellow lid')
report = {'runtime_build': BUILD_ID,
          'scope': 'One deterministic source and matched bounded local proposal/verification pair; UTF-8 wire bytes, not measured provider tokens or general efficiency. Zero provider calls.',
          'old_message_bytes': {request.phase: size(request) for request in previous},
          'new_message_bytes': {request.phase: size(request) for request in current},
          'model_context_bytes': {'fresh': len(fresh['model_context'].encode()),
                                  'aged': len(aged['model_context'].encode()),
                                  'expanded': len(expanded['model_context'].encode())},
          'full_source_and_statement_retained': TEXT in source['observed']['content']['text'] and TEXT in memory['statement'],
          'source_summary_verdict': result.verification_assessments[0]['recall_summary_verdict']}
Path('.local/recall-resolution/metrics.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
