import argparse
import copy
import json
import os
import sys
import time
from contextlib import ExitStack
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path.cwd()))
from agent_memory.build_identity import BUILD_ID
from agent_memory.chat_provider import ChatCompletionsGenerator
from agent_memory.config import Settings
from agent_memory.helpers import digest
from agent_memory.runtime import BrainRuntime, ModelRequest, RuntimePolicy
from agent_memory.semantic import CognitiveBatch, LATEST_INPUT_CONTRACT_VERSION, SemanticPolicy, SemanticProcessor
from agent_memory.semantic_provider import ChatCompletionsSemanticProvider
from examples.evaluation_support import MeteredTransport

ROOT = Path.cwd()
WORK = ROOT / '.local/recall-resolution'
OUT = WORK / 'live-followup'
OLD = ROOT / '.local/longitudinal-repair-live/plan.json'

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def prepare():
    assert not OUT.exists()
    old = json.loads(OLD.read_text())
    host = json.loads((ROOT / '.local/longitudinal-v7-cues/plan.json').read_text())
    host_policy = {**host['runtime_policy'], 'max_input_tokens': 32000}
    batch = copy.deepcopy(old['batch'])
    batch.update(batch_id='resolution-diagnostic', input_contract_version=LATEST_INPUT_CONTRACT_VERSION)
    inputs = []
    for item in old['host_inputs']:
        if item['case']['id'] not in {'unaided', 'broadcue', 'specificcue'}:
            continue
        runtime = BrainRuntime(SimpleNamespace(brain_id=item['brain_id']), lambda _: None,
                               instructions=host['host_instructions'], policy=RuntimePolicy(**host_policy))
        request = runtime._prompt('resolution-' + item['case']['id'], item['case']['text'], item['packet'])
        inputs.append({'case': item['case'], 'request': asdict(request)})
    assert len(inputs) == 3
    plan = {'runtime_build': BUILD_ID, 'created_at': datetime.now(UTC).isoformat(),
            'executor_sha256': digest(Path(__file__).read_text()), 'original_plan_sha256': digest(old),
            'source_archive_sha256': old['source_archive_sha256'], 'batch': batch,
            'model': old['model'], 'semantic_policy': asdict(SemanticPolicy(
                max_wall_time_ms=600000, max_output_tokens=16384, max_response_bytes=65536)),
            'host_inputs': inputs, 'max_calls': 5, 'max_reserved_output_tokens': 45056,
            'host_runtime_policy': host_policy,
            'provider_envelope_bytes': 262144, 'host_output_tokens': 4096, 'host_timeout_seconds': 240,
            'cognitive_effort': 'low', 'host_effort': 'high',
            'scope': 'Isolated two-call encoding and three previously frozen source-backed host contexts regenerated with current host protocol. No source writes, new user story, background learning, delivery, answer-review model, retry or longitudinal acceptance claim.',
            'rubric': {'encoding': 'Every accepted full and short expression must retain source attribution, complete citation support, negation and qualifications. Optional summary absence is not successful layered recall. No question premise may become fact.',
                       'host': 'Review each entire answer, including first-person drafts. Recover original scene and expressed meaning; supplied cue facts get no recall credit. No unsupported time of day, location, sound, actions or emotions. A disclaimer cannot excuse later invention.'},
            'stop_rules': ['Unknown usage or provider failure stops execution.', 'Pause after encoding for source review.',
                           'Keep failures; no replacement calls. No changes to frozen requests or allowance after first call.']}
    OUT.mkdir(mode=0o700)
    write(OUT / 'plan.json', plan)
    print(json.dumps({'state': 'prepared_no_calls', 'plan_sha256': digest(plan), 'runtime_build': BUILD_ID}))

def live(stage):
    plan = json.loads((OUT / 'plan.json').read_text())
    assert plan['runtime_build'] == BUILD_ID
    assert plan['executor_sha256'] == digest(Path(__file__).read_text())
    check = json.loads((WORK / 'checks.json').read_text())
    assert check['passed'] and check['runtime_build'] == BUILD_ID
    review = json.loads((OUT / 'plan-review.json').read_text())
    assert review['plan_sha256'] == digest(plan) and review['approved_for_bounded_execution']
    if stage == 'encoding':
        assert not (OUT / 'calls.jsonl').exists()
    else:
        review = json.loads((OUT / 'encoding-review.json').read_text())
        assert review['continue_host_probes'] and review['plan_sha256'] == digest(plan)
        assert not (OUT / 'host-results.json').exists()
    Settings.from_env()
    records = []
    with ExitStack() as stack:
        meter = MeteredTransport(OUT / 'calls.jsonl', max_calls=plan['max_calls'],
                                max_output_tokens=plan['max_reserved_output_tokens'], capture_content=False,
                                max_response_bytes=plan['provider_envelope_bytes'])
        stack.callback(meter.close)
        def boundary():
            value = meter.summary()
            assert value['usage_unknown_calls'] == 0 and value['reserved_calls'] == value['completed_calls']
        boundary()
        def measured(provider, request, case):
            record = {'case': case, 'request': asdict(request), 'started_at': datetime.now(UTC).isoformat()}
            records.append(record)
            write(OUT / (stage + '-calls.json'), records)
            started = time.monotonic()
            try:
                response = provider(request)
                record.update(output=response, usage=provider.last_usage, elapsed_seconds=time.monotonic()-started)
                write(OUT / (stage + '-calls.json'), records)
                boundary()
                return response
            except Exception as error:
                record['error_type'] = type(error).__name__
                write(OUT / (stage + '-calls.json'), records)
                raise
        common = (plan['model']['base_url'], os.environ['DEEPSEEK_API_KEY'], plan['model']['model'])
        if stage == 'encoding':
            provider = ChatCompletionsSemanticProvider(*common, thinking='enabled', reasoning_effort='low',
                max_response_bytes=plan['provider_envelope_bytes'], transport=meter)
            stack.callback(provider.close)
            data = plan['batch']
            data = {**data, **{key: tuple(data[key]) for key in ('sources', 'existing_assertions', 'episodes',
                'belief_relations', 'current_input_refs', 'learning_input_refs')}}
            result = SemanticProcessor(lambda r: measured(provider, r, 'encoding'),
                lambda r: measured(provider, r, 'verification'), SemanticPolicy(**plan['semantic_policy'])).process(
                    CognitiveBatch(**data), reserve=lambda **_: None)
            write(OUT / 'encoding-result.json', {'result': asdict(result), 'usage': meter.summary(), 'plan_sha256': digest(plan)})
            assert result.status in {'completed', 'partial'}
        else:
            provider = ChatCompletionsGenerator(*common, thinking='enabled', reasoning_effort='high',
                max_output_tokens=plan['host_output_tokens'], timeout_seconds=plan['host_timeout_seconds'],
                max_response_bytes=plan['provider_envelope_bytes'], transport=meter)
            stack.callback(provider.close)
            results = []
            for item in plan['host_inputs']:
                data = item['request']
                request = ModelRequest(**{**data, 'messages': tuple(data['messages'])})
                answer = measured(provider, request, item['case']['id'])
                results.append({'case': item['case'], 'answer': answer, 'request_sha256': digest(data)})
                write(OUT / 'host-results.partial.json', {'results': results, 'usage': meter.summary(), 'plan_sha256': digest(plan)})
            write(OUT / 'host-results.json', {'results': results, 'usage': meter.summary(), 'plan_sha256': digest(plan)})
        boundary()
        print(json.dumps({'state': stage + '_completed', 'usage': meter.summary()}))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--stage', choices=['encoding', 'host'])
    args = parser.parse_args()
    if args.prepare:
        prepare()
    elif args.stage:
        live(args.stage)
    else:
        parser.error('Choose a non-executing preparation or explicit bounded stage')
