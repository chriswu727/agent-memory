import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
from pathlib import Path, PurePosixPath

from dotenv import dotenv_values

from agent_memory.build_identity import BUILD_ID, package_manifest

ROOT = Path.cwd()
WORK = ROOT / '.local/recall-resolution'
PREFIX = 'v1-2026-10-26-recall-resolution'
PUBLIC = ROOT / 'evaluations'

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

assert BUILD_ID == 'd8cd5deb13986cab0589476a9a3a572180df482bc37aefe8ee147fd2ca934117'
artifacts = read(WORK / 'artifacts.json')
assert artifacts['runtime_build'] == BUILD_ID
manifest = package_manifest(ROOT / 'src/agent_memory', ROOT)
assert artifacts['files'] == {name: hashlib.sha256(value).hexdigest() for name, value in manifest.items()}
prior_plan = read(ROOT / '.local/longitudinal-repair-live/plan.json')
archive = ROOT / '.local/longitudinal-v7-cues/source-archive.json'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == prior_plan['source_file_sha256']

def run(directory, host=False):
    value = {name: read(directory / (name + '.json')) for name in (
        'plan', 'plan-review', 'encoding-calls', 'encoding-result', 'encoding-review')}
    if host:
        value.update({name: read(directory / (name + '.json')) for name in ('host-calls', 'host-results', 'host-review')})
    return value

report = {'status': 'scoped_batch_complete_longitudinal_acceptance_unpassed',
          'runtime_build': BUILD_ID, 'local_checks': read(WORK / 'checks.json'),
          'metrics': read(WORK / 'metrics.json'), 'actual_combined_usage': read(WORK / 'usage.json'),
          'failed_run': run(WORK / 'live'), 'followup': run(WORK / 'live-followup', host=True),
          'source_file_unchanged': True, 'source_file_sha256': prior_plan['source_file_sha256'],
          'raw_source_reference': '.local/longitudinal-v7-cues/source-archive.json',
          'remaining': ['No optional short expression in either small real-model encoding case.',
                        'Episode organization may transfer the sorting action to Grandma.',
                        'Unaided autobiographical draft still adds a time of day.',
                        'No new complete varied longitudinal campaign or actual machine-sleep/result reconciliation.'],
          'evidence_scope': 'Implementing Codex source/whole-answer review, not a blinded panel. No real-model result was published, delivered or merged into a brain.'}
write(PUBLIC / (PREFIX + '.json'), report)
write(PUBLIC / (PREFIX + '-artifacts.json'), artifacts)

note = {'status': 'reconstructed_note_not_original_raw_log',
        'observed': ["index.ts(279,12): Property 'source_act' does not exist on type 'RecallItem'.",
                     "index.ts(279,63): Property 'source_act' does not exist on type 'RecallItem'."],
        'repair': 'Declare the already supported optional source_act on RecallItem. Strict final typechecking passed.',
        'limitation': 'The initial typechecker output was returned by the terminal tool; it was not saved as a separate raw log.'}
write(WORK / 'typescript-typecheck-failure-note.json', note)

entries = {}
for path in WORK.iterdir():
    if path.is_file() and (path.suffix in {'.log', '.json', '.py'} or path.name.endswith('.before-verifier-tightening')):
        entries['work/' + path.name] = path.read_bytes()
for dirname in ('live', 'live-followup', 'live-pre-budget-fix'):
    for path in (WORK / dirname).iterdir():
        if path.is_file():
            entries[dirname + '/' + path.name] = path.read_bytes()
entries['sources/original-archive.json'] = archive.read_bytes()
entries['candidate.patch'] = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--',
    'src', 'sdk/typescript', 'tests', 'migrations', 'architecture/memory-contract.schema.json'])
entries['artifact-runtime-manifest.json'] = json.dumps(artifacts, indent=2).encode()

secret_values = set()
for key, value in {**dotenv_values(ROOT / '.env'), **os.environ}.items():
    if value and len(value) >= 12 and any(term in key.upper() for term in ('API_KEY', 'API_TOKEN', 'PASSWORD', 'SECRET')):
        secret_values.add(value.encode())

def check_json(value):
    if isinstance(value, list):
        for item in value:
            check_json(item)
    elif isinstance(value, dict):
        assert not any(key in {'reasoning_content', 'hidden_reasoning', 'chain_of_thought'} and item
                       for key, item in value.items())
        for item in value.values():
            check_json(item)

for name, raw in entries.items():
    assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
    assert not any(value in raw for value in secret_values), 'Configured secret in ' + name
    assert not re.search(rb'sk-[A-Za-z0-9]{16,}', raw), 'Key-like value in ' + name
    if name.endswith('.json'):
        check_json(json.loads(raw))
    elif name.endswith('.jsonl'):
        for line in raw.splitlines():
            if line.strip():
                check_json(json.loads(line))

bundle = PUBLIC / 'artifacts' / (PREFIX + '-evidence.tar.gz')
with tarfile.open(bundle, 'w:gz') as stream:
    for name, raw in sorted(entries.items()):
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        item.mode = 0o600
        stream.addfile(item, io.BytesIO(raw))
with tarfile.open(bundle, 'r:gz') as stream:
    assert {member.name for member in stream.getmembers()} == set(entries)
    for member in stream.getmembers():
        assert member.isfile() and stream.extractfile(member).read() == entries[member.name]
evidence = {'runtime_build': BUILD_ID, 'bundle': str(bundle.relative_to(ROOT)),
            'sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(), 'bytes': bundle.stat().st_size,
            'files': {name: hashlib.sha256(raw).hexdigest() for name, raw in sorted(entries.items())},
            'configured_secret_and_key_pattern_scan': 'passed', 'json_hidden_reasoning_field_scan': 'passed',
            'member_bytes_verified': True, 'source_archive_file_unchanged': True}
write(PUBLIC / (PREFIX + '-evidence.json'), evidence)
print(json.dumps({'runtime_build': BUILD_ID, 'bundle_files': len(entries), 'bundle_bytes': evidence['bytes'],
                  'bundle_sha256': evidence['sha256']}))
