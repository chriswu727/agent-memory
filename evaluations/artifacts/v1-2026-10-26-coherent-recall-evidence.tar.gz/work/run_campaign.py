import json
import sys
from pathlib import Path

ROOT = Path('/Users/yichen/projects/agent-memory')
sys.path.insert(0, str(ROOT))
import agent_memory
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
from examples.evaluate_longitudinal import live, plan
from examples.longitudinal_journal import CampaignJournal

WORK = ROOT / '.local/coherent-recall'
CAMPAIGN = WORK / 'campaign'
checks = json.loads((WORK / 'checks.json').read_text())
assert checks['passed'] and checks['runtime_build'] == BUILD_ID
assert str(WORK / 'wheel-env') in agent_memory.__file__
frozen = json.loads((WORK / 'frozen-plan.json').read_text())
assert plan(fixture='release') == frozen
review = json.loads((WORK / 'pre-execution-review.json').read_text())
assert review['plan_sha256'] == digest(frozen) and review['approved_for_execution']
target = int(sys.argv[1])
assert target in (4,7,10,14)
completed = 0
if CAMPAIGN.exists():
    with CampaignJournal(CAMPAIGN, frozen) as journal:
        journal.assert_resumable()
        completed = sum(event['kind']=='session_completed' for event in journal.events)
        approval = json.loads((WORK / f'stage-{completed}-review.json').read_text())
        assert approval['continue_permitted'] and approval['source_head_sha256']==journal.events[-1]['sha256']
        assert approval['plan_sha256']==digest(frozen)
assert target=={0:4,4:7,7:10,10:14}[completed]
result = live(CAMPAIGN, continuing=CAMPAIGN.exists(), sessions=target-completed, fixture='release')
(WORK / f"stage-{len(result['sessions_completed'])}-report.json").write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key: result[key] for key in ('state','sessions_completed','turns_completed','turns_delivered','unsettled_deliveries','user_assistance','timing')}))
