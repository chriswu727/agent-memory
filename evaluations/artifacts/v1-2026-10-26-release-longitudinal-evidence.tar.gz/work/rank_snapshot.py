import json,sys
from collections import Counter
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory import cognition
from agent_memory.context_views import assistant_speech
from agent_memory.lexical_candidates import LexicalScorer
w=Path('.local/source-composition');ev=[json.loads(x) for x in (w/'campaign/journal.jsonl').read_text().splitlines()]
snapshot=next(e['payload']['before'] for e in ev if e['kind']=='turn_started' and e['payload']['turn_id']=='first-caption')
(w/'pre-caption-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
request=json.loads((w/'first-caption-request.json').read_text());query=request['messages'][-1]['content']
memories=[m for m in snapshot['documents']['memories'] if not assistant_speech(m)]
old=LexicalScorer(query,[m['statement'] for m in memories]);documents={}
for m in memories:
 terms=cognition._terms(m['statement']);refs={(r['event_id'],r['event_revision'],r['source_content_sha256']) for r in m['evidence_refs'] if r['relationship']=='supports'}
 for key in refs or {('memory',m['memory_id'],m['revision'])}:
  parts=documents.setdefault(key,[set(),set(),set()])
  for p,t in zip(parts,terms,strict=True):p.update(t)
freq=[Counter(t for d in documents.values() for t in d[i]) for i in range(3)]
new=LexicalScorer(query,[]);new.weights=[{t:(1+len(documents))/(1+f[t]) for t in q} for q,f in zip(new.query_terms,freq,strict=True)]
for label,score in [('current',old),('source_origin',new)]:
 print('\n'+label)
 for s,m in sorted(((score(query,m['statement']),m) for m in memories),key=lambda v:-v[0])[:18]:print(round(s,4),m['dynamics']['retention_priority'],m['statement'])
