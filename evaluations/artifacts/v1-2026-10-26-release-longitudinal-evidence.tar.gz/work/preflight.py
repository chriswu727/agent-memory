import json
from pathlib import Path
from agent_memory.helpers import digest
w=Path('.local/source-composition');p=json.loads((w/'frozen-plan.json').read_text())
r={'plan_sha256':digest(p),'approved_for_execution':True,
'reviewer':'Implementing Codex source reviewer, separate from the tested DeepSeek host and selector; not a blinded external panel.',
'authority':'User requested two repairs followed by varied real-model longitudinal acceptance; purposeful DeepSeek usage authorized.',
'fixture_review':{'sessions':14,'turns':26,'source_bounded_cases':18,'ordinary_practical_cases':15,'explicit_recall_cases':3,'story_span_days':70,'future_fact_leakage':'Actor sees only released authored user knowledge, actual current-session answers and current permitted choices. Host never receives private rubrics or future turns.','branches':'Twelve selectors react to actual delivered responses. Assistance and corrections scored separately.'},
'execution_schedule':{'session_boundaries':[4,7,10,14],'reconstruction':'Fresh installed-runtime process and HTTP service each invocation; same durable brain, source snapshot, plan and cumulative ledger.','callback_change':'After seven completed sessions switch from evaluation host to core ChatCompletionsGenerator with the same provider/model/settings. No cross-model claim.','time':'Narrative offsets only; record real active time and review gaps.'},
'behavior_rubric':'Review every clause of every answer including drafts, and every published derived claim, short expression and episode organization against only its exact available source prefix. Correct actors, expressed meaning, negation, world, qualification and uncertainty required. Plausibility does not supply facts. Requested fictional suggestions remain fiction. Optional summary absence is recorded separately, not forced for each short claim.',
'stop_rules':['Every paid call reserved before network access; unknown usage or provider/required-processing failure stops. No retry, replay or budget replenishment.','Critical unsupported publication stops dependent paid continuation. Earlier failed answers and assessments remain failures.','No runtime or fixture edits after first paid call; review each completed stage before continuation. Never insert memories or teach facts through diagnostics.','194 cumulative calls and 2668544 reserved output tokens across all invocations; ceilings are not expected consumption. Unused capacity expires at completion or failure.'],
'auxiliary':'At final checkpoint only, zero-provider frozen-source age comparisons may inspect actual model-created summaries with the validated access-time seam. No additional paid short probes or reviewer.',
'acceptance':'Completion is not semantic acceptance; required cases must satisfy frozen constraints. Assistance, invalid and unexecuted cases remain labeled. Known failures block stable release.'}
assert len(p['scenario']['sessions'])==14 and p['allocation']=={'host':26,'cognition':156,'user':12}
assert sum(c['kind']=='practical' for c in p['scenario']['private_review']['cases'])==15
(w/'pre-execution-review.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'plan_sha256':digest(p),'allocation':p['allocation'],'review':'ready_after_local_checks'}))
