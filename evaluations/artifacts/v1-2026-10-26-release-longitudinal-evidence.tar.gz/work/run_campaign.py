import json
import sys
from pathlib import Path

ROOT = Path('/Users/yichen/projects/agent-memory')
sys.path.insert(0, str(ROOT))
import agent_memory
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
from examples.evaluate_longitudinal import live, plan

WORK = ROOT / '.local/source-composition'
CAMPAIGN = WORK / 'campaign'
checks = json.loads((WORK / 'checks.json').read_text())
assert checks['passed'] and checks['runtime_build'] == BUILD_ID
assert str(WORK / 'wheel-env') in agent_memory.__file__
frozen = json.loads((WORK / 'frozen-plan.json').read_text())
assert plan(fixture='release') == frozen
review = json.loads((WORK / 'pre-execution-review.json').read_text())
assert review['plan_sha256'] == digest(frozen) and review['approved_for_execution']
result = live(CAMPAIGN, continuing=CAMPAIGN.exists(), sessions=int(sys.argv[1]), fixture='release')
(WORK / f"stage-{len(result['sessions_completed'])}-report.json").write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key: result[key] for key in ('state','sessions_completed','turns_completed','turns_delivered','unsettled_deliveries','user_assistance','timing')}))
