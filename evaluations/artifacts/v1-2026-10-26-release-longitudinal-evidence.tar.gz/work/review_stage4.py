import json
from pathlib import Path
import sys
from types import SimpleNamespace
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from contextlib import nullcontext

w=Path('.local/source-composition');c=w/'campaign';p=json.loads((c/'plan.json').read_text())
head=json.loads((w/'stage-4-report.json').read_text())['last_event']['sha256']
raw=[json.loads(line) for line in (c/'journal.jsonl').read_text().splitlines()]
end=next(i for i,e in enumerate(raw) if e['sha256']==head)
prefix=raw[:end+1]
previous=digest(p)
for index,entry in enumerate(prefix,1):
 assert entry['previous_sha256']==previous and entry['sequence']==index and entry['plan_sha256']==digest(p)
 assert digest({k:v for k,v in entry.items() if k!='sha256'})==entry['sha256']
 previous=entry['sha256']
with nullcontext(SimpleNamespace(events=prefix)) as j:
 assert j.events[-1]['kind']=='paused' 
 turns=[e['payload'] for e in j.events if e['kind']=='turn_completed'];assert len(turns)==7
 episodes=[];seen={};refs_checked=0
 for t in turns:
  sources={(s['event_id'],s['revision']):s for s in t['after']['sources']}
  for source in sources.values():assert digest(source['observed']['content'])==source['content_sha256']
  for m in t['after']['documents']['memories']:
   if m['derivation']['method']=='direct_capture':continue
   seen[m['memory_id'],m['revision']]=m
   for r in m['evidence_refs']:
    s=sources[r['event_id'],r['event_revision']];assert r['source_content_sha256']==s['content_sha256']
    assert 0<=r['span']['start']<r['span']['end']<=len(s['observed']['content']['text']);refs_checked+=1
 for e in j.events:
  v=e['payload']
  if e['kind']=='learning_completed':assert not v['stop_reason'] and v['encoding_coverage']['complete']
  if e['kind']=='learning_job' and v.get('record_type')=='finished':
   result=v.get('result') or {}
   for a in result.get('episode_actions',[]):
    audit,=[x for x in result['verification_assessments'] if x['proposal_id']==a['proposal_id']]
    assert set(audit['organization_fidelity'])=={'attribution','modality','specificity','boundary','participant_actions'}
    assert set(audit['organization_fidelity'].values())=={'supports'};episodes.append(a)
 early=json.loads((w/'early-answer-review.json').read_text())['turns'];assert len(early)==6
 early['tiny-task']={'verdict':'pass','reason':'Acknowledges the one-week exception and narrows the task to the first junction. The user warning is preventive; the preceding answer did not assert a permanent schedule.'}
 review={'review_completed':True,'continue_permitted':True,'verdict':'stage_pass_no_critical_publication_defect','plan_sha256':digest(p),'source_head_sha256':j.events[-1]['sha256'],
  'reviewer':'Implementing Codex whole-answer and source reviewer; separate from tested DeepSeek, not a blinded panel.',
  'turns':early,'published_derived_memory_versions_reviewed':len(seen),'episode_organizations_reviewed':len(episodes),'mechanical_reference_checks':refs_checked,
  'source_review':'Read all newly published derived statements, cited excerpts and complete available user/assistant sources in stage-4-inspection.txt. Roles, negation, plans, unknown validity and speaker provenance preserved. Assistant draft/suggestion records stay agent_said, not independent proof of user action. No unsupported time, location, sensation or completed external action found.',
  'branch_review':{'ordinary':5,'assisted':1,'correction':1,'sam-family':'Authored assisted branch introduces the brother for the first time; preceding work reply had no identity error. Retain assistance label, do not score it as unaided identity recall.','tiny-task':'Authored correction branch warns against permanent scheduling and narrows desired task. Previous answer already used the current one-week slot. No prior factual error erased.'},
  'limitations':['No autobiographical caption/card reached yet; no overall acceptance claim.','No short expressions produced yet; automatic layered presentation remains to be assessed.','Partial semantic jobs retained their rejected proposals; completion is not a whole-proposal accuracy claim.'],
  'usage':j.events[-1]['payload']['usage']}
 (w/'stage-4-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({k:review[k] for k in ('verdict','published_derived_memory_versions_reviewed','episode_organizations_reviewed','source_head_sha256')}))
