import json
import os
import subprocess
import sys
from pathlib import Path

from agent_memory.config import Settings

root = Path.cwd()
work = root / '.local/source-composition'
python = work / 'wheel-env/bin/python'
mode = sys.argv[1]
environment = {key: value for key, value in os.environ.items()
               if not key.startswith(('DEEPSEEK', 'OPENAI', 'ANTHROPIC', 'MEMORY_'))}
environment.update(PYTHON_DOTENV_DISABLED='1', MEMORY_DATABASE_URL=Settings.from_env().database_url)
names = ['test_source_composition.py', 'test_episode_fidelity.py', 'test_recall_resolution.py', 'test_recall_resolution_storage.py', 'test_learning_process_interruption.py',
         'test_source_act_contract.py', 'test_bounded_learning_semantics.py', 'test_context_views.py',
         'test_memory_consumption.py', 'test_answer_review.py', 'test_mcp.py', 'test_schema_compatibility.py']
if mode == 'desktop':
    environment['MEMORY_DESKTOP_E2E'] = '1'
    names = ['test_desktop_e2e.py', 'test_standalone_chat_e2e.py', 'test_desktop_recovery_e2e.py',
             'test_desktop_upgrade_e2e.py']
    log = work / 'desktop-delivery.log'
else:
    environment['MEMORY_MIGRATION_DATABASE_URL'] = Settings.from_env().migration_database_url or environment['MEMORY_DATABASE_URL']
    log = work / 'installed-delivery.log'
code = "import sys,pytest; sys.path.insert(0,sys.argv[1]); raise SystemExit(pytest.main(sys.argv[2:]))"
command = [str(python), '-I', '-c', code, str(root / 'tests'), '-q', *[str(root / 'tests' / name) for name in names]]
with log.open('w') as stream:
    result = subprocess.run(command, cwd='/tmp', env=environment, stdout=stream, stderr=subprocess.STDOUT)
print(json.dumps({'scope': mode, 'exit_code': result.returncode, 'log': str(log)}))
raise SystemExit(result.returncode)
