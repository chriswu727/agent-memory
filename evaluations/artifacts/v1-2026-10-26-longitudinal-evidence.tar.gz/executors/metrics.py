import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.local/longitudinal-life-v7')
rows=[json.loads(x) for x in (path/'journal.jsonl').read_text().splitlines()]
calls=[json.loads(x) for x in (path/'calls.jsonl').read_text().splitlines()]
finished=[x for x in calls if x['event']=='completed']

def samples(items):
    ordered=sorted(items)
    if not ordered:return None
    n=len(ordered)
    return {'count':n,'min_seconds':min(ordered),'median_seconds':(ordered[(n-1)//2]+ordered[n//2])/2,
            'p95_seconds':ordered[math.ceil(n*.95)-1],'max_seconds':max(ordered),'sum_seconds':sum(ordered),'raw_seconds':items}

roles=defaultdict(lambda:{'calls':0,'input_tokens':0,'output_tokens':0,'total_tokens':0,'reasoning_tokens':0,'seconds':[]})
prior=0
for row in rows:
    if row['kind']!='provider_completed':continue
    p=row['payload'];after=p['usage_after']['completed_calls']
    assert after==prior+1
    call=finished[prior];prior=after
    role=roles[p['role']];usage=call.get('usage',{})
    role['calls']+=1
    for destination,source in [('input_tokens','prompt_tokens'),('output_tokens','completion_tokens'),('total_tokens','total_tokens')]:role[destination]+=usage.get(source,0)
    role['reasoning_tokens']+=usage.get('completion_tokens_details',{}).get('reasoning_tokens',0)
    role['seconds'].append(p['elapsed_seconds'])
for role in roles.values():role['latency']=samples(role.pop('seconds'))
learning=[r['payload'] for r in rows if r['kind']=='learning_job' and r['payload'].get('record_type')=='finished' and r['payload'].get('learning_phase')]
phases=defaultdict(lambda:{'jobs':0,'published_memories':0,'published_relations':0,'episode_actions':0,'rejections':Counter(),'no_publication_jobs':0})
for job in learning:
    phase=phases[job['learning_phase']];phase['jobs']+=1
    result=job.get('result') or {};publication=result.get('publication') or {}
    phase['published_memories']+=len(publication.get('memory_versions',[]))
    phase['published_relations']+=len(publication.get('belief_relation_versions',[]))
    phase['episode_actions']+=len(result.get('episode_actions',[]))
    phase['rejections'].update(item['reason'] for item in result.get('rejected',[]))
    phase['no_publication_jobs']+=not(publication.get('memory_versions') or publication.get('belief_relation_versions') or result.get('episode_actions'))
overheads=[]
provider_seconds=0.0
for row in rows:
    if row['kind']=='turn_started':provider_seconds=0.0
    elif row['kind']=='provider_completed' and row['payload']['role']!='user':provider_seconds+=row['payload']['elapsed_seconds']
    elif row['kind']=='runtime_completed':overheads.append(row['payload']['elapsed_seconds']-provider_seconds)
result={'state':rows[-1]['kind'],'last_sequence':rows[-1]['sequence'],'usage_by_role':roles,'learning_by_phase':phases,
        'foreground':samples([r['payload']['elapsed_seconds'] for r in rows if r['kind']=='runtime_completed']),
        'foreground_non_provider_overhead':samples(overheads),
        'background':samples([r['payload']['elapsed_seconds'] for r in rows if r['kind']=='learning_completed']),
        'sessions':sum(r['kind']=='session_completed' for r in rows),'turns':sum(r['kind']=='turn_completed' for r in rows),
        'unknown_calls':sum(not x['usage_confirmed'] for x in finished),
        'scope':'Measured real calls; accelerated fictional time does not establish real calendar aging.'}
print(json.dumps(result,ensure_ascii=False,indent=2))
