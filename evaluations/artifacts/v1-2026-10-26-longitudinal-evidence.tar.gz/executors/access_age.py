import importlib.util
import json
import os
import sys
from datetime import UTC, datetime, timedelta
from pathlib import Path

ROOT = Path('/Users/yichen/projects/agent-memory')
sys.path.insert(0, str(ROOT))
import psycopg
from psycopg.rows import dict_row

from agent_memory.build_identity import BUILD_ID
from agent_memory.client import default_read_fence
from agent_memory.helpers import Principal, digest, uid
from agent_memory.service import MemoryService
from agent_memory.storage import Database
from diagnostic_binding import source_campaign

BASE = ROOT / '.local/longitudinal-v7-verification'
CAMPAIGN = ROOT / '.local/longitudinal-life-v7-tail'
OUTPUT = BASE / 'access-age'
spec = importlib.util.spec_from_file_location(
    'age_helpers', ROOT / '.local/longitudinal-v3-verification/access_age_diagnostic.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def main():
    assert os.environ.get('PYTHON_DOTENV_DISABLED') == '1'
    assert not any(key.startswith(('MEMORY_COGNITION_', 'MEMORY_EMBEDDING_', 'DEEPSEEK_', 'OPENAI_'))
                   for key in os.environ)
    frozen = json.loads((BASE / 'frozen-plan.json').read_text())
    template = frozen['access_age_template']
    review = json.loads((BASE / 'stage-11-review.json').read_text())
    assert review['review_completed'] and review['source_integrity'] == 'pass'
    assert review['attempted_sessions'] == 11 and review['completed_sessions'] == 10
    assert BUILD_ID == frozen['primary']['runtime_build']
    OUTPUT.mkdir(mode=0o700)
    results = []
    with source_campaign(CAMPAIGN) as (journal, binding):
        assert review['source_head_sha256'] == binding['head_sha256']
        files_before = {name: digest((CAMPAIGN / name).read_text())
                        for name in ('plan.json', 'journal.jsonl', 'head.json', 'calls.jsonl')}
        principal = Principal(**binding['principal'])
        params = (principal.tenant_id, principal.principal_id, binding['brain_id'])
        conversation = 'isolated-access-age-' + uid()
        with psycopg.connect(os.environ['MEMORY_DATABASE_URL'], row_factory=dict_row,
                            autocommit=True) as conn:
            with conn.transaction(force_rollback=True):
                conn.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
                helpers.configure(conn, principal)
                tables = helpers.scoped_tables(conn)
                assert len(tables) == 25
                before = helpers.snapshot(conn, params, tables)
                brain = conn.execute('SELECT * FROM memory_brains WHERE tenant_id=%s AND owner_id=%s AND id=%s', params).fetchone()
                assert brain is not None
                reference = conn.execute('SELECT clock_timestamp() AS at').fetchone()['at']
                memories = [r['document'] for r in conn.execute(
                    'SELECT document FROM memory_assertions WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s '
                    'AND is_current AND NOT invalidated AND NOT deleted AND NOT suppressed AND document IS NOT NULL', params)]
                events = [r['document'] for r in conn.execute(
                    'SELECT document FROM memory_events WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s '
                    'AND is_current AND NOT deleted AND NOT suppressed ORDER BY sequence', params)]
                access = list(conn.execute('SELECT * FROM memory_access_state WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s', params))
                assert all(e['scope']['conversation_id'] != conversation for e in events)
                bound = {**template, 'state': 'bound_before_retrieval', 'runtime_build': BUILD_ID,
                         'source_checkpoint': binding, 'source_files': files_before,
                         'original_clean_checkpoint_requirements_met': False,
                         'exploratory_amendment': review['auxiliary_scope'],
                         'review_sha256': digest(review), 'executor_sha256': digest(Path(__file__).read_text()),
                         'helper_sha256': digest(Path(spec.origin).read_text()), 'snapshot': before,
                         'reference_time': reference.isoformat(), 'conversation': conversation,
                         'memory_catalog': memories, 'events': events,
                         'access_ledger': json.loads(json.dumps(access, default=str))}
                (OUTPUT / 'bound-plan.json').write_text(json.dumps(bound, ensure_ascii=False, indent=2))
                for query in template['queries']:
                    for days in template['elapsed_day_offsets']:
                        for intent in template['intents']:
                            calls = []
                            at = (reference + timedelta(days=days)).isoformat()

                            def clock():
                                calls.append(at)
                                return at

                            service = MemoryService(Database(os.environ['MEMORY_DATABASE_URL']), access_time_provider=clock)
                            request = {'query': query['text'], 'intent': intent, 'cue_event_ids': [],
                                       'additional_cues': [], 'evidence_mode': template['evidence_mode'],
                                       'world_filter': template['world_filter'], 'budget': template['budget'],
                                       'evidence_cutoff': {'mode': 'through_sequence', 'through_sequence': brain['durable_sequence']},
                                       'read_fence': default_read_fence(brain['durable_sequence'])}
                            target = {'brain_ref': brain['id'], 'conversation_ref': conversation, 'branch_ref': 'main'}
                            started = datetime.now(UTC).isoformat()
                            with conn.transaction(force_rollback=True):
                                result, _, _ = service._retrieval(conn, principal, brain, target, request)
                            assert calls == [at]
                            assert result['usage']['model_calls'] == result['usage']['embedding_calls'] == 0
                            assert helpers.snapshot(conn, params, tables) == before
                            results.append({'query_id': query['id'], 'request': request, 'elapsed_days': days,
                                            'access_at': at, 'started_at': started,
                                            'finished_at': datetime.now(UTC).isoformat(), 'result': result,
                                            'snapshot_unchanged_after_rollback': True})
                            (OUTPUT / 'retrievals.partial.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
                assert helpers.snapshot(conn, params, tables) == before
            with conn.transaction(force_rollback=True):
                conn.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
                helpers.configure(conn, principal)
                assert helpers.snapshot(conn, params, tables) == before
        assert {name: digest((CAMPAIGN / name).read_text()) for name in files_before} == files_before
    assert len(results) == 18
    report = {'runtime_build': BUILD_ID, 'source_head_sha256': binding['head_sha256'],
              'retrieval_count': len(results), 'provider_calls': 0, 'all_25_tables_unchanged': True,
              'source_files_unchanged': True, 'time_mode': 'frozen_snapshot_access_time_only',
              'semantic_review': 'pending', 'retrievals': results}
    (OUTPUT / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps({k: v for k, v in report.items() if k != 'retrievals'}))


if __name__ == '__main__':
    main()
