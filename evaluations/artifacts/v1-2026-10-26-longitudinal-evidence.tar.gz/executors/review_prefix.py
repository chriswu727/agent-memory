import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from examples import evaluate_longitudinal as base
from examples.longitudinal_journal import CampaignJournal
verify=Path('.local/longitudinal-v7-verification')
path=Path('.local/longitudinal-life-v7-tail')
parent=Path('.local/longitudinal-life-v7')
planned=json.loads((verify/'tail-plan.json').read_text())
with CampaignJournal(parent,json.loads((parent/'plan.json').read_text())) as original:
 with CampaignJournal(path,planned) as journal:
  journal.assert_resumable()
  assert journal.events[-1]['kind']=='paused'
  report=base.report(journal)
  assert report['turns_completed']==report['turns_delivered']==4 and not report['unsettled_deliveries']
  assert len(report['sessions_completed'])==2
  usage=journal.events[-1]['payload']['usage']
  assert not usage['usage_unknown_calls'] and usage['completed_calls']==usage['reserved_calls']
  completed=[e['payload'] for e in journal.events if e['kind']=='session_completed']
  assert digest([json.loads(x) for x in (path/'calls.jsonl').read_text().splitlines()])==completed[-1]['ledger_sha256']
  learned=[e['payload'] for e in journal.events if e['kind']=='learning_completed']
  assert len(learned)==4 and all(not p['stop_reason'] and p['encoding_coverage']['complete'] for p in learned)
  old=json.loads((verify/'main-terminal-review.json').read_text())
  notes=json.loads((verify/'tail-judgments.json').read_text())
  assert set(notes['turns'])=={e['payload']['transcript']['turn_id'] for e in journal.events if e['kind']=='delivered_exchange'}
  review={'reviewer':'Root Codex source reviewer, independent of the tested host/actor, not a blinded external human panel',
          'review_completed':True,'source_integrity':'pass','verdict':'diagnostic_review_complete_with_failures',
          'attempted_sessions':11,'completed_sessions':10,'partially_completed_sessions':1,
          'delivered_turns':22,'failed_unanswered_turns':1,'source_head_sha256':journal.events[-1]['sha256'],
          'source_plan_sha256':journal.plan_sha256,'parent_head_sha256':original.events[-1]['sha256'],
          'usage':{'parent':old['usage'],'tail':usage},'turn_judgments':{**old['turn_judgments'],**notes['turns'],
          'dinner-shopping':{'verdict':'failed_no_answer','reason':'Host timeout overlapping system sleep. Unknown usage and expired generating lease remain unreconciled; never retried.'}},
          'publication_review':{'parent':old['publication_review'],'tail':notes['publication_review']},
          'auxiliary_scope':'Exploratory diagnostic on the actual retained prefix. Original eleven-clean-session condition is unmet. No acceptance pass or failed-case erasure.'}
  (verify/'stage-11-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
  (verify/'tail-stage-11-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
  print(json.dumps({k:review[k] for k in ('review_completed','source_integrity','attempted_sessions','completed_sessions','delivered_turns','failed_unanswered_turns','source_head_sha256')}))
