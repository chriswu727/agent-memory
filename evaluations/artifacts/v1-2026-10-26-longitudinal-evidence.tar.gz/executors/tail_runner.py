import argparse
import copy
import inspect
import json
import sys
import textwrap
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from examples import evaluate_longitudinal as base
from examples.longitudinal_journal import CampaignJournal
from examples import longitudinal_scenario as scenario_module

ROOT=Path.cwd()
VERIFY=ROOT/'.local/longitudinal-v7-verification'
SOURCE=ROOT/'.local/longitudinal-life-v7'
OUTPUT=ROOT/'.local/longitudinal-life-v7-tail'
START=9
FAILED_TURN='dinner-shopping'


def replace_once(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new,1)


def derived_sources():
    run=textwrap.dedent(inspect.getsource(base.SessionRunner.run))
    run=replace_once(run,'self.story["sessions"][:len(done)]','self.story["sessions"][9:9 + len(done)]')
    run=replace_once(run,'range(len(done), min(len(done) + sessions, len(self.story["sessions"])))','range(9 + len(done), min(9 + len(done) + sessions, len(self.story["sessions"])))')
    run=replace_once(run,'count == len(self.story["sessions"])','count == len(self.story["sessions"]) - 9')
    choose=textwrap.dedent(inspect.getsource(base.SessionRunner.choose))
    choose=replace_once(choose,'transcript(self.journal)','self.inherited_transcript + transcript(self.journal)')
    actor=textwrap.dedent(inspect.getsource(scenario_module.actor_request))
    actor=replace_once(actor,'        _text(record["assistant_text"], "delivered assistant text", limit=1_000_000)',
        '        if record["turn_id"] == "dinner-shopping":\n'
        '            assert record["assistant_text"] is None\n'
        '            assert record["session_id"] != session["id"]\n'
        '        else:\n'
        '            _text(record["assistant_text"], "delivered assistant text", limit=1_000_000)')
    return {'run':run,'choose':choose,'actor_request':actor}


def source_binding():
    with CampaignJournal(SOURCE,json.loads((SOURCE/'plan.json').read_text())) as source:
        base.validate_plan(source.plan)
        assert source.events[-1]['kind']=='stopped'
        assert source.events[-1]['payload']['error']=={'code':'timeout','type':'HostProviderError'}
        audit=json.loads((VERIFY/'post-timeout-audit.json').read_text())
        assert audit['source_head_sha256']==source.events[-1]['sha256']
        assert audit['all_previous_sources_unchanged'] and audit['failed_turn_has_no_output']
        inherited=base.transcript(source)
        assert len(inherited)==18
        selected=next(e['payload']['selection'] for e in reversed(source.events) if e['kind']=='user_selected')
        failed=dict(session_id=source.plan['scenario']['sessions'][8]['id'],turn_id=FAILED_TURN,
                    choice_id=selected['id'],user_text=selected['text'],assistant_text=None)
        assert failed['user_text']==audit['new_events_since_last_completed_turn'][0]['observed']['content']['text']
        initial=next(e['payload'] for e in source.events if e['kind']=='initialized')
        return {'source_path':str(SOURCE),'source_head_sha256':source.events[-1]['sha256'],
                'source_plan_sha256':source.plan_sha256,'source_files':{name:digest((SOURCE/name).read_text())
                    for name in ('plan.json','journal.jsonl','head.json','calls.jsonl')},
                'usage':source.events[-1]['payload']['usage'],'initial':initial,
                'delivered_transcript':inherited,'unanswered_input':failed,'audit_sha256':digest(audit)}


def make_plan(binding):
    planned=base.plan()
    primary=copy.deepcopy(planned)
    planned['max_calls']-=binding['usage']['reserved_calls']
    planned['max_reserved_output_tokens']-=binding['usage']['reserved_output_tokens']
    planned['diagnostic_continuation']={
        'version':'sleep-interrupted-tail-v1','source':binding,'start_session_index':START,
        'executor_sha256':digest(Path(__file__).read_text()),'derived_sources':derived_sources(),
        'reason':'Finish the remaining authored life scenarios after documented computer sleep interrupted host generation. This is a separately disclosed diagnostic segment, not a successful restart of the stopped campaign.',
        'failed_turn':'The unanswered dinner-shopping request remains failed with unknown usage and its original output reservation permanently counted. It is never retried, redelivered, cleared, or marked completed.',
        'continuity':'Same database, brain, sources, runtime and generation settings. Only new conversation IDs from the remaining original scenario are used. Original history and terminal journal remain unchanged.',
        'budgets':'Subtract every original reservation, including the unknown call, from the original primary ceiling. Auxiliary 15-call ceiling remains separate. No increase, retries or additional tail after a new failure.',
        'environment':'Temporary AC/idle system-sleep inhibition for this bounded test; no permanent power setting changes.',
        'review':'Root Codex source review of unchanged scenario and exact failed-state audit. Earlier answer failures remain failed. No confirmatory acceptance pass; original eleven-clean-session condition is not met.',
        'auxiliary':'At two completed tail sessions, independently review the combined eleven-attempted-session prefix. Isolated cue/access-age diagnostics are explicitly amended exploratory measurements on this actual prefix, not the original clean-boundary acceptance experiment.',
        'stop':'All original unknown-usage/provider/required-processing/integrity stops apply within this new segment. Prior unknown usage is retained in linked accounting, never converted to known usage.',
        'original_primary_ceiling':{'calls':primary['max_calls'],'reserved_output_tokens':primary['max_reserved_output_tokens']}}
    return planned


class TailRunner(base.SessionRunner):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        binding=self.planned['diagnostic_continuation']['source']
        self.inherited_transcript=binding['delivered_transcript']+[binding['unanswered_input']]

    def resume_check(self):
        if any(e['kind']=='session_completed' for e in self.journal.events):
            return super().resume_check()
        binding=self.planned['diagnostic_continuation']['source']
        assert self.memory.brain_id==binding['initial']['brain_id']
        snapshot=self.snapshot()
        audit=json.loads((VERIFY/'post-timeout-audit.json').read_text())
        new_id=audit['new_events_since_last_completed_turn'][0]['event_id']
        assert any(s['event_id']==new_id for s in snapshot['sources'])
        self.journal.append('continuation_baseline',{'snapshot':snapshot,'sha256':digest(snapshot),
                            'original_failed_turn_unresolved':True,'prior_unknown_usage':binding['usage']['usage_unknown_calls']})


def setup(planned):
    sources=derived_sources()
    scenario_namespace=dict(vars(scenario_module))
    exec(compile(sources['actor_request'],'<frozen-tail-actor>','exec'),scenario_namespace)
    namespace=dict(vars(base))
    namespace['actor_request']=scenario_namespace['actor_request']
    for name in ('run','choose'):
        exec(compile(sources[name],'<frozen-tail-'+name+'>','exec'),namespace)
        setattr(TailRunner,name,namespace[name])
    namespace['SessionRunner']=TailRunner
    namespace['plan']=lambda:copy.deepcopy(planned)
    exec(compile(textwrap.dedent(inspect.getsource(base.live)),'<frozen-tail-live>','exec'),namespace)
    return namespace['live']


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--sessions',type=int)
    args=parser.parse_args()
    binding=source_binding()
    planned=make_plan(binding)
    if args.prepare:
        assert not OUTPUT.exists()
        for index in range(START,16):
            assert planned['scenario']['sessions'][index]['conversation_id'] != 'rowan-dinner-with-nia'
        assert planned['max_calls']==166 and planned['max_reserved_output_tokens']==2436608
        for name,source in derived_sources().items():compile(source,'<validate-'+name+'>','exec')
        (VERIFY/'tail-plan.json').write_text(json.dumps(planned,ensure_ascii=False,indent=2))
        print(json.dumps({'state':'prepared_not_started','plan_sha256':digest(planned),'remaining_sessions':7,
                          'new_turns':14,'prior_delivered':18,'prior_failed':1,'max_calls':166,'max_reserved_output_tokens':2436608}))
        return
    frozen=json.loads((VERIFY/'tail-plan.json').read_text())
    assert planned==frozen
    assert args.sessions in (2,5)
    if not OUTPUT.exists():
        assert args.sessions==2
        with CampaignJournal(OUTPUT,planned) as journal:
            journal.append('lineage',binding)
            journal.append('initialized',binding['initial'])
            journal.append('paused',{'reason':'new_diagnostic_segment_preserving_failed_source'})
    result=setup(planned)(OUTPUT,continuing=True,sessions=args.sessions)
    assert {name:digest((SOURCE/name).read_text()) for name in binding['source_files']}==binding['source_files']
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
