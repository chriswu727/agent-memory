import json
import sys
from contextlib import contextmanager
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from examples import evaluate_longitudinal as base
from examples.longitudinal_journal import CampaignJournal

ROOT=Path.cwd()
VERIFY=ROOT/'.local/longitudinal-v7-verification'
PARENT=ROOT/'.local/longitudinal-life-v7'
TAIL=ROOT/'.local/longitudinal-life-v7-tail'


@contextmanager
def source_campaign(path):
    assert Path(path).resolve()==TAIL
    planned=json.loads((VERIFY/'tail-plan.json').read_text())
    with CampaignJournal(PARENT,json.loads((PARENT/'plan.json').read_text())) as parent:
        base.validate_plan(parent.plan)
        assert parent.events[-1]['kind']=='stopped'
        inherited=planned['diagnostic_continuation']['source']
        assert {name:digest((PARENT/name).read_text()) for name in inherited['source_files']}==inherited['source_files']
        with CampaignJournal(TAIL,planned) as journal:
            journal.assert_resumable()
            checkpoints=[e['payload'] for e in journal.events if e['kind']=='session_completed']
            assert [x['session_id'] for x in checkpoints]==[s['id'] for s in planned['scenario']['sessions'][9:11]]
            new=base.delivered_exchanges(journal)
            assert len(new)==4 and all(x['runtime_settlement']=='completed' for x in new)
            assert [x['transcript']['turn_id'] for x in new]==[t['id'] for s in planned['scenario']['sessions'][9:11] for t in s['turns']]
            assert journal.events[-1]['kind']=='paused'
            checkpoint=checkpoints[-1]
            ledger=[json.loads(x) for x in (TAIL/'calls.jsonl').read_text().splitlines()]
            assert digest(ledger)==checkpoint['ledger_sha256']
            assert checkpoint['usage']['usage_unknown_calls']==0
            assert inherited['usage']['usage_unknown_calls']==1
            prefix=base.delivered_exchanges(parent)+new
            source=next(x for x in prefix if x['transcript']['turn_id']=='blackout-memory')
            input_event,=source['sources']['input_events']
            assert input_event['observed']['actor_role']=='user'
            assert input_event['observed']['content']['text']==source['transcript']['user_text']
            assert digest(input_event['observed']['content'])==input_event['content_sha256']
            review=json.loads((VERIFY/'stage-11-review.json').read_text())
            assert review['review_completed'] and review['source_integrity']=='pass'
            assert review['source_head_sha256']==journal.events[-1]['sha256']
            binding={'path':str(TAIL),'plan_sha256':journal.plan_sha256,'head_sha256':journal.events[-1]['sha256'],
                     'checkpoint':checkpoint,'principal':inherited['initial']['principal'],'brain_id':inherited['initial']['brain_id'],
                     'source_evidence':source,'actual_received_prefix':prefix,'original_unanswered_input':inherited['unanswered_input'],
                     'parent_head_sha256':parent.events[-1]['sha256'],'parent_usage':inherited['usage'],
                     'boundary_disclosure':'Eleven attempted original sessions; ten complete and one with an unanswered host call. Twenty-two delivered turns plus one unanswered input. Original clean-boundary acceptance condition is unmet; this is an amended exploratory diagnostic.',
                     'binding_executor_sha256':digest(Path(__file__).read_text()),'review_sha256':digest(review)}
            tail_files={name:digest((TAIL/name).read_text()) for name in ('plan.json','journal.jsonl','head.json','calls.jsonl')}
            yield journal,binding
            assert {name:digest((PARENT/name).read_text()) for name in inherited['source_files']}==inherited['source_files']
            assert {name:digest((TAIL/name).read_text()) for name in tail_files}==tail_files
