import copy
import json
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from examples import evaluate_longitudinal as base
from examples.longitudinal_journal import CampaignJournal

verify=Path('.local/longitudinal-v7-verification')
paths={key:Path('.local')/name for key,name in [('initial_240s','longitudinal-life-v6'),('primary','longitudinal-life-v7'),('tail','longitudinal-life-v7-tail'),('cue','longitudinal-v7-cues')]}
journals={};plans={};ledgers={};heads={}
for key,path in paths.items():
 with CampaignJournal(path,json.loads((path/'plan.json').read_text())) as j:
  journals[key]=j.events;plans[key]=j.plan;heads[key]=j.events[-1]['sha256']
  ledgers[key]=[json.loads(x) for x in (path/'calls.jsonl').read_text().splitlines()]
  assert journals[key][-1]['kind'] in ('completed','stopped')
assert journals['tail'][-1]['kind']=='completed' and journals['cue'][-1]['kind']=='completed'
base.validate_plan(plans['primary'])
assert plans['tail']==json.loads((verify/'tail-plan.json').read_text())
assert plans['tail']['runtime_build']==plans['primary']['runtime_build']
assert plans['tail']['diagnostic_continuation']['source']['source_head_sha256']==heads['primary']
assert plans['cue']['source']['parent_head_sha256']==heads['primary']
original_review=json.loads((verify/'main-terminal-review.json').read_text())
tail_review=json.loads((verify/'tail-judgments.json').read_text())
judgments={**original_review['turn_judgments'],**tail_review['turns'],
           'dinner-shopping':{'verdict':'failed_no_answer','reason':'Host timeout overlapping macOS sleep; no assistant output, no retry, unknown usage retained.'}}
story=plans['primary']['scenario']
expected=[turn['id'] for session in story['sessions'] for turn in session['turns']]
assert len(expected)==33 and set(judgments)==set(expected)
rows=journals['primary']+journals['tail']
selections=[x['payload'] for x in rows if x['kind']=='user_selected']
actual=[story['sessions'][x['session_index']]['turns'][x['turn_index']]['id'] for x in selections]
assert actual==expected
initials=[x['payload'] for x in rows if x['kind']=='initialized']
assert len(initials)==2 and initials[0]==initials[1]
completed=[x['payload'] for x in rows if x['kind']=='turn_completed']
assert len(completed)==32
learning=[x['payload'] for x in rows if x['kind']=='learning_completed']
assert len(learning)==32 and all(not x['stop_reason'] and x['encoding_coverage']['complete'] for x in learning)
assert sum(x['kind']=='session_started' for x in rows)==16
assert sum(x['kind']=='session_completed' for x in rows)==15
assert sum(x['kind']=='checkpoint_verified' for x in rows)==3
turns=[]
for key in ('primary','tail'):
 events=journals[key]
 settled={e['payload']['result']['turn_id']:e['payload'] for e in events if e['kind']=='runtime_completed'}
 for e in events:
  if e['kind']!='delivered_exchange':continue
  p=e['payload'];result=settled[p['runtime_turn_id']]
  assert result['result']['stage']=='completed'
  turns.append({'segment':key,'delivery_event_sha256':e['sha256'],'transcript':p['transcript'],
                'answer_sha256':digest(p['transcript']['assistant_text']),'branch':p['branch'],
                'input_events':result['sources']['input_events'],'runtime_stage':result['result']['stage'],
                'judgment':judgments[p['transcript']['turn_id']]})
usage={}
for key,ledger in ledgers.items():
 reserved={x['request_id']:x for x in ledger if x['event']=='reserved'}
 finished={x['request_id']:x for x in ledger if x['event']=='completed'}
 assert len(reserved)==len(finished) and set(reserved)==set(finished)
 totals=Counter()
 for call in finished.values():
  if call['usage_confirmed']:
   for name in ('prompt_tokens','completion_tokens','total_tokens'):totals[name]+=call['usage'][name]
 assert totals['prompt_tokens']+totals['completion_tokens']==totals['total_tokens']
 usage[key]={'calls':len(finished),'known_calls':sum(x['usage_confirmed'] for x in finished.values()),
             'unknown_calls':sum(not x['usage_confirmed'] for x in finished.values()),
             'reserved_output_tokens':sum(x['reserved_output_tokens'] for x in reserved.values()),'known_tokens':dict(totals)}
assert usage['primary']['calls']+usage['tail']['calls']<=plans['primary']['max_calls']
assert usage['primary']['reserved_output_tokens']+usage['tail']['reserved_output_tokens']<=plans['primary']['max_reserved_output_tokens']
assert usage['cue']['calls']<=15 and not usage['tail']['unknown_calls'] and not usage['cue']['unknown_calls']
starts=[x['payload']['actual_started_at'] for x in rows if x['kind']=='invocation_started']
ends=[x['payload']['actual_finished_at'] for x in rows if x['kind'] in ('paused','completed','stopped') and 'actual_finished_at' in x['payload']]
intervals=[{'start':x['payload']['actual_started_at'],'pid':x['payload']['pid']} for x in rows if x['kind']=='invocation_started']
active=sum(x['payload']['invocation_seconds'] for x in rows if x['kind'] in ('paused','completed','stopped') and 'invocation_seconds' in x['payload'])
cases=[{**case,'judgment':judgments[case['at_turn']]} for case in story['private_review']['cases']]
category=lambda v:'pass' if v.startswith('pass') else 'partial' if v.startswith('partial') else 'fail'
result={'version':'varied-longitudinal-diagnostic-2026-10-26','acceptance':'not_passed','runtime_build':plans['primary']['runtime_build'],
 'scope':{'fictional_days':56,'attempted_sessions':16,'complete_sessions':15,'partial_sessions':1,'attempted_inputs':33,'completed_replies':32,'unanswered_inputs':1,'named_cases':16,'primary_replay_checkpoints':3},
 'source_base_revision':'f1daa5b3e92a88a666b78f9410be1f3dbbdc7f80','plan_sha256':{k:digest(v) for k,v in plans.items()},'journal_heads':heads,
 'reviewer':'Implementing Codex source reviewer independent of the tested host and user actor; not a blinded external human panel.',
 'deviations':['Semantic failures retained while continuing the frozen scenario for diagnosis.','Host timeout overlapped macOS sleep. Original campaign closed; same-brain new-session tail skipped the unanswered request, retained unknown usage, and subtracted earlier reservations.','Auxiliary boundary is eleven attempted sessions, including one partial session, not the original eleven clean sessions. Exploratory diagnostics cannot establish acceptance.'],
 'usage':usage,'total_calls_this_round':sum(v['calls'] for v in usage.values()),'known_tokens_this_round':sum(v['known_tokens']['total_tokens'] for v in usage.values()),'unknown_calls_this_round':sum(v['unknown_calls'] for v in usage.values()),
 'timing':{'first_primary_start':starts[0],'final_tail_end':ends[-1],'calendar_elapsed_seconds':(datetime.fromisoformat(ends[-1])-datetime.fromisoformat(starts[0])).total_seconds(),'instrumented_invocation_seconds':active,'invocations':intervals,'limitation':'Calendar duration includes sleep, review gaps and auxiliary diagnostics. Instrumented monotonic samples are not an always-awake wall-time SLA.'},
 'assistance':dict(Counter(x['branch'] for x in turns)),'all_input_verdicts':dict(Counter(category(v['verdict']) for v in judgments.values())),
 'named_case_verdicts':dict(Counter(category(x['judgment']['verdict']) for x in cases)),'named_cases':cases,'turns':turns,
 'unanswered_input':plans['tail']['diagnostic_continuation']['source']['unanswered_input'],
 'publication_review':{'primary':original_review['publication_review'],'tail':tail_review['publication_review']},
 'cue_review':json.loads((verify/'cue-review.json').read_text()),'access_age_review':json.loads((verify/'access-age/review.json').read_text()),
 'limitations':['One authored fictional user, not a human field trial.','No 56-day actual operation or biological forgetting claim.','No baseline superiority experiment.','A successful scaffold/engineering test does not imply behavioral maturity.','No Codex/Claude subscription-backed test, paid answer reviewer or additional age-answer call.']}
(verify/'final-data.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:result[k] for k in ('scope','total_calls_this_round','known_tokens_this_round','unknown_calls_this_round','timing','assistance','all_input_verdicts','named_case_verdicts')}))
