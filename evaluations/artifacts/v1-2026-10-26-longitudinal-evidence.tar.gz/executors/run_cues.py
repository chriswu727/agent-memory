import inspect
import json
import sys
import textwrap
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory.helpers import digest
from examples import longitudinal_cue_diagnostics as cue
from diagnostic_binding import source_campaign, TAIL, VERIFY

OUTPUT=Path.cwd()/'.local/longitudinal-v7-cues'
with source_campaign(TAIL) as (_,binding):
    planned=cue.plan(binding)
    review={'plan':planned,'plan_sha256':digest(planned),'executor_sha256':digest(Path(__file__).read_text()),
            'scope':'Exploratory identical-source copies after disclosed sleep-interrupted primary segment. Failed host call and unknown usage remain in source binding. No confirmatory clean-boundary acceptance claim.',
            'review':'Same original five probe texts, source-based rubric, alternate callback, model settings and fifteen-call ceiling. Copies never merge back. No background learning, actor, retries or paid reviewer.'}
    path=VERIFY/'cue-bound-review.json'
    assert not path.exists() and not OUTPUT.exists()
    path.write_text(json.dumps(review,ensure_ascii=False,indent=2))
namespace=dict(vars(cue));namespace['source_campaign']=source_campaign
exec(compile(textwrap.dedent(inspect.getsource(cue.live)),'<frozen-tail-cues>','exec'),namespace)
result=namespace['live'](TAIL,OUTPUT)
print(json.dumps(result,ensure_ascii=False,indent=2))
