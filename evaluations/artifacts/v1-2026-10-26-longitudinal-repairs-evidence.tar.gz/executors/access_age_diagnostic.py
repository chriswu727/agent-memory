from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from collections import Counter
from datetime import UTC, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

import agent_memory
import psycopg
from psycopg import sql
from psycopg.rows import dict_row

from agent_memory.build_identity import BUILD_ID, manifest_digest, package_manifest
from agent_memory.client import default_budget, default_read_fence
from agent_memory.dynamics import DEFAULT_POLICY, access_state
from agent_memory.helpers import Principal, digest
from agent_memory.service import MemoryService
from agent_memory.storage import Database

QUERIES = (
    ("writing_goal", "short story writing outline"),
    ("fictional_detail", "observatory letter sister"),
    ("class_schedule", "evening class Tuesdays Thursdays"),
    ("assistant_proposal", "Wednesday Saturday writing"),
)
AGES = (0, 365, 3650)


def configure(conn, principal):
    conn.execute("SET LOCAL statement_timeout = '5000'")
    conn.execute("SET LOCAL lock_timeout = '1000'")
    conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",
                 (principal.tenant_id, principal.principal_id))


def scoped_tables(conn):
    rows = conn.execute(
        "SELECT table_name,array_agg(column_name::text) AS columns FROM information_schema.columns "
        "WHERE table_schema=current_schema() AND table_name LIKE 'memory_%' GROUP BY table_name ORDER BY table_name"
    ).fetchall()
    tables = [(row["table_name"], "id" if row["table_name"] == "memory_brains" else "brain_id", "owner_id" in row["columns"])
              for row in rows if {"tenant_id", "id" if row["table_name"] == "memory_brains" else "brain_id"}
              <= set(row["columns"])]
    assert 1 <= len(tables) <= 128
    return tables


def snapshot(conn, params, tables):
    result = {}
    for table, key, has_owner in tables:
        statement = sql.SQL("SELECT row_to_json(t) AS data FROM {} t WHERE tenant_id=%s {} AND {}=%s LIMIT 10001").format(
            sql.Identifier(table), sql.SQL("AND owner_id=%s") if has_owner else sql.SQL(""), sql.Identifier(key))
        rows = conn.execute(statement, params if has_owner else (params[0], params[2])).fetchall()
        assert len(rows) <= 10000, "Snapshot row bound exceeded"
        result[table] = {"rows": len(rows), "sha256": digest(sorted(digest(row["data"]) for row in rows))}
    return {"tables": result, "sha256": digest(result)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--reference-time")
    parser.add_argument("--expect-snapshot-sha256")
    args = parser.parse_args()
    assert Path(agent_memory.__file__).resolve().is_relative_to(ROOT / "src")
    assert os.environ.get("PYTHON_DOTENV_DISABLED") == "1"
    assert not any(key.startswith(("MEMORY_COGNITION_", "MEMORY_EMBEDDING_", "DEEPSEEK_", "OPENAI_"))
                   for key in os.environ)
    campaign = ROOT / ".local/longitudinal-life-v1"
    journal = [json.loads(line) for line in (campaign / "journal.jsonl").read_text().splitlines()]
    initial, = [row["payload"] for row in journal if row["kind"] == "initialized"]
    principal = Principal(**initial["principal"])
    params = (principal.tenant_id, principal.principal_id, initial["brain_id"])
    started = datetime.now(UTC)
    label = lambda identifier, revision: "memory-" + digest([identifier, revision])[:12]
    results = []
    clock_calls = 0

    with psycopg.connect(os.environ["MEMORY_DATABASE_URL"], row_factory=dict_row, autocommit=True) as conn:
        with conn.transaction(force_rollback=True):
            conn.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ")
            configure(conn, principal)
            tables = scoped_tables(conn)
            before = snapshot(conn, params, tables)
            if args.expect_snapshot_sha256:
                assert before["sha256"] == args.expect_snapshot_sha256, "The persisted source snapshot changed"
            brain = conn.execute("SELECT * FROM memory_brains WHERE tenant_id=%s AND owner_id=%s AND id=%s", params).fetchone()
            assert brain is not None
            reference = (datetime.fromisoformat(args.reference_time) if args.reference_time else
                         conn.execute("SELECT clock_timestamp() AS instant").fetchone()["instant"])
            assert reference.tzinfo is not None
            reference = reference.astimezone(UTC)
            memories = [row["document"] for row in conn.execute(
                "SELECT document FROM memory_assertions WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s "
                "AND is_current AND NOT invalidated AND NOT deleted AND NOT suppressed AND document IS NOT NULL ORDER BY id,revision",
                params).fetchall()]
            assert 1 <= len(memories) <= 256
            usage = {(row["memory_id"], row["memory_revision"]): row for row in conn.execute(
                "SELECT * FROM memory_access_state WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s", params).fetchall()}
            events = [row["document"] for row in conn.execute(
                "SELECT document FROM memory_events WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s "
                "AND is_current AND NOT deleted AND NOT suppressed ORDER BY sequence", params).fetchall()]
            conversations = {event["scope"]["conversation_id"] for event in events}
            assert len(conversations) == 1, "This bounded diagnostic expects the completed v1 conversation"
            target = {"brain_ref": brain["id"], "conversation_ref": conversations.pop(), "branch_ref": "main"}
            active_worlds = sorted({memory["world"] for memory in memories})
            access_evaluations = []
            for days in AGES:
                at = (reference + timedelta(days=days)).isoformat()
                states = [{"memory": label(memory["memory_id"], memory["revision"]),
                           **access_state(memory, usage.get((memory["memory_id"], memory["revision"])), at=at)}
                          for memory in memories]
                access_evaluations.append({"elapsed_days": days, "access_evaluated_at": at,
                                           "tiers": dict(Counter(item["tier"] for item in states)), "memories": states})

                def access_time():
                    nonlocal clock_calls
                    clock_calls += 1
                    return at

                service = MemoryService(Database(os.environ["MEMORY_DATABASE_URL"]), access_time_provider=access_time)
                for query_name, text in QUERIES:
                    for intent in ("explore", "cue_recovery"):
                        query = {"query": text, "intent": intent, "cue_event_ids": [], "additional_cues": [],
                                 "evidence_mode": "prior_record_check", "world_filter": active_worlds,
                                 "evidence_cutoff": {"mode": "through_sequence", "through_sequence": brain["durable_sequence"]},
                                 "read_fence": default_read_fence(brain["durable_sequence"]), "budget": default_budget(64000)}
                        call_started = datetime.now(UTC)
                        with conn.transaction(force_rollback=True):
                            result, _, _ = service._retrieval(conn, principal, brain, target, query)
                        call_finished = datetime.now(UTC)
                        after_call = snapshot(conn, params, tables)
                        assert after_call == before, "Retrieval changed the frozen snapshot after rollback"
                        audit = [result["retrieval_snapshot"]["created_at"],
                                 *(trace["recorded_at"] for trace in result["recall_traces"])]
                        assert all(call_started <= datetime.fromisoformat(value) <= call_finished for value in audit)
                        assert result["usage"]["model_calls"] == result["usage"]["embedding_calls"] == 0
                        results.append({"query": query_name, "query_sha256": digest(text), "intent": intent,
                                        "elapsed_days": days, "status": result["status"],
                                        "coverage_limitations": result["coverage"]["limitations"],
                                        "source_count": len({ref["event_id"] for item in result["items"] for ref in item["memory"]["evidence_refs"]}),
                                        "stopped_by": result["usage"]["stopped_by"],
                                        "items": [{"memory": label(item["memory"]["memory_id"], item["memory"]["revision"]),
                                                   "position": index + 1, "rank_signal_sum": sum(signal["score"] for signal in item["rank_signals"]),
                                                   "retrieved_from": item["retrieved_from"], "display_mode": item["display_mode"]}
                                                  for index, item in enumerate(result["items"])]})
            assert snapshot(conn, params, tables) == before
        with conn.transaction(force_rollback=True):
            conn.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
            configure(conn, principal)
            after = snapshot(conn, params, tables)
            assert after == before, "Persisted state changed after the outer rollback"

    assert clock_calls == len(QUERIES) * len(AGES) * 2 == 24
    source_root = ROOT / "src/agent_memory"
    assert manifest_digest(package_manifest(source_root, ROOT)) == BUILD_ID, "Runtime code changed during the diagnostic"
    comparisons = []
    for query_name, _ in QUERIES:
        for intent in ("explore", "cue_recovery"):
            runs = [run for run in results if run["query"] == query_name and run["intent"] == intent]
            baseline = {item["memory"]: item for item in runs[0]["items"]}
            for run in runs[1:]:
                aged = {item["memory"]: item for item in run["items"]}
                common = baseline.keys() & aged.keys()
                comparisons.append({"query": query_name, "intent": intent, "elapsed_days": run["elapsed_days"],
                                    "same_membership": baseline.keys() == aged.keys(), "common_memories": len(common),
                                    "lower_signal_sum": sum(aged[key]["rank_signal_sum"] < baseline[key]["rank_signal_sum"] for key in common),
                                    "same_signal_sum": sum(aged[key]["rank_signal_sum"] == baseline[key]["rank_signal_sum"] for key in common),
                                    "position_changes": sum(aged[key]["position"] != baseline[key]["position"] for key in common)})
    report = {
        "version": "frozen-v1-access-age-diagnostic-v1", "actual_started_at": started.isoformat(),
        "actual_finished_at": datetime.now(UTC).isoformat(), "access_reference_time": reference.isoformat(),
        "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "runtime_build": BUILD_ID, "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "campaign_plan_sha256": hashlib.sha256((campaign / "plan.json").read_bytes()).hexdigest(),
        "time_mode": "frozen_snapshot_access_age_only", "elapsed_day_offsets": list(AGES),
        "completed_source_turns": sum(row["kind"] == "turn_completed" for row in journal),
        "source_events": len(events), "active_assertions": len(memories), "access_ledger_rows": len(usage),
        "derivation_counts": dict(Counter(memory["derivation"]["method"] for memory in memories)),
        "brain_watermarks": {key: brain[key] for key in ("durable_sequence", "indexed_sequence", "dependency_generation", "scope_generation")},
        "snapshot": before, "checks": {"all_24_call_rollbacks_equal": True, "outer_rollback_equal": after == before,
                                       "single_access_clock_read_per_retrieval": True, "audit_clock_remained_actual": True,
                                       "provider_calls": 0, "embedding_calls": 0, "schema_changes": 0},
        "policy": {"version": DEFAULT_POLICY.version, "half_life_days": dict(DEFAULT_POLICY.half_life_days),
                   "retention_half_life_gain": DEFAULT_POLICY.retention_half_life_gain,
                   "everyday_threshold": DEFAULT_POLICY.everyday_threshold, "cue_threshold": DEFAULT_POLICY.cue_threshold},
        "memory_catalog": [{"memory": label(memory["memory_id"], memory["revision"]), "statement_sha256": digest(memory["statement"]),
                            "kind": memory["memory_kind"], "representation": memory.get("representation", "legacy_episodic_fallback"),
                            "derivation": memory["derivation"]["method"], "world": memory["world"],
                            "age_days_at_reference": (reference - datetime.fromisoformat(memory["system_time"]["recorded_at"])).total_seconds() / 86400}
                           for memory in memories],
        "access_evaluations": access_evaluations, "retrievals": results, "comparisons": comparisons,
        "limitations": ["Only one completed source conversation turn; no external reinforcement ledger rows.",
                        "Day zero is a shared snapshot reference, not rewritten per-memory creation time.",
                        "Queries were selected from known source content to exercise age weighting; this is not a blind recall benchmark.",
                        "Both intents use the same explicit historical cutoff and all existing memory worlds.",
                        "Ranks and access tiers are engineering diagnostics, not semantic accuracy, human forgetting rates or maturity.",
                        "The unmodified retrieval path writes audit traces inside savepoints; every call and the enclosing transaction roll back.",
                        "No simulated interaction, validity advance, new memory, feedback or source timestamp rewrite occurred."]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "retrievals": len(results), "snapshot_equal": after == before,
                      "tiers": [{"days": item["elapsed_days"], **item["tiers"]} for item in access_evaluations],
                      "comparisons": comparisons}, indent=2))


if __name__ == "__main__":
    main()
