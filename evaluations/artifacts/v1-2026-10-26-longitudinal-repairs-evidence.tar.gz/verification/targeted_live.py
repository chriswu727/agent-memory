import argparse
import copy
import hashlib
import json
import os
import sys
import time
from contextlib import ExitStack
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path.cwd()))
from agent_memory.build_identity import BUILD_ID
from agent_memory.chat_provider import ChatCompletionsGenerator
from agent_memory.client import default_budget, default_read_fence, integration_capabilities
from agent_memory.config import Settings
from agent_memory.contracts import CONTRACT_VERSION
from agent_memory.helpers import Principal, digest, uid
from agent_memory.local_semantics import LOCAL_OBSERVATION_MODE
from agent_memory.runtime import BrainRuntime, ModelRequest, RuntimePolicy
from agent_memory.semantic import CognitiveBatch, LATEST_INPUT_CONTRACT_VERSION, SemanticPolicy, SemanticProcessor
from agent_memory.semantic_provider import ChatCompletionsSemanticProvider
from agent_memory.service import MemoryService
from agent_memory.storage import Database
from examples.evaluate_memory_lifecycle import archive_graph
from examples.evaluation_support import MeteredTransport

ROOT=Path.cwd();WORK=ROOT/'.local/longitudinal-repairs';OUTPUT=ROOT/'.local/longitudinal-repair-live'
SOURCE=ROOT/'.local/longitudinal-v7-cues/source-archive.json'

def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def stamp():return datetime.now(UTC).isoformat()

def prepare():
 assert not OUTPUT.exists()
 OUTPUT.mkdir(mode=0o700)
 archive=json.loads(SOURCE.read_text());source_scope=archive['document']['events'][0]['scope']
 principal=Principal(source_scope['tenant_id'],source_scope['principal_binding_id'])
 service=MemoryService(Database(Settings.from_env().database_url))
 assert service.semantic_processor is service.embedding_provider is None
 assert digest(service.download_archive(principal,archive['archive_id']))==digest(archive)
 old=json.loads((ROOT/'.local/longitudinal-v7-cues/plan.json').read_text())
 reference_graph=archive_graph(archive['document']);graph_hash=digest(reference_graph)
 inputs=[]
 for case in old['cases']:
  brain=service.create_brain(principal,'Frozen repair probe '+case['id'])['id']
  target={'brain_ref':brain,'conversation_ref':'repair-'+case['id']+'-'+uid(),'branch_ref':'main'}
  def action(name,payload):
   reply=service.handle(principal,{'message_type':'request','contract_version':CONTRACT_VERSION,
    'request_id':uid(),'action':name,'target':target,'payload':payload})
   assert reply['outcome']=='completed',reply
   return reply['result']
  restored=action('restore',{'uploaded_archive_ref':archive['archive_id'],
   'expected_manifest_sha256':archive['manifest_sha256'],'mode':'new_brain','apply_current_tombstones':True,
   'expected_scope_generation':1,'budget':default_budget(64000)})
  assert restored['read_enabled'] and restored['quarantined_event_count']==0
  exported=action('export',{'include_events':True,'include_assertions':True,'include_working_states':True,
   'include_provenance':True,'include_tombstones':True,'budget':default_budget(64000)})
  actual=archive_graph(service.download_archive(principal,exported['archive_id'])['document'],restored=True)
  originals={e['event_id']:e for e in reference_graph['events']}
  from agent_memory import cognition
  for event in actual['events']:
   if 'segmentation_rule_version' not in originals[event['event_id']]:
    assert event.pop('segmentation_rule_version')==cognition._literal_rule_version(originals[event['event_id']])
  assert digest(actual)==graph_hash
  received=action('observe',{'idempotency_key':uid(),'events':[{
   'producer_ref':'repair-diagnostic','source_event_key':case['id'],'source_revision':1,
   'actor_ref':'user','actor_role':'user','event_kind':'message','delivery_state':'received',
   'interpretation_hint':'unknown','content':{'media_type':'text/plain','text':case['text']},
   'occurred_time':{'start':None,'end':None,'precision':'unknown','basis':'unknown'}}]})
  packet=action('prepare',{'turn_id':'repair-'+case['id'],'latest_input_event_ids':received['accepted_event_ids'],
   'read_fence':default_read_fence(received['durable_through_sequence']),'budget':default_budget(16000),
   'capabilities':integration_capabilities(),'recent_event_limit':6})
  runtime=BrainRuntime(SimpleNamespace(brain_id=brain),lambda _:None,instructions=old['host_instructions'],
                       policy=RuntimePolicy(**old['runtime_policy']))
  request=runtime._prompt('repair-'+case['id'],case['text'],packet)
  inputs.append({'case':case,'brain_id':brain,'source_graph_sha256':graph_hash,
                 'request':asdict(request),'packet':packet})
 source=next(e for e in archive['document']['events'] if e['observed']['actor_role']=='user'
             and 'When our power went out, Grandma would' in e['observed']['content'].get('text',''))
 scope=source['scope'];stamp_value=source['system_time']['recorded_at']
 batch=CognitiveBatch('repair-source-act',scope,(source,),working_state={
  'scope':scope,'revision':0,'through_sequence':0,'items':[],'open_loops':[],'updated_at':stamp_value},
  sampling={'strategy':LOCAL_OBSERVATION_MODE,'through_sequence':source['sequence'],
   'indexed_through_sequence':0,'search_exhaustive':False,'publication_restricted':False,
   'source_count':1,'assertion_count':0,'episode_count':0,'omitted_packages':0,'limitations':[]},
  proposal_mode=LOCAL_OBSERVATION_MODE,learning_input_refs=({'event_id':source['event_id'],'revision':source['revision']},),
  input_contract_version=LATEST_INPUT_CONTRACT_VERSION)
 policy=SemanticPolicy(max_wall_time_ms=600000,max_output_tokens=16384,max_response_bytes=65536)
 planned={'runtime_build':BUILD_ID,'source_archive_sha256':archive['manifest_sha256'],
  'source_file_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source_graph_sha256':graph_hash,
  'created_at':stamp(),'executor_sha256':digest(Path(__file__).read_text()),'model':old['provider'],
  'cognitive_effort':'low','host_timeout_seconds':240,'host_output_tokens':4096,'provider_envelope_bytes':262144,
  'max_calls':7,'max_reserved_output_tokens':53248,'batch':asdict(batch),'semantic_policy':asdict(policy),'host_inputs':inputs,
  'scope':'Two-call isolated encoding of one retained source, then five frozen prepared host requests on independent restored copies. No actor, background learning, source mutation, retries or automatic answer reviewer. Not a new longitudinal acceptance pass.',
  'stop_rules':['Stop at unknown usage, provider failure or invalid required processing.','Pause after encoding for whole-source review before host calls.','Keep failed semantic/host judgments; no replacement probe.'],
  'rubric':{'encoding':'Accepted concise attributed blackout report and user-expressed safety meaning, with complete declarative source spans and no question as proof.',
   'unaided':'Use original family scene and meaning without re-teaching, invented locations or language switch.',
   'broadcue':'Recover unsupplied lantern/button details and user meaning; no table, kitchen or house-owner invention.',
   'specificcue':'Recover unsupplied details/meaning; supplied cue facts get no recall credit; no house-owner invention.',
   'unknowndetail':'Admit photo storage location was not supplied; practical suggestions must be conditional.',
   'falsepremise':'Do not confirm invented childhood trip or present; preserve uncertainty and separate actual known memory.'}}
 write(OUTPUT/'plan.json',planned)
 print(json.dumps({'state':'prepared_no_provider_calls','plan_sha256':digest(planned),'inputs':len(inputs),'runtime_build':BUILD_ID}))

def live(stage):
 planned=json.loads((OUTPUT/'plan.json').read_text())
 assert planned['runtime_build']==BUILD_ID
 assert planned['executor_sha256']==digest(Path(__file__).read_text())
 assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==planned['source_file_sha256']
 log=(WORK/'full-final.log').read_text()
 assert 'failed' not in log and 'passed' in log and '[100%]' in log
 if stage=='encoding':assert not (OUTPUT/'encoding-result.json').exists() and not (OUTPUT/'calls.jsonl').exists()
 else:
  review=json.loads((OUTPUT/'encoding-review.json').read_text())
  assert review['continue_host_probes'] is True and review['plan_sha256']==digest(planned)
  assert not (OUTPUT/'host-results.json').exists()
 Settings.from_env();key=os.environ['DEEPSEEK_API_KEY'];records=[]
 def save():write(OUTPUT/(stage+'-calls.json'),records)
 with ExitStack() as stack:
  meter=MeteredTransport(OUTPUT/'calls.jsonl',max_calls=planned['max_calls'],
   max_output_tokens=planned['max_reserved_output_tokens'],capture_content=False,max_response_bytes=planned['provider_envelope_bytes'])
  stack.callback(meter.close)
  def boundary():
   summary=meter.summary()
   assert summary['usage_unknown_calls']==0 and summary['reserved_calls']==summary['completed_calls'],summary
  boundary()
  def measured(provider,request,case):
   entry={'case':case,'started_at':stamp(),'request':asdict(request)};records.append(entry);save()
   start=time.monotonic()
   try:
    result=provider(request);entry.update(finished_at=stamp(),elapsed_seconds=time.monotonic()-start,
                                         output=result,usage=provider.last_usage);save();boundary();return result
   except Exception as error:
    entry.update(finished_at=stamp(),error_type=type(error).__name__);save();raise
  if stage=='encoding':
   provider=ChatCompletionsSemanticProvider(planned['model']['base_url'],key,planned['model']['model'],
    thinking='enabled',reasoning_effort='low',max_response_bytes=planned['provider_envelope_bytes'],transport=meter)
   stack.callback(provider.close)
   data=planned['batch'];data={**data,**{k:tuple(data[k]) for k in ('sources','existing_assertions','episodes','belief_relations','current_input_refs','learning_input_refs')}}
   result=SemanticProcessor(lambda r:measured(provider,r,'encoding'),lambda r:measured(provider,r,'verification'),
                            SemanticPolicy(**planned['semantic_policy'])).process(CognitiveBatch(**data),reserve=lambda **_:None)
   write(OUTPUT/'encoding-result.json',{'result':asdict(result),'usage':meter.summary(),'plan_sha256':digest(planned)})
   boundary();assert result.status in {'completed','partial'},result.status
  else:
   provider=ChatCompletionsGenerator(planned['model']['base_url'],key,planned['model']['model'],
    thinking='enabled',reasoning_effort='high',max_output_tokens=4096,timeout_seconds=240,
    max_response_bytes=planned['provider_envelope_bytes'],transport=meter)
   stack.callback(provider.close)
   results=[]
   for item in planned['host_inputs']:
    data=item['request'];request=ModelRequest(**{**data,'messages':tuple(data['messages'])})
    answer=measured(provider,request,item['case']['id'])
    results.append({'case':item['case'],'answer':answer,'request_sha256':digest(data)})
    write(OUTPUT/'host-results.partial.json',{'results':results,'usage':meter.summary(),'plan_sha256':digest(planned)})
   write(OUTPUT/'host-results.json',{'results':results,'usage':meter.summary(),'plan_sha256':digest(planned)})
 print(json.dumps({'state':stage+'_completed','usage':meter.summary()}))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--stage',choices=('encoding','host'))
 args=parser.parse_args()
 if args.prepare:prepare()
 elif args.stage:live(args.stage)
 else:parser.error('Choose --prepare or an explicit bounded stage')
