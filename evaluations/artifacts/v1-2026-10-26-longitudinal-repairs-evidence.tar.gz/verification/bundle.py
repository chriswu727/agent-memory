import gzip,hashlib,io,json,os,re,tarfile
from pathlib import Path
from dotenv import dotenv_values
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
root=Path.cwd();work=root/'.local/longitudinal-repairs';live=root/'.local/longitudinal-repair-live';public=root/'evaluations'
previous=json.loads((public/'v1-2026-10-26-longitudinal-round.json').read_text())
continuity={}
for key,directory in [('primary','longitudinal-life-v7'),('tail','longitudinal-life-v7-tail')]:
 path=root/'.local'/directory
 last=json.loads((path/'journal.jsonl').read_text().splitlines()[-1])
 assert last['sha256']==previous['journal_heads'][key]
 assert digest(json.loads((path/'plan.json').read_text()))==previous['plan_sha256'][key]
 continuity[key]={'head_sha256':last['sha256'],'plan_sha256':previous['plan_sha256'][key],'unchanged':True}
(work/'original-continuity.json').write_text(json.dumps(continuity,indent=2)+'\n')
paths={}
for path in live.iterdir():
 if path.is_file() and path.suffix in ('.json','.jsonl'):paths['live/'+path.name]=path
names=['candidate.patch','artifacts.json','original-continuity.json','replay_snapshot.py','snapshot-replay.json',
 'snapshot-before-passages.json','snapshot-before-tail-calibration.json','snapshot-before-frequency-weight.json',
 'snapshot-before-age-fix.json','snapshot-interrupted-slow.log','snapshot-profile.log','snapshot-plan-helper-error.log',
 'snapshot-scoped-profile.log','episode-query-plans.json','sql-profile.partial.json','history-cost-audit.json',
 'targeted_live.py','targeted-final-preflight.log','plan-before-dto-fix.json','live-encoding.log','live-host.log',
 'report_data.py','artifacts_check.py','measure-fixed-retrieval.py','measure-capabilities.py','capability-performance.json',
 'retrieval-performance.json','retrieval-performance.log','first-focused.log','focused-fixed.log','expanded-focused.log',
 'full-source.log','full-integrated.log','full-final.log','access-clock-fixed.log','compact-dto-followup.log',
 'installed-delivery.log','desktop-delivery.log','typescript-initial-failure-note.json','typescript-tests.log',
 'typescript-typecheck.log','source-act-contract.log','passage-regressions.log','tail-calibration.log','integrated-focused.log']
for name in names:
 p=work/name;assert p.is_file(),name;paths['verification/'+name]=p
paths['source/source-archive.json']=root/'.local/longitudinal-v7-cues/source-archive.json'
paths['executors/access_age_diagnostic.py']=root/'.local/longitudinal-v3-verification/access_age_diagnostic.py'
paths['verification/bundle.py']=Path(__file__)
secrets={**os.environ,**dotenv_values(root/'.env')}
secret_values=[value.encode() for key,value in secrets.items() if value and len(value)>=8 and
               any(part in key.upper() for part in ('API_KEY','TOKEN','PASSWORD','SECRET','DATABASE_URL'))]
raws={};entries=[]
for name,p in sorted(paths.items()):
 raw=p.read_bytes()
 assert not any(value in raw for value in secret_values),'Configured credential match in '+name
 assert not re.search(rb'sk-[A-Za-z0-9_-]{16,}',raw),'Possible key in '+name
 raws[name]=raw;entries.append({'name':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
archive=public/'artifacts/v1-2026-10-26-longitudinal-repairs-evidence.tar.gz'
with archive.open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
  with tarfile.open(mode='w',fileobj=gz) as tar:
   for name,raw in sorted(raws.items()):
    info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(raws)
 for item in tar.getmembers():
  assert item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts
  assert tar.extractfile(item).read()==raws[item.name]
manifest={'version':'longitudinal-repairs-evidence-v1','runtime_build':BUILD_ID,'archive':str(archive.relative_to(public)),
 'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,
 'credential_scan':'All included uncompressed bytes checked against configured credential values and API-key patterns; zero matches.',
 'scope':'Synthetic source archive, frozen requests, provider-reported usage and visible outputs, review, local verification and diagnostic executors. No credentials, personal configuration, hidden reasoning or unrelated user data. Original path metadata can appear. TypeScript initial failure is a disclosed note, not a retained complete raw log.',
 'entries':entries}
(public/'v1-2026-10-26-longitudinal-repairs-evidence.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(entries),'archive_bytes':archive.stat().st_size,'archive_sha256':manifest['archive_sha256'],'secret_matches':0}))
