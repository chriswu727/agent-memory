import json,statistics,subprocess
from pathlib import Path
from agent_memory.build_identity import BUILD_ID
from agent_memory.helpers import digest
root=Path.cwd();work=root/'.local/longitudinal-repairs';live=root/'.local/longitudinal-repair-live';public=root/'evaluations'
plan=json.loads((live/'plan.json').read_text());encoding=json.loads((live/'encoding-result.json').read_text());hosts=json.loads((live/'host-results.json').read_text())
assert plan['runtime_build']==BUILD_ID and hosts['plan_sha256']==digest(plan)==encoding['plan_sha256']
ledger=[json.loads(line) for line in (live/'calls.jsonl').read_text().splitlines()]
assert len([r for r in ledger if r['event']=='reserved'])==7
assert hosts['usage']['usage_unknown_calls']==0 and hosts['usage']['completed_calls']==7
assert hosts['usage']['usage_totals']['total_tokens']==54688
calls=json.loads((live/'encoding-calls.json').read_text())+json.loads((live/'host-calls.json').read_text())
assert all(c.get('usage') and c.get('finished_at') and c.get('output') and not c.get('error_type') for c in calls)
assert sum(c['usage']['total_tokens'] for c in calls)==54688
snapshot=json.loads((work/'snapshot-replay.json').read_text());assert snapshot['provider_calls']==0
assert snapshot['runtime_build']=='463bcd74bc8109a529ce5c7b2bbc16d6fc856aa4539a4f5df7f2371769acfb00'
assert len(snapshot['results'])==6 and snapshot['scoped_tables_unchanged_after_each_read']==25
for arm in snapshot['results']:
 assert arm['result']['usage']['model_calls']==arm['result']['usage']['embedding_calls']==0
 if arm['query_id'].startswith('grandma'):
  statements=[i['memory']['statement'] for i in arm['result']['items']]
  assert any('Grandma would light a lantern' in s for s in statements)
  assert any('scary dark house feel safe' in s for s in statements)
report={'version':'longitudinal-source-recall-repair-2026-10-26','runtime_build':BUILD_ID,
 'source_base_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'acceptance':'G4_not_passed','live_plan_sha256':digest(plan),
 'source_archive_sha256':plan['source_archive_sha256'],'source_graph_sha256':plan['source_graph_sha256'],
 'usage':hosts['usage'],'encoding':{'processing_status':encoding['result']['status'],'accepted_claims':encoding['result']['claims'],
  'rejections':encoding['result']['rejected'],'episode_actions':encoding['result']['episode_actions'],
  'review':json.loads((live/'encoding-review.json').read_text())},
 'host_results':hosts['results'],'host_review':json.loads((live/'host-review.json').read_text()),
 'usage_by_role':{role:{'calls':len(group),'input_tokens':sum(c['usage']['prompt_tokens'] for c in group),
  'output_tokens':sum(c['usage']['completion_tokens'] for c in group),'total_tokens':sum(c['usage']['total_tokens'] for c in group),
  'latencies_seconds':[c['elapsed_seconds'] for c in group]} for role,group in [
   ('cognition',[c for c in calls if c['case'] in ('encoding','verification')]),('host',[c for c in calls if c['case'] not in ('encoding','verification')])]},
 'local_checks':{'full_source':{'passed':5341,'skipped':4,'runtime_build':'463bcd74bc8109a529ce5c7b2bbc16d6fc856aa4539a4f5df7f2371769acfb00',
  'qualification':'A subsequent compact-DTO missing-derivation guard leaves complete MemoryAssertion paths unchanged; 60 affected source checks and 37 TypeScript checks passed after it.'},
  'final_installed':129,'final_desktop_docker':4,'typescript_tests':37,'typescript_typecheck':'passed','ruff':'passed','runtime_files_matching_all_artifacts':118},
 'retrieval_performance':json.loads((work/'retrieval-performance.json').read_text()),
 'capability_performance':json.loads((work/'capability-performance.json').read_text()),
 'snapshot_replay':{'runtime_build':snapshot['runtime_build'],'current_compatibility_patch':'Only missing-metadata DTO rendering changed subsequently; complete snapshot memory rendering is unchanged.',
  'provider_calls':0,'retrievals':6,'tables_unchanged_after_each_read':25,'source_files_unchanged':snapshot['source_files_unchanged'],
  'arms':[{'query_id':x['query_id'],'access_age_days':x['days'],'elapsed_ms':x['result']['usage']['elapsed_ms'],
   'status':x['result']['status'],'context':x['context']} for x in snapshot['results']]},
 'limitations':['Targeted encoded-source and frozen prepared-request replay, not a new complete longitudinal campaign.',
  'No acceptance pass, cross-vendor reliability or real elapsed-year aging claim.',
  'Three whole-answer passes and two failures despite correct recall in the three family-card answers.',
  'Accepted local encoding remains episode fragments, often quotations; no verified gist-first forgetting or cognitive-token saving.',
  'No probe result or isolated encoding publication is merged into the original source brain.',
  'No retry, actor, paid reviewer or Codex/Claude subscription-backed test.']}
(public/'v1-2026-10-26-longitudinal-repairs.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(public/'v1-2026-10-26-longitudinal-repairs-artifacts.json').write_text((work/'artifacts.json').read_text())
tracked=subprocess.check_output(['git','diff','--','src/agent_memory','architecture/memory-contract.schema.json','tests'])
for name in ('src/agent_memory/source_passages.py','tests/test_longitudinal_repairs.py','tests/test_source_passages.py','tests/test_source_act_contract.py'):
 result=subprocess.run(['git','diff','--no-index','--','/dev/null',name],capture_output=True)
 assert result.returncode==1
 tracked+=result.stdout
(work/'candidate.patch').write_bytes(tracked)
print(json.dumps({'runtime_build':BUILD_ID,'calls':7,'known_tokens':54688,'whole_answer_results':report['host_review']['whole_answer_counts']}))
