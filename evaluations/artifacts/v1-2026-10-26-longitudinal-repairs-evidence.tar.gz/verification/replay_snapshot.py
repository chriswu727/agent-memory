import importlib.util
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from agent_memory import cognition
from agent_memory.build_identity import BUILD_ID
from agent_memory.client import default_budget, default_read_fence
from agent_memory.config import Settings
from agent_memory.contracts import CONTRACT_VERSION
from agent_memory.helpers import Principal, digest, uid
from agent_memory.service import MemoryService
from agent_memory.storage import Database

root=Path.cwd(); output=root/'.local/longitudinal-repairs'
source_path=root/'.local/longitudinal-v7-cues/source-archive.json'
archive=json.loads(source_path.read_text())
source_scope=archive['document']['events'][0]['scope']
principal=Principal(source_scope['tenant_id'],source_scope['principal_binding_id'])
settings=Settings.from_env(); database=Database(settings.database_url)
service=MemoryService(database)
queries_profile=[]
class Profiled:
 def __init__(self,conn):self.conn=conn
 def __getattr__(self,name):return getattr(self.conn,name)
 def execute(self,query,params=None):
  import time
  start=time.monotonic()
  try:
   return self.conn.execute(query,params)
  finally:
   queries_profile.append({'sql':query,'elapsed_seconds':time.monotonic()-start})
   (output/'sql-profile.partial.json').write_text(json.dumps(queries_profile,indent=2))
assert service.semantic_processor is service.embedding_provider is None
assert digest(service.download_archive(principal,archive['archive_id']))==digest(archive)
source_hash=digest(archive)
brain_id=service.create_brain(principal,'Retained longitudinal snapshot offline replay')['id']
def action(name,payload):
 result=service.handle(principal,{'message_type':'request','contract_version':CONTRACT_VERSION,
  'request_id':uid(),'action':name,'target':{'brain_ref':brain_id,'conversation_ref':'isolated-repair','branch_ref':'main'},'payload':payload})
 assert result['outcome']=='completed',result
 return result['result']
restored=action('restore',{'uploaded_archive_ref':archive['archive_id'],
 'expected_manifest_sha256':archive['manifest_sha256'],'mode':'new_brain',
 'apply_current_tombstones':True,'expected_scope_generation':1,'budget':default_budget(64000)})
assert restored['read_enabled'] and restored['quarantined_event_count']==0,restored
bound=json.loads((root/'.local/longitudinal-v7-verification/access-age/bound-plan.json').read_text())
queries=bound['queries']
helper_path=root/'.local/longitudinal-v3-verification/access_age_diagnostic.py'
spec=importlib.util.spec_from_file_location('snapshot_helpers',helper_path);helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
results=[]
with database.transaction(principal) as conn:
 tables=helpers.scoped_tables(conn);before=helpers.snapshot(conn,service._params(principal,brain_id),tables)
 conn.execute("SET LOCAL statement_timeout='10000ms'")
 brain=service._brain(conn,principal,brain_id)
 for query in queries:
  for days in (0,3650):
   at=(datetime.fromisoformat(bound['reference_time'])+timedelta(days=days)).isoformat()
   timed=MemoryService(database,access_time_provider=lambda:at)
   payload={'query':query['text'],'intent':'explore','cue_event_ids':[],'additional_cues':[],
    'evidence_mode':'contextual','world_filter':['real_world'],'budget':default_budget(16000),
    'evidence_cutoff':{'mode':'through_sequence','through_sequence':brain['durable_sequence']},
    'read_fence':default_read_fence(brain['durable_sequence'])}
   with conn.transaction(force_rollback=True):
    result,_,_=timed._retrieval(Profiled(conn),principal,brain,
     {'brain_ref':brain_id,'conversation_ref':'isolated-repair','branch_ref':'main'},payload)
   assert result['usage']['model_calls']==result['usage']['embedding_calls']==0
   assert helpers.snapshot(conn,service._params(principal,brain_id),tables)==before
   results.append({'query_id':query['id'],'days':days,'query':query['text'],
    'context':json.loads(cognition.render_recall(result)),'result':result})
 assert helpers.snapshot(conn,service._params(principal,brain_id),tables)==before
assert digest(service.download_archive(principal,archive['archive_id']))==source_hash
assert digest(json.loads(source_path.read_text()))==source_hash
report={'runtime_build':BUILD_ID,'source_archive_sha256':archive['manifest_sha256'],
 'source_files_unchanged':True,'provider_calls':0,'restored_brain_id':brain_id,
 'scope':'Same trusted archived source graph restored to an isolated brain; normal database retrieval, fixed access clock, no host generation or background learning. Partial/index-lag flags retained. Not behavioral acceptance.',
 'restore':restored,'scoped_tables_unchanged_after_each_read':len(tables),'results':results}
(output/'snapshot-replay.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
for item in results:
 print(json.dumps({'query':item['query_id'],'days':item['days'],'items':len(item['result']['items']),
  'elapsed_ms':item['result']['usage']['elapsed_ms'],'status':item['result']['status'],
  'context':item['context']},ensure_ascii=False))
